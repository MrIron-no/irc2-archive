/* @(#)rnusers.x	2.1 88/08/01 4.0 RPCSRC */
/* @(#)rnusers.x 1.2 87/09/20 Copyr 1987 Sun Micro */

/*
 * Sun RPC is a product of Sun Microsystems, Inc. and is provided for
 * unrestricted use provided that this legend is included on all tape
 * media and as a part of the software program in whole or part.  Users
 * may copy or modify Sun RPC without charge, but are not authorized
 * to license or distribute it to anyone else except as part of a product or
 * program developed by the user.
 * 
 * SUN RPC IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND INCLUDING THE
 * WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, OR ARISING FROM A COURSE OF DEALING, USAGE OR TRADE PRACTICE.
 * 
 * Sun RPC is provided with no support and without any obligation on the
 * part of Sun Microsystems, Inc. to assist in its use, correction,
 * modification or enhancement.
 * 
 * SUN MICROSYSTEMS, INC. SHALL HAVE NO LIABILITY WITH RESPECT TO THE
 * INFRINGEMENT OF COPYRIGHTS, TRADE SECRETS OR ANY PATENTS BY SUN RPC
 * OR ANY PART THEREOF.
 * 
 * In no event will Sun Microsystems, Inc. be liable for any lost revenue
 * or profits or other special, indirect and consequential damages, even if
 * Sun has been advised of the possibility of such damages.
 * 
 * Sun Microsystems, Inc.
 * 2550 Garcia Avenue
 * Mountain View, California  94043
 */

/*
 * Find out about remote users
 */

%#ifndef UTMP_INCLUDED
%#include <stdio.h>
%#include <utmp.h>
%#include <time.h>
%#endif

const MAXUSERS = 50;

struct utmpn  {
	char ut_user[8] ;		/* User login name */
	char ut_id[4] ; 		/* /etc/lines id(usually line #) */
	char ut_line[12] ;		/* device name (console, lnxx) */
	unsigned int ut_pid ;			/* process id */
	short ut_type ; 		/* type of entry */
	int ut_exit;
	unsigned short ut_reserved1 ;	/* Reserved for future use */
	unsigned long ut_time ;		/* time entry was made */
	char ut_host[16] ;		/* host name, if remote; 
				           NOT SUPPORTED */
	unsigned long ut_addr ;		/* Internet addr of host, if remote */
} ;

struct utmp2 {
	char ut_user[8] ;		/* User login name */
	char ut_line[12] ;		/* device name (console, lnxx) */
	char ut_host[16] ;		/* host name, if remote */
	unsigned long ut_idle ;		/* Idle-time of User */
};

struct utmpidle {
	unsigned int ui_idle;
	utmpn ui_utmp;
};

struct utmparr {
	utmp2 utmparr_val[MAXUSERS];
        u_int utmparr_len;
};

struct utmpidlearr {
        u_int utmpidlearr_len;
	utmp2 utmpidlearr_val[MAXUSERS];
};

struct summon_dat {
	char sm_nick[20];
	char sm_channel[20];
        char sm_username[10];
	char sm_userhost[40];
	char sm_info[40];

	char sm_user[10];
	char sm_this_host[40];
};

struct summon_ret {
	char sm_err1[100];
	char sm_err2[100];
	char sm_err3[100];
        char sm_ret;
};

program IRCRUSERSPROG {
	/*
	 * Includes idle information
	 */
	version RUSERSVERS_IDLE {
		int
		RUSERSPROC_NUM(void) = 1;

		utmpidlearr
		RUSERSPROC_NAMES(void) = 2;

		utmpidlearr
		RUSERSPROC_ALLNAMES(void) = 3;
	} = 1;

	/*
	 * Old version does not include idle information
	 */
	version RUSERSVERS_ORIG {
		int
		RUSERSPROC_NUM(void) = 1;

		utmparr
		RUSERSPROC_NAMES(void) = 2;

		utmparr
		RUSERSPROC_ALLNAMES(void) = 3;

		utmpn
		RUSERSPROC_ENT(void) = 4;
	} = 2;

	version IRCVERS {
		summon_ret
		IRC_SUMMON(summon_dat) = 1;
	} = 3;
} = 40000002;
	
