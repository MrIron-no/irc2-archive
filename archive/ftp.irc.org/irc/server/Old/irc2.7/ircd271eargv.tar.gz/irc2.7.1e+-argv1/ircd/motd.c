/*
 * send out a MOTD per client connection if there's a file
 *
 * argv 2/92
 */

void
localmotd(sptr)
aClient *sptr;
{
}
