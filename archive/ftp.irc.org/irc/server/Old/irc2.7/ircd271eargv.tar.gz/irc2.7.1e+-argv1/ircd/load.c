#ifndef lint
static char sccsid[] = "@(#) load.c 1.3 92/05/17";
#endif
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#ifdef sun
#include <sys/time.h>
#else
#include <time.h>
#endif
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <strings.h>
#include <rpc/rpc.h>
#include <rpc/pmap_prot.h>
#include <netdb.h>
#include <sys/socket.h>
#include "top.h"

extern int errno;
static struct timeval timeout = { 5, 0 };
static struct timeval long_timeout = { 300, 0 };

#define HostFile "/etc/default/load"
              
main(argc,argv)
int argc;
char *argv[];
{ CLIENT    *cl;
  int       sock, portno, *pret;
  struct sockaddr_in server_addr;
  struct hostent *hp = NULL;
  load	ld;
  load_ret *ldr;
  char server[100];
  int i;
  FILE *fp;

  if(argc!=2)
  { printf(" usage %s get/rset\n", argv[0]);
    if(argc!=3) exit(1);
  }
  if(!strncmp(argv[1], "get", 3)) ld.cmd = LD_CMD_GET;
  else
  { if(!strncmp(argv[1], "rset", 4)) ld.cmd = LD_CMD_RSET;
    else ld.cmd = LD_CMD_NOP;
  }

  if( (fp=fopen( HostFile, "r"))==NULL)
  { printf("Cannot open %s.\n", HostFile);
    exit(1);
  }

  while(!feof(fp))
  { fgets( server, 100, fp);
    server[strlen(server)-1] = '\0';
    if(feof(fp))break;

    if(( hp = gethostbyname(server) ) == NULL) {
      fprintf(stderr, "host '%s' not found.\n", server);
      return -1;
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = 0;
    bcopy( hp->h_addr, (caddr_t)&server_addr.sin_addr, hp->h_length);

    portno = pmap_getport(&server_addr, TOP, TOPVERS, IPPROTO_UDP);

    if( portno == 0) {
      fprintf(stderr, "cannot get port.\n");
      return -1;
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons( portno);
    bcopy( hp->h_addr, (caddr_t)&server_addr.sin_addr, hp->h_length);
  
    sock = RPC_ANYSOCK;
    cl = clntudp_create( &server_addr, TOP, TOPVERS, timeout, &sock);

    if(cl == NULL) {
      goto end_lable_2;
    }

    ldr = load_prg_1(&ld, cl);

    if(ldr == NULL) {
      clnt_perror(cl, server);
      goto end_lable;
    }


    if(!ld.cmd)printf("-> %f  %f  %f\n",  ldr->avenrun[0], ldr->avenrun[1],
             ldr->avenrun[2]);
    printf("%s: ", server);
    for(i=0;i<MAXLOADLST; i++)
      printf("%d ", ldr->LoadLevel[i]);
    printf("\n");

end_lable:
    CLNT_DESTROY(cl);
end_lable_2:
    close(sock);
    strcpy(server,"\0\0\0");
  }
  close(fp);
}
