#include <rpc/rpc.h>
#include <sys/time.h>
#include "ircd.h"

#ifdef hpux

#ifndef NULL
#define NULL  0
#endif  NULL

#endif hpux
#ifndef UTMP_INCLUDED
#include <stdio.h>
#include <utmp.h>
#include <time.h>
#endif

static struct timeval TIMEOUT = { 25, 0 };

int *
rusersproc_num_1(argp, clnt)
	void *argp;
	CLIENT *clnt;
{
	static int res;

#ifdef hpux
	memset(&res, 0, sizeof(res));
#else  hpux
	memset(&res, sizeof(res));
#endif hpux
	if (clnt_call(clnt, RUSERSPROC_NUM, xdr_void, argp, xdr_int, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


utmpidlearr *
rusersproc_names_1(argp, clnt)
	void *argp;
	CLIENT *clnt;
{
	static utmpidlearr res;

#ifdef hpux
	memset(&res, 0, sizeof(res));
#else  hpux
	memset(&res, sizeof(res));
#endif hpux
	if (clnt_call(clnt, RUSERSPROC_NAMES, xdr_void, argp, xdr_utmpidlearr, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


utmpidlearr *
rusersproc_allnames_1(argp, clnt)
	void *argp;
	CLIENT *clnt;
{
	static utmpidlearr res;

#ifdef hpux
	memset(&res, 0, sizeof(res));
#else  hpux
	memset(&res, sizeof(res));
#endif hpux
	if (clnt_call(clnt, RUSERSPROC_ALLNAMES, xdr_void, argp, xdr_utmpidlearr, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


int *
rusersproc_num_2(argp, clnt)
	void *argp;
	CLIENT *clnt;
{
	static int res;

#ifdef hpux
	memset(&res, 0, sizeof(res));
#else  hpux
	memset(&res, sizeof(res));
#endif hpux
	if (clnt_call(clnt, RUSERSPROC_NUM, xdr_void, argp, xdr_int, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


utmparr *
rusersproc_names_2(argp, clnt)
	void *argp;
	CLIENT *clnt;
{
	static utmparr res;

#ifdef hpux
	memset(&res, 0, sizeof(res));
#else  hpux
	memset(&res, sizeof(res));
#endif hpux
	if (clnt_call(clnt, RUSERSPROC_NAMES, xdr_void, argp, xdr_utmparr, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


utmparr *
rusersproc_allnames_2(argp, clnt)
	void *argp;
	CLIENT *clnt;
{
	static utmparr res;

#ifdef hpux
	memset(&res, 0, sizeof(res));
#else  hpux
	memset(&res, sizeof(res));
#endif hpux
	if (clnt_call(clnt, RUSERSPROC_ALLNAMES, xdr_void, argp, xdr_utmparr, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


utmpn *
rusersproc_ent_2(argp, clnt)
	void *argp;
	CLIENT *clnt;
{
	static utmpn res;

#ifdef hpux
	memset(&res, 0, sizeof(res));
#else  hpux
	memset(&res, sizeof(res));
#endif hpux
	if (clnt_call(clnt, RUSERSPROC_ENT, xdr_void, argp, xdr_utmpn, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


summon_ret *
irc_summon_3(argp, clnt)
	summon_dat *argp;
	CLIENT *clnt;
{
	static summon_ret res;

#ifdef hpux
	memset(&res, 0, sizeof(res));
#else  hpux
	memset(&res, sizeof(res));
#endif hpux
	if (clnt_call(clnt, IRC_SUMMON, xdr_summon_dat, argp, xdr_summon_ret, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}

