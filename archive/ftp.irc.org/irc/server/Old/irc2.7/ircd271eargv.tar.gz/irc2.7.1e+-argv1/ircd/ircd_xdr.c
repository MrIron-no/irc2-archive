#include <rpc/rpc.h>
#include "ircd.h"
#ifndef UTMP_INCLUDED
#include <stdio.h>
#include <utmp.h>
#include <time.h>
#endif


bool_t
xdr_utmpn(xdrs, objp)
	XDR *xdrs;
	utmpn *objp;
{
	if (!xdr_vector(xdrs, (char *)objp->ut_user, 8, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->ut_id, 4, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->ut_line, 12, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_u_int(xdrs, &objp->ut_pid)) {
		return (FALSE);
	}
	if (!xdr_short(xdrs, &objp->ut_type)) {
		return (FALSE);
	}
	if (!xdr_int(xdrs, &objp->ut_exit)) {
		return (FALSE);
	}
	if (!xdr_u_short(xdrs, &objp->ut_reserved1)) {
		return (FALSE);
	}
	if (!xdr_u_long(xdrs, &objp->ut_time)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->ut_host, 16, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_u_long(xdrs, &objp->ut_addr)) {
		return (FALSE);
	}
	return (TRUE);
}




bool_t
xdr_utmp2(xdrs, objp)
	XDR *xdrs;
	utmp2 *objp;
{
	if (!xdr_vector(xdrs, (char *)objp->ut_user, 8, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->ut_line, 12, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->ut_host, 16, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_u_long(xdrs, &objp->ut_idle)) {
		return (FALSE);
	}
	return (TRUE);
}




bool_t
xdr_utmpidle(xdrs, objp)
	XDR *xdrs;
	utmpidle *objp;
{
	if (!xdr_u_int(xdrs, &objp->ui_idle)) {
		return (FALSE);
	}
	if (!xdr_utmpn(xdrs, &objp->ui_utmp)) {
		return (FALSE);
	}
	return (TRUE);
}




bool_t
xdr_utmparr(xdrs, objp)
	XDR *xdrs;
	utmparr *objp;
{
	if (!xdr_vector(xdrs, (char *)objp->utmparr_val, MAXUSERS, sizeof(utmp2), xdr_utmp2)) {
		return (FALSE);
	}
	if (!xdr_u_int(xdrs, &objp->utmparr_len)) {
		return (FALSE);
	}
	return (TRUE);
}




bool_t
xdr_utmpidlearr(xdrs, objp)
	XDR *xdrs;
	utmpidlearr *objp;
{
	if (!xdr_u_int(xdrs, &objp->utmpidlearr_len)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->utmpidlearr_val, MAXUSERS, sizeof(utmp2), xdr_utmp2)) {
		return (FALSE);
	}
	return (TRUE);
}




bool_t
xdr_summon_dat(xdrs, objp)
	XDR *xdrs;
	summon_dat *objp;
{
	if (!xdr_vector(xdrs, (char *)objp->sm_nick, 20, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->sm_channel, 20, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->sm_username, 10, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->sm_userhost, 40, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->sm_info, 40, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->sm_user, 10, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->sm_this_host, 40, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	return (TRUE);
}




bool_t
xdr_summon_ret(xdrs, objp)
	XDR *xdrs;
	summon_ret *objp;
{
	if (!xdr_vector(xdrs, (char *)objp->sm_err1, 100, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->sm_err2, 100, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_vector(xdrs, (char *)objp->sm_err3, 100, sizeof(char), xdr_char)) {
		return (FALSE);
	}
	if (!xdr_char(xdrs, &objp->sm_ret)) {
		return (FALSE);
	}
	return (TRUE);
}


