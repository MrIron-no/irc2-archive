#ifndef UTMP_INCLUDED
#include <stdio.h>
#include <utmp.h>
#include <time.h>
#endif
#define MAXUSERS 50

struct utmpn {
	char ut_user[8];
	char ut_id[4];
	char ut_line[12];
	u_int ut_pid;
	short ut_type;
	int ut_exit;
	u_short ut_reserved1;
	u_long ut_time;
	char ut_host[16];
	u_long ut_addr;
};
typedef struct utmpn utmpn;
bool_t xdr_utmpn();


struct utmp2 {
	char ut_user[8];
	char ut_line[12];
	char ut_host[16];
	u_long ut_idle;
};
typedef struct utmp2 utmp2;
bool_t xdr_utmp2();


struct utmpidle {
	u_int ui_idle;
	utmpn ui_utmp;
};
typedef struct utmpidle utmpidle;
bool_t xdr_utmpidle();


struct utmparr {
	utmp2 utmparr_val[MAXUSERS];
	u_int utmparr_len;
};
typedef struct utmparr utmparr;
bool_t xdr_utmparr();


struct utmpidlearr {
	u_int utmpidlearr_len;
	utmp2 utmpidlearr_val[MAXUSERS];
};
typedef struct utmpidlearr utmpidlearr;
bool_t xdr_utmpidlearr();


struct summon_dat {
	char sm_nick[20];
	char sm_channel[20];
	char sm_username[10];
	char sm_userhost[40];
	char sm_info[40];
	char sm_user[10];
	char sm_this_host[40];
};
typedef struct summon_dat summon_dat;
bool_t xdr_summon_dat();


struct summon_ret {
	char sm_err1[100];
	char sm_err2[100];
	char sm_err3[100];
	char sm_ret;
};
typedef struct summon_ret summon_ret;
bool_t xdr_summon_ret();


#define IRCRUSERSPROG ((u_long)40000002)
#define RUSERSVERS_IDLE ((u_long)1)
#define RUSERSPROC_NUM ((u_long)1)
extern int *rusersproc_num_1();
#define RUSERSPROC_NAMES ((u_long)2)
extern utmpidlearr *rusersproc_names_1();
#define RUSERSPROC_ALLNAMES ((u_long)3)
extern utmpidlearr *rusersproc_allnames_1();
#define RUSERSVERS_ORIG ((u_long)2)
extern int *rusersproc_num_2();
extern utmparr *rusersproc_names_2();
extern utmparr *rusersproc_allnames_2();
#define RUSERSPROC_ENT ((u_long)4)
extern utmpn *rusersproc_ent_2();
#define IRCVERS ((u_long)3)
#define IRC_SUMMON ((u_long)1)
extern summon_ret *irc_summon_3();

