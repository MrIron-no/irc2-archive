char *copyright = 
	"ircd_sub.c, version 1.1, copyright (c) 1992 Kai Krueger";
#ifndef lint
static char sccsid[] = "@(#) ircd_sub.c 1.3 92/07/21";
#endif

#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/file.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netdb.h>
#include <pwd.h>
#ifdef sun
#include <sys/time.h>
#else
#include <time.h>
#endif
#include <errno.h>
#include <rpc/rpc.h>
#include <strings.h>
#include <sys/signal.h>

#include <pwd.h>
#include <nlist.h>

#include "../include/struct.h"
#include "ircd.h"

#define UTMP "/etc/utmp"

extern int errno;

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
int *rusersproc_num_1()
{
}
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
utmpidlearr *rusersproc_names_1()
{
}
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
utmpidlearr *rusersproc_allnames_1()
{
}
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
int *rusersproc_num_2()
{
}
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
utmparr *rusersproc_allnames_2()
{
}
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
utmparr *rusersproc_names_2()
{ int fd;
  static utmparr uta;
  static utmp2  utn;

  uta.utmparr_len = 0;

  if ((fd = utmp_open()) == -1)
  { uta.utmparr_len--;
    return (&uta);
  }

  while (utmp_read(fd, &utn) == 0)
  { uta.utmparr_val[uta.utmparr_len] = utn; 
#if 0
    fprintf(stderr,"1) [%d] %s %s %s\n",     uta.utmparr_len,
                 uta.utmparr_val[uta.utmparr_len].ut_name,
                 uta.utmparr_val[uta.utmparr_len].ut_line,
                 uta.utmparr_val[uta.utmparr_len].ut_host);
    fprintf(stderr,"2) %s %s %s\n", utn.ut_name, utn.ut_line, utn.ut_host);
#endif
    uta.utmparr_len++;
  }

  utmp_close(fd);
#if 0
    for(fd=0; fd<uta.utmparr_len; fd++)
    fprintf(stderr,"[%d] %s %s %s %s (%ld)\n",     fd,
                 uta.utmparr_val[fd].ut_name,
                 uta.utmparr_val[fd].ut_line,
                 uta.utmparr_val[fd].ut_host,
                 gmtime(&uta.utmparr_val[fd].ut_idle),
                 uta.utmparr_val[fd].ut_idle );
    fprintf(stderr," size utmparr =%d;\n", sizeof(utmparr));
    fprintf(stderr," size utmpn   =%d;\n", sizeof(utmpn));
#endif

  return (&uta);
}
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
utmpn *rusersproc_ent_2()
{ static int fd;
  utmparr uta;
  utmpn  utn;

  uta.utmparr_len = 0;

  if(!fd)
    if ((fd = utmp_open()) == -1)
    { uta.utmparr_len--;
      return (&utn);
     }

  utmp_read(fd, &utn);
#if 1
  fprintf(stderr,"2) %s %s %s\n", utn.ut_name, utn.ut_line, utn.ut_host);
#endif

  /*utmp_close(fd);*/

  return (&utn);
}
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
summon_ret *irc_summon_3(smd, rqstp)
summon_dat *smd;
struct svc_rep *rqstp;
{ static summon_ret smr;
  char namebuf[10],linebuf[10],hostbuf[17],*host,*user;
  char linetmp[10], ttyname[15]; /* Ack */
  struct stat stb;
  time_t ltime = (time_t)0;
  int fd, flag = 0;

  smr.sm_ret = 0;
  if ((fd = utmp_open()) == -1)
  { smr.sm_ret++;
    sprintf(smr.sm_err1,":%s NOTICE  Cannot open utmp", smd->sm_this_host);
    return ( &smr);
  }
  /* use least-idle tty, not the first
   * one we find in utmp. 10/9/90 Spike@world.std.com
   * (loosely based on Jim Frost jimf@saber.com code)
   */
		
  while ((flag = utmp_read2(fd, namebuf, linetmp, hostbuf)) == 0){
    if (StrEq(namebuf,smd->sm_user))
    { sprintf(ttyname,"/dev/%s",linetmp);
      sprintf(smr.sm_err1, "NOTICE %s :Summoning user %s to irc",
 		   smd->sm_nick, namebuf);
      if (stat(ttyname,&stb) == -1) sprintf(ttyname,"/dev/pty/%s",linetmp);
      if (stat(ttyname,&stb) == -1) {
        smr.sm_ret++;
        sprintf(smr.sm_err1,":%s NOTICE %s  Cannot stat %s",
				 smd->sm_this_host, smd->sm_nick,ttyname);
        return ( &smr);
      }
      if (!ltime) {
         ltime= stb.st_mtime;
         strcpy(linebuf,linetmp);
      }
      else if (stb.st_mtime > ltime) { /* less idle */
         ltime= stb.st_mtime;
         strcpy(linebuf,linetmp);
      }
    }
  }
  utmp_close(fd);
  if (ltime == 0)
  { smr.sm_ret++;
    sprintf(smr.sm_err1,":%s NOTICE %s :User %s not logged in",
			   smd->sm_this_host, smd->sm_nick, smd->sm_user);
  }
  else
  { int fd;
    char line[120], *wrerr = "NOTICE %s :Write error. Couldn't summon.";
    if (strlen(linebuf) > 9)
    { smr.sm_ret++;
      sprintf(smr.sm_err1,"NOTICE %s :Serious fault in SUMMON.",
			   smd->sm_nick);
      smr.sm_ret++;
      sprintf(smr.sm_err2,"NOTICE %s :linebuf too long. Inform Administrator",
			   smd->sm_nick);
      return( &smr);
    }
    /* Following line added to prevent cracking to e.g. /dev/kmem if */
    /* UTMP is for some silly reason writable to everyone... */
    if ((linebuf[0] != 't' || linebuf[1] != 't' || linebuf[2] != 'y')
	    && (linebuf[0] != 'c' || linebuf[1] != 'o' || linebuf[2] != 'n')
	    && (linebuf[0] != 'p' || linebuf[1] != 't' || linebuf[2] != 'y' ||
		linebuf[3] != '/')
	    )
    { smr.sm_ret++;
      sprintf(smr.sm_err1,
	      "NOTICE %s :Looks like mere mortal souls are trying to",
			   smd->sm_nick);
      smr.sm_ret++;
      sprintf(smr.sm_err2,	"NOTICE %s :enter the twilight zone... ",
			   smd->sm_nick);
      smr.sm_ret++;
      sprintf(smr.sm_err3,"%s (%s@%s, nick %s, %s)",
		      "FATAL: major security hack. Notify Administrator !",
		      smd->sm_username, smd->sm_userhost,
		      smd->sm_nick, smd->sm_info);
      return (&smr);
    }
    if ((linebuf[0] != 'c' || linebuf[1] != 'o' || linebuf[2] != 'n'))
       sprintf(line,"/dev/pty/%s", linebuf);
    else sprintf(line,"/dev/%s", linebuf);
    alarm(5);
    if ((fd = open(line, O_WRONLY | O_NDELAY)) == -1) 
    { alarm(0);
      smr.sm_ret++;
      sprintf(smr.sm_err1, "NOTICE %s :%s seems to have disabled summoning...",
			   smd->sm_nick, namebuf);
      return (&smr);
    }
    alarm(0);
    strcpy(line,
	       "\n\r\007ircd: You are being summoned to Internet Relay Chat by\n\r");
    alarm(5);
    if (write(fd, line, strlen(line)) != strlen(line))
    { alarm(0);
      close(fd);
      smr.sm_ret++;
      vsprintf(smr.sm_err1,wrerr,smd->sm_nick);
      return (&smr);
    }
    alarm(0);
    smr.sm_ret++;
    sprintf(line, "ircd: Channel *: %s@%s (%s) %s\n\r",
		smd->sm_username, smd->sm_userhost, smd->sm_nick, smd->sm_info);
    alarm(5);
    if (write(fd, line, strlen(line)) != strlen(line))
    { alarm(0);
      close(fd);
      smr.sm_ret++;
      vsprintf(smr.sm_err1,wrerr,smd->sm_nick);
      return (&smr);
    }
    alarm(0);
    strcpy(line,"ircd: Respond with irc\n\r");
    alarm(5);
    if (write(fd, line, strlen(line)) != strlen(line))
    { alarm(0);
      close(fd);
      smr.sm_ret++;
      vsprintf(smr.sm_err1,wrerr,smd->sm_nick);
      return (&smr);
    }
    close(fd);
    alarm(0);
    smr.sm_ret++;
  }
  return (&smr);
}
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
#include <utmp.h> /* */

int utmp_open()
{
  return (open(UTMP_FILE,O_RDONLY));
}
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
int utmp_read(fd, utn)
int fd;
utmp2 *utn;
{ struct utmp ut;
  char linetmp[10], ttyname[15]; /* Ack */
  struct stat stb;
  struct passwd *pd;
  unsigned long ltime;


	while (read(fd, &ut, sizeof (struct utmp)) == sizeof (struct utmp))
	    { strncpyzt(utn->ut_name,ut.ut_name,9);
	      strncpyzt(utn->ut_line,ut.ut_line,13);
	      strncpyzt(utn->ut_host,ut.ut_host,17);

              ltime = time((long *) 0);
	      utn->ut_idle = 0;
              sprintf(ttyname,"/dev/%s",ut.ut_line);
              if (stat(ttyname,&stb) == -1) {
                sprintf(ttyname,"/dev/pty/%s",ut.ut_line);
                if (stat(ttyname,&stb) != -1) {
                    utn->ut_idle = ltime - stb.st_mtime;
                }
              } else utn->ut_idle = ltime - stb.st_mtime;

	      if(utn->ut_idle)
	      { if( (pd = getpwnam( ut.ut_name))!= NULL)
		{ if( stb.st_uid != pd->pw_uid)ut.ut_type = EMPTY; 
                }
              }
	      if (ut.ut_type == USER_PROCESS)
			return 0;
	    }
	return -1;
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
int utmp_read2(fd, name, line, host)
int fd;
char *name, *line, *host;
    {
	struct utmp ut;
	while (read(fd, &ut, sizeof (struct utmp)) == sizeof (struct utmp))
	    {
		strncpyzt(name,ut.ut_name,9);
		strncpyzt(line,ut.ut_line,10);
		strncpy(host,ut.ut_host, 16);
		if (ut.ut_type == USER_PROCESS)
			return 0;
	    }
	return -1;
    }

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
int utmp_close(fd)
int fd;
    {
	return(close(fd));
    }

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/









