#include <stdio.h>
#include <rpc/rpc.h>
#include "ircd.h"
#ifndef UTMP_INCLUDED
#include <stdio.h>
#include <utmp.h>
#include <time.h>
#endif

static void ircrusersprog_1();
static void ircrusersprog_2();
static void ircrusersprog_3();

main()
{
	SVCXPRT *transp;

	pmap_unset(IRCRUSERSPROG, RUSERSVERS_IDLE);
	pmap_unset(IRCRUSERSPROG, RUSERSVERS_ORIG);
	pmap_unset(IRCRUSERSPROG, IRCVERS);

	transp = svcudp_create(RPC_ANYSOCK);
	if (transp == NULL) {
		fprintf(stderr, "cannot create udp service.\n");
		exit(1);
	}
	if (!svc_register(transp, IRCRUSERSPROG, RUSERSVERS_IDLE, ircrusersprog_1, IPPROTO_UDP)) {
		fprintf(stderr, "unable to register (IRCRUSERSPROG, RUSERSVERS_IDLE, udp).\n");
		exit(1);
	}
	if (!svc_register(transp, IRCRUSERSPROG, RUSERSVERS_ORIG, ircrusersprog_2, IPPROTO_UDP)) {
		fprintf(stderr, "unable to register (IRCRUSERSPROG, RUSERSVERS_ORIG, udp).\n");
		exit(1);
	}
	if (!svc_register(transp, IRCRUSERSPROG, IRCVERS, ircrusersprog_3, IPPROTO_UDP)) {
		fprintf(stderr, "unable to register (IRCRUSERSPROG, IRCVERS, udp).\n");
		exit(1);
	}
	svc_run();
	fprintf(stderr, "svc_run returned\n");
	exit(1);
}

static void
ircrusersprog_1(rqstp, transp)
	struct svc_req *rqstp;
	SVCXPRT *transp;
{
	union {
		int fill;
	} argument;
	char *result;
	bool_t (*xdr_argument)(), (*xdr_result)();
	char *(*local)();

	switch (rqstp->rq_proc) {
	case NULLPROC:
		svc_sendreply(transp, xdr_void, NULL);
		return;

	case RUSERSPROC_NUM:
		xdr_argument = xdr_void;
		xdr_result = xdr_int;
		local = (char *(*)()) rusersproc_num_1;
		break;

	case RUSERSPROC_NAMES:
		xdr_argument = xdr_void;
		xdr_result = xdr_utmpidlearr;
		local = (char *(*)()) rusersproc_names_1;
		break;

	case RUSERSPROC_ALLNAMES:
		xdr_argument = xdr_void;
		xdr_result = xdr_utmpidlearr;
		local = (char *(*)()) rusersproc_allnames_1;
		break;

	default:
		svcerr_noproc(transp);
		return;
	}
#ifdef hpux
	memset(&argument, 0, sizeof(argument));
#else  hpux
	memset(&argument, sizeof(argument));
#endif hpux
	if (!svc_getargs(transp, xdr_argument, &argument)) {
		svcerr_decode(transp);
		return;
	}
	result = (*local)(&argument, rqstp);
	if (result != NULL && !svc_sendreply(transp, xdr_result, result)) {
		svcerr_systemerr(transp);
	}
	if (!svc_freeargs(transp, xdr_argument, &argument)) {
		fprintf(stderr, "unable to free arguments\n");
		exit(1);
	}
}


static void
ircrusersprog_2(rqstp, transp)
	struct svc_req *rqstp;
	SVCXPRT *transp;
{
	union {
		int fill;
	} argument;
	char *result;
	bool_t (*xdr_argument)(), (*xdr_result)();
	char *(*local)();

	switch (rqstp->rq_proc) {
	case NULLPROC:
		svc_sendreply(transp, xdr_void, NULL);
		return;

	case RUSERSPROC_NUM:
		xdr_argument = xdr_void;
		xdr_result = xdr_int;
		local = (char *(*)()) rusersproc_num_2;
		break;

	case RUSERSPROC_NAMES:
		xdr_argument = xdr_void;
		xdr_result = xdr_utmparr;
		local = (char *(*)()) rusersproc_names_2;
		break;

	case RUSERSPROC_ALLNAMES:
		xdr_argument = xdr_void;
		xdr_result = xdr_utmparr;
		local = (char *(*)()) rusersproc_allnames_2;
		break;

	case RUSERSPROC_ENT:
		xdr_argument = xdr_void;
		xdr_result = xdr_utmpn;
		local = (char *(*)()) rusersproc_ent_2;
		break;

	default:
		svcerr_noproc(transp);
		return;
	}
#ifdef hpux
	memset(&argument, 0, sizeof(argument));
#else  hpux
	memset(&argument, sizeof(argument));
#endif hpux
	if (!svc_getargs(transp, xdr_argument, &argument)) {
		svcerr_decode(transp);
		return;
	}
	result = (*local)(&argument, rqstp);
	if (result != NULL && !svc_sendreply(transp, xdr_result, result)) {
		svcerr_systemerr(transp);
	}
	if (!svc_freeargs(transp, xdr_argument, &argument)) {
		fprintf(stderr, "unable to free arguments\n");
		exit(1);
	}
}


static void
ircrusersprog_3(rqstp, transp)
	struct svc_req *rqstp;
	SVCXPRT *transp;
{
	union {
		summon_dat irc_summon_3_arg;
	} argument;
	char *result;
	bool_t (*xdr_argument)(), (*xdr_result)();
	char *(*local)();

	switch (rqstp->rq_proc) {
	case NULLPROC:
		svc_sendreply(transp, xdr_void, NULL);
		return;

	case IRC_SUMMON:
		xdr_argument = xdr_summon_dat;
		xdr_result = xdr_summon_ret;
		local = (char *(*)()) irc_summon_3;
		break;

	default:
		svcerr_noproc(transp);
		return;
	}
#ifdef hpux
	memset(&argument, 0, sizeof(argument));
#else  hpux
	memset(&argument, sizeof(argument));
#endif hpux
	if (!svc_getargs(transp, xdr_argument, &argument)) {
		svcerr_decode(transp);
		return;
	}
	result = (*local)(&argument, rqstp);
	if (result != NULL && !svc_sendreply(transp, xdr_result, result)) {
		svcerr_systemerr(transp);
	}
	if (!svc_freeargs(transp, xdr_argument, &argument)) {
		fprintf(stderr, "unable to free arguments\n");
		exit(1);
	}
}

