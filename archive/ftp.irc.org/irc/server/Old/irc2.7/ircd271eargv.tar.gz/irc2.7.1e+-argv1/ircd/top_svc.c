#include <stdio.h>
#include <rpc/rpc.h>
#include "top.h"


main()
{
	SVCXPRT *transp;


	transp = svcudp_create(RPC_ANYSOCK);
	if (transp == NULL) {
		fprintf(stderr, "cannot create udp service.\n");
		exit(1);
	}
	svc_run();
	fprintf(stderr, "svc_run returned\n");
	exit(1);
}
