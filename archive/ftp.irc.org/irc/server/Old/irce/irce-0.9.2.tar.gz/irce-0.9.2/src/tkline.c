/************************************************************************
 *   IRC - Internet Relay Chat, tkline.c
 *   Copyright (C) 1998 Ari Heikkinen
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "struct.h"
#include "common.h"
#include "sys.h"
#include "numeric.h"
#include "h.h"

#define TK_USAGE "Usage: /quote tkline seconds user@host <:comment>"

aTkline	*tklines = NULL;

static	int	add_tkline(sptr, expire, pattern, comment)
aClient	*sptr;
time_t	expire;
char	*pattern, *comment;
{
	aTkline	*new, *spot, *prev = NULL;

	if (!IsPerson(sptr) || expire <= 0
	    || BadPtr(pattern) || BadPtr(comment))
		return -1;

	expire = timeofday + expire;

	new = (aTkline *)MyMalloc(sizeof(*new));
	bzero((char *)new, sizeof(*new));
	new->expire = expire;
	strncpyzt(new->by, sptr->name, sizeof(new->by));
	strncpyzt(new->pattern, pattern, sizeof(new->pattern));
	strncpyzt(new->comment, comment, sizeof(new->comment));

	for (spot = tklines; spot; spot = spot->next)
	    {
		if (expire <= spot->expire)
			break;
		prev = spot;
	    }
	if (prev)
	    {
		prev->next = new;
		new->next = spot;
	    }
	else
	    {
		new->next = tklines;
		tklines = new;
	    }

	return 0;
}

static	int	del_tkline(pattern)
char	*pattern;
{
	aTkline	*tmp, *next, *prev = NULL;
	int	cnt = 0;

	if (BadPtr(pattern))
		return -1;

	for (tmp = tklines; tmp; tmp = next)
	    {
		next = tmp->next;
		if (!mycmp(tmp->pattern, pattern))
		    {
			cnt++;
			if (prev)
				prev->next = next;
			else
				tklines = next;
			MyFree(tmp);
			continue;
		    }
		prev = tmp;
	    }

	return cnt > 0 ? 0 : -1;
}

static	int	fix_pattern(ptr)
char	*ptr;
{
	int	chars = 0;

	for (; *ptr; ptr++)
	    {
		if (*ptr == ' ' || *ptr == '\t')
		    {
			*ptr = '\0';
			break;
		    }
		if (*ptr != '*' && *ptr != '?' && *ptr != '@')
			chars++;
	    }
	return chars;
}

static  char    *make_user_host(user, host)
char    *user, *host;
{
        static  char    buf[USERLEN+HOSTLEN+10];

        if (strlen(user) > USERLEN || strlen(host) > HOSTLEN)
		abort();
	(void)sprintf(buf, "%s@%s", user, host);
	return buf;
}

time_t	release_tklines(curtime)
time_t	curtime;
{
	while (tklines && tklines->expire <= curtime)
	    {
		aTkline *tmp = tklines;

		tklines = tklines->next;
		sendto_ops("Released TK-line %s", tmp->pattern);
		MyFree(tmp);
	    }
	return tklines ? tklines->expire : 0;
}

int	find_tkline(cptr)
aClient	*cptr;
{
	aTkline *tmp;
	char	*s;

	if (!cptr->user)
		return 0;

	s = make_user_host(cptr->user->username, cptr->user->host);
	for (tmp = tklines; tmp; tmp = tmp->next)
		if (match(tmp->pattern, s) == 0)
			goto tklined;
	s = make_user_host(cptr->user->username, inet_ntoa(cptr->ip));
	for (tmp = tklines; tmp; tmp = tmp->next)
		if (match(tmp->pattern, s) == 0)
			goto tklined;
	return 0;
tklined:
	sendto_one(cptr, ":%s %d %s :TK-lined (%s)", me.name,
		   ERR_YOUREBANNEDCREEP, cptr->name, tmp->comment);
	return -1;
}

/*
** m_tkline
**	parv[0] = sender prefix
**	parv[1] = expire time (seconds)
**	parv[2] = pattern (nick!user@host)
**	parv[3] = comment
*/
int	m_tkline(cptr, sptr, parc, parv)
aClient	*cptr, *sptr;
int	parc;
char	*parv[];
{
	char	*pattern, *comment, *ptr;
	time_t	expire;

	int	deleted = 0;

	if (check_registered_user(sptr))
		return 0;

	if (parc < 3 || BadPtr(parv[2]))
	    {
		sendto_one(sptr, err_str(ERR_NEEDMOREPARAMS),
			   me.name, parv[0], "TKLINE");
		sendto_one(sptr, ":%s NOTICE %s :%s", me.name, parv[0],
			   TK_USAGE);
		return 0;
	    }

	expire = atoi(parv[1]);
	if (!expire)
	    {
		sendto_one(sptr, ":%s NOTICE %s :Bad expire time [%s]",
			   me.name, parv[0], parv[1]);
		sendto_one(sptr, ":%s NOTICE %s :%s", me.name, parv[0],
			   TK_USAGE);
		return 0;
	    }

	pattern = parv[2];
	comment = parc > 3 && !BadPtr(parv[3]) ? parv[3] : "Banned";

	if (fix_pattern(pattern) < 5 || BadPtr(pattern)
	    || !(ptr = index(pattern, '@')) || index(ptr + 1, '@')
	    || !mycmp(pattern, "*@*"))
	    {
		sendto_one(sptr, ":%s NOTICE %s :Bad pattern [%s]",
			   me.name, parv[0], pattern);
		sendto_one(sptr, ":%s NOTICE %s :%s", me.name, parv[0],
			   TK_USAGE);
		return 0;
	    }

	if (!MyConnect(sptr) || !IsAnOper(sptr))
	    {
		sendto_one(sptr, err_str(ERR_NOPRIVILEGES), me.name, parv[0]);
		return 0;
	    }

	if (!del_tkline(pattern))
		deleted++;

	if (expire > 0 && !add_tkline(sptr, expire, pattern, comment))
	    {
		sendto_ops("TK-line %s [%s] %d %s (%s)",
			   deleted ? "updated" : "added",
			   parv[0], expire, pattern, comment);
		nextping = timeofday;
	    }
	else if (deleted)
		sendto_ops("TK-line deleted [%s] %s", parv[0], pattern);
	else
		sendto_one(sptr, ":%s NOTICE %s :Nothing added or removed.",
			   me.name, parv[0]);

	nexttklinerelease = tklines ? tklines->expire : 0;

	return 0;
}
