/************************************************************************
 *   IRC - Internet Relay Chat, hash.c
 *   Copyright (C) 1998 Ari Heikkinen
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "setup.h"
#include "common.h"
#include <stdlib.h>
#ifdef HAVE_STRINGH
# include <string.h>
#endif
#ifdef HAVE_MATHH
# include <math.h>
#endif
#ifdef HAVE_UNISTDH
# include <unistd.h>
#endif
#include "hash.h"

static	struct	{
	HashTable *ht;
	HashLink *ptr;
	int	hashv;
} lastGet = { 0, 0, 0 };

static	void	*hash_malloc(size)
int	size;
{
	void	*ptr;

	for (;;)
	    {
		if (ptr = malloc(size))
			return ptr;
		sleep(1);
	    }
}

static	void	hash_free(ptr)
void	*ptr;
{
	if (!ptr)
		abort();
	free(ptr);
}

static	int	make_prime(val)
int	val;
{
	int	i, sq;

	if (val <= 11)
		return 11;
	val |= 1;
	for (;; val += 2)
	    {
		sq = (int)sqrt((double)val);
		for (i = 2; i <= sq; i++)
			if (!(val % i))
				break;
		if (i > sq)
			return val;
	    }
}

static	int	calc_hash(key, keylen, size)
void	*key;
int	keylen;
int	size;
{
	unsigned char *ptr, *end;
	int	hashv = 0;

	if (keylen)
		for (ptr = key, end = &ptr[keylen]; ptr != end; ptr++)
			hashv = hashv * HASH_MULT + *ptr;
	else
		for (ptr = key, end = &ptr[15]; *ptr && ptr != end; ptr++)
			hashv = hashv * HASH_MULT + tolower(*ptr);
	if (hashv < 0)
		hashv = -hashv;
	return hashv % size;
}

static	HashLink *find_hash_link(ht, key, keylen, hvptr, hlptr)
HashTable *ht;
void	*key;
int	keylen;
int	*hvptr;
HashLink **hlptr;
{
	HashLink *hprev = 0, *ptr;
	int	hashv;

	hashv = calc_hash(key, keylen, ht->size);
	if (keylen)
		for (ptr = ht->table[hashv].list; ptr; ptr = ptr->hnext)
		    {
			if (ptr->keylen == keylen)
			    {
				if (!memcmp(ptr->key, key, keylen))
					break;
			    }
			hprev = ptr;
		    }
	else
		for (ptr = ht->table[hashv].list; ptr; ptr = ptr->hnext)
		    {
			if (!ptr->keylen)
			    {
				if (!strcasecmp(ptr->key, key))
					break;
			    }
			hprev = ptr;
		    }
	if (hvptr)
		*hvptr = hashv;
	if (hlptr)
		*hlptr = hprev;
	return ptr;
}

static	void	rebuild_hash_table(ht, nsize)
HashTable *ht;
int	nsize;
{
	HashLink *ptr, *hnext;
	HashItem *ntable;
	int	i, hashv, cnt = 0;

	nsize = make_prime(nsize);
	ntable = hash_malloc(sizeof(*ntable) * nsize);
	for (i = 0; i < nsize; i++)
		ntable[i].list = 0, ntable[i].links = 0;
	for (i = 0; i < ht->size; i++)
		for (ptr = ht->table[i].list; ptr; ptr = hnext)
		    {
			hnext = ptr->hnext;
			hashv = calc_hash(ptr->key, ptr->keylen, nsize);
			ptr->hnext = ntable[hashv].list;
			ntable[hashv].list = ptr;
			ntable[hashv].links++;
			cnt++;
		    }
	hash_free(ht->table);
	ht->table = ntable;
	ht->size = nsize;
	if (ht->entries != cnt)
		abort();
}

HashTable *hash_open(size, threshold, increment)
int	size;
float	threshold;
float	increment;
{
	HashTable *ptr;
	int	i;

	size = make_prime(size);
	if (threshold < 0.1 || threshold > 99.0)
		threshold = 0.7;
	if (increment < 0.1 || increment > 99.0)
		increment = 0.3;
	ptr = hash_malloc(sizeof(*ptr));
	ptr->table = hash_malloc(sizeof(*ptr->table) * size);
	for (i = 0; i < size; i++)
		ptr->table[i].list = 0, ptr->table[i].links = 0;
	ptr->size = size;
	ptr->entries = 0;
	ptr->threshold = threshold;
	ptr->increment = increment;
	return ptr;
}

void	hash_close(ht)
HashTable *ht;
{
	HashLink *ptr, *hnext;
	int	i;

	for (i = 0; i < ht->size; i++)
		for (ptr = ht->table[i].list; ptr; ptr = hnext)
		    {
			hnext = ptr->hnext;
			hash_free(ptr);
		    }
	hash_free(ht->table);
	hash_free(ht);
}

int	hash_add(ht, key, keylen, data)
HashTable *ht;
void	*key;
int	keylen;
void	*data;
{
	HashLink *ptr;
	int	hashv;

	if (!data || find_hash_link(ht, key, keylen, &hashv, 0))
		return -1;
	ptr = hash_malloc(sizeof(*ptr));
	ptr->key = key;
	ptr->keylen = keylen;
	ptr->data = data;
	ptr->hnext = ht->table[hashv].list;
	ht->table[hashv].list = ptr;
	ht->table[hashv].links++;
	if (++ht->entries >= (int)((float)ht->size * ht->threshold))
		rebuild_hash_table(ht, ht->size +
				   (int)((float)ht->size * ht->increment));
	return 0;
}

int	hash_del(ht, key, keylen)
HashTable *ht;
void	*key;
int	keylen;
{
	HashLink *ptr, *hprev;
	int	hashv;

	ptr = find_hash_link(ht, key, keylen, &hashv, &hprev);
	if (!ptr)
		return -1;
	if (hprev)
		hprev->hnext = ptr->hnext;
	else
	    {
		if (ht->table[hashv].list != ptr)
			abort();
		ht->table[hashv].list = ptr->hnext;
	    }
	if (--ht->table[hashv].links < 0)
		abort();
	hash_free(ptr);
	if (--ht->entries < 0)
		abort();
	return 0;
}

void	*hash_get(ht, key, keylen)
HashTable *ht;
void	*key;
int	keylen;
{
	HashLink *ptr, *hprev;
	int	hashv;

	ptr = find_hash_link(ht, key, keylen, &hashv, &hprev);
	if (!ptr)
	    {
		lastGet.ht = 0;
		return 0;
	    }
	if (hprev)
	    {
		hprev->hnext = ptr->hnext;
		ptr->hnext = ht->table[hashv].list;
		ht->table[hashv].list = ptr;
	    }
	lastGet.ht = ht;
	lastGet.ptr = ptr;
	lastGet.hashv = hashv;
	return ptr->data;
}

void	hash_del_last(void)
{
	HashTable *ht = lastGet.ht;
	HashLink *ptr = lastGet.ptr;
	int	hashv = lastGet.hashv;

	if (!ht || ht->table[hashv].list != ptr)
		abort();
	ht->table[hashv].list = ptr->hnext;
	if (--ht->table[hashv].links < 0)
		abort();
	hash_free(ptr);
	if (--ht->entries < 0)
		abort();
}
