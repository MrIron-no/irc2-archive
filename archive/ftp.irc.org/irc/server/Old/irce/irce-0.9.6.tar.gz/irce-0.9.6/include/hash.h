/************************************************************************
 *   IRC - Internet Relay Chat, hash.h
 *   Copyright (C) 1998 Ari Heikkinen
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef	__hash_include__
#define __hash_include__

#ifndef	PROTO
#ifdef __STDC__
#	define PROTO(x)	x
#else
#	define PROTO(x)	()
#endif
#endif

#define HASH_MULT 151

typedef	struct	HashLink {
	struct	HashLink *hnext;
	void	*key;
	int	keylen;
	void	*data;
} HashLink;

typedef	struct	{
	HashLink *list;
	int	links;
} HashItem;

typedef	struct	{
	HashItem *table;
	int	size;
	int	entries;
	float	threshold;
	float	increment;
} HashTable;

#ifndef	__STDC__
extern	HashTable *hash_open PROTO((int, float, float));
#endif
extern	void	hash_close PROTO((HashTable *));
extern	int	hash_add PROTO((HashTable *, void *, int, void *));
extern	int	hash_del PROTO((HashTable *, void *, int));
extern	void	*hash_get PROTO((HashTable *, void *, int));
extern	void	hash_del_last PROTO((void));

#endif
