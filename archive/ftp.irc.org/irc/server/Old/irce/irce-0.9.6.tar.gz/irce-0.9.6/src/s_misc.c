/************************************************************************
 *   IRC - Internet Relay Chat, s_misc.c
 *   Copyright (C) 1990 Jarkko Oikarinen and
 *                      University of Oulu, Computing Center
 *   Portions Copyright (C) 1998 Ari Heikkinen
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "struct.h"
#include "common.h"
#include "sys.h"
#include "numeric.h"
#ifdef HAVE_SYS_STATH
# include <sys/stat.h>
#endif
#ifdef HAVE_FCNTLH
# include <fcntl.h>
#endif
#ifdef HAVE_UNISTDH
# include <unistd.h>
#endif
#include "h.h"

static	void	exit_one_client PROTO((aClient *,aClient *,aClient *,char *));

static	char	*months[] = {
	"January",	"February",	"March",	"April",
	"May",	        "June",	        "July",	        "August",
	"September",	"October",	"November",	"December"
};

static	char	*weekdays[] = {
	"Sunday",	"Monday",	"Tuesday",	"Wednesday",
	"Thursday",	"Friday",	"Saturday"
};

/*
 * stats stuff
 */
struct	stats	ircst, *ircstp = &ircst;

char	*date(clock) 
time_t	clock;
{
	static	char	buf[80], plus;
	struct	tm *lt, *gm;
	struct	tm	gmbuf;
	int	minswest;

	if (!clock) 
		clock = timeofday;
	gm = gmtime(&clock);
	bcopy((char *)gm, (char *)&gmbuf, sizeof(gmbuf));
	gm = &gmbuf;
	lt = localtime(&clock);

	if (lt->tm_yday == gm->tm_yday)
		minswest = (gm->tm_hour - lt->tm_hour) * 60 +
			   (gm->tm_min - lt->tm_min);
	else if (lt->tm_yday > gm->tm_yday)
		minswest = (gm->tm_hour - (lt->tm_hour + 24)) * 60;
	else
		minswest = ((gm->tm_hour + 24) - lt->tm_hour) * 60;

	plus = (minswest > 0) ? '-' : '+';
	if (minswest < 0)
		minswest = -minswest;

	(void)sprintf(buf, "%s %s %d 19%02d -- %02d:%02d %c%02d:%02d",
		weekdays[lt->tm_wday], months[lt->tm_mon],lt->tm_mday,
		lt->tm_year, lt->tm_hour, lt->tm_min,
		plus, minswest/60, minswest%60);

	return buf;
}

/**
 ** myctime()
 **   This is like standard ctime()-function, but it zaps away
 **   the newline from the end of that string. Also, it takes
 **   the time value as parameter, instead of pointer to it.
 **   Note that it is necessary to copy the string to alternate
 **   buffer (who knows how ctime() implements it, maybe it statically
 **   has newline there and never 'refreshes' it -- zapping that
 **   might break things in other places...)
 **
 **/

char	*myctime(value)
time_t	value;
{
	static	char	buf[28];
	char	*p;

	(void)strcpy(buf, ctime(&value));
	if ((p = (char *)index(buf, '\n')) != NULL)
		*p = '\0';

	return buf;
}

/*
** check_registered_user is used to cancel message, if the
** originator is a server or not registered yet. In other
** words, passing this test, *MUST* guarantee that the
** sptr->user exists (not checked after this--let there
** be coredumps to catch bugs... this is intentional --msa ;)
**
** There is this nagging feeling... should this NOT_REGISTERED
** error really be sent to remote users? This happening means
** that remote servers have this user registered, althout this
** one has it not... Not really users fault... Perhaps this
** error message should be restricted to local clients and some
** other thing generated for remotes...
*/
int	check_registered_user(sptr)
aClient	*sptr;
{
	if (!IsRegisteredUser(sptr))
	    {
		sendto_one(sptr, err_str(ERR_NOTREGISTERED), me.name, "*");
		return -1;
	    }
	return 0;
}

/*
** check_registered user cancels message, if 'x' is not
** registered (e.g. we don't know yet whether a server
** or user)
*/
int	check_registered(sptr)
aClient	*sptr;
{
	if (!IsRegistered(sptr))
	    {
		sendto_one(sptr, err_str(ERR_NOTREGISTERED), me.name, "*");
		return -1;
	    }
	return 0;
}

/*
** get_client_name
**      Return the name of the client for various tracking and
**      admin purposes.
**
** NOTE:
**	Function return either a pointer to the structure (sptr) or
**	to internal buffer (nbuf). *NEVER* use the returned pointer
**	to modify what it points!!!
*/
char	*get_client_name(sptr, showip)
aClient *sptr;
int	showip;
{
	static	char	nbuf[HOSTLEN * 2 + USERLEN * 2 + 20];
		char	abuf[USERLEN + 10];
	char	*username;

	if (!MyConnect(sptr))
		return sptr->name;
	if (IsUnixSocket(sptr))
	    {
		if (showip)
			sprintf(nbuf, "%s[%s]", sptr->name, sptr->sockhost);
		else
			sprintf(nbuf, "%s[%s]", sptr->name, me.sockhost);
		return nbuf;
	    }
	*abuf = '\0';
	if (IsPerson(sptr))
		username = sptr->user->username;
	else
	    {
		if (sptr->user)
		    {
			username = sptr->userstr;
			sprintf(abuf, " [%s]", sptr->auth);
		    }
		else
			username = sptr->auth;
	    }
	if (showip)
		sprintf(nbuf, "%s[%s@%s]%s", sptr->name, username,
			inetntoa((char *)&sptr->ip), abuf);
	else
	    {
		if (mycmp(sptr->name, sptr->sockhost))
			sprintf(nbuf, "%s[%s@%s]%s", sptr->name, username,
				sptr->sockhost, abuf);
		else
			return sptr->name;
	    }
	return nbuf;
}

char	*get_client_host(cptr)
aClient	*cptr;
{
	static char nbuf[HOSTLEN * 2 + USERLEN + 5];

	if (!MyConnect(cptr))
		return cptr->name;
	if (!cptr->hostp)
		return get_client_name(cptr, FALSE);
	if (IsUnixSocket(cptr))
		(void) sprintf(nbuf, "%s[%s]", cptr->name, me.name);
	else
		(void)sprintf(nbuf, "%s[%-.*s@%-.*s]",
			cptr->name, USERLEN,
			(!(cptr->flags & FLAGS_GOTID)) ? "" : cptr->auth,
			HOSTLEN, cptr->hostp->h_name);
	return nbuf;
}

/*
 * Form sockhost such that if the host is of form user@host, only the host
 * portion is copied.
 */
void	get_sockhost(cptr, host)
aClient	*cptr;
char	*host;
{
	char	*s;
	if ((s = (char *)index(host, '@')))
		s++;
	else
		s = host;
	strncpyzt(cptr->sockhost, s, sizeof(cptr->sockhost));
}

/*
 * Return wildcard name of my server name according to given config entry
 * --Jto
 */
char	*myname_for_link(name, aconf)
char	*name;
aConfItem *aconf;
{
	static	char	namebuf[HOSTLEN];
	int	count = aconf->port;
	char	*start = name;

	if (count <= 0 || count > 5)
		return start;

	while (count-- && name)
	    {
		name++;
		name = (char *)index(name, '.');
	    }
	if (!name)
		return start;

	namebuf[0] = '*';
	(void)strncpy(&namebuf[1], name, HOSTLEN - 1);
	namebuf[HOSTLEN - 1] = '\0';

	return namebuf;
}

/*
** hide_servers_by_name
*/
int	hide_servers_by_name(name)
char	*name;
{
	aClient	*acptr;
	int	i, c = 0;

	for (i = fdserv.highest; i >= 0; i--)
	    {
		if (!(acptr = local[fdserv.fd[i]]))
			abort();
		if (name && !match(acptr->myname, name))
			acptr->flags |= FLAGS_HIDDEN, c++;
		else
			acptr->flags &= ~FLAGS_HIDDEN;
	    }
	return c;
}

/*
** exit_client
**	This is old "m_bye". Name  changed, because this is not a
**	protocol function, but a general server utility function.
**
**	This function exits a client of *any* type (user, server, etc)
**	from this server. Also, this generates all necessary prototol
**	messages that this exit may cause.
**
**   1) If the client is a local client, then this implicitly
**	exits all other clients depending on this connection (e.g.
**	remote clients having 'from'-field that points to this.
**
**   2) If the client is a remote client, then only this is exited.
**
** For convenience, this function returns a suitable value for
** m_funtion return value:
**
**	FLUSH_BUFFER	if (cptr == sptr)
**	0		if (cptr != sptr)
*/
int	exit_client(cptr, sptr, from, comment)
aClient *cptr;	/*
		** The local client originating the exit or NULL, if this
		** exit is generated by this server for internal reasons.
		** This will not get any of the generated messages.
		*/
aClient *sptr;	/* Client exiting */
aClient *from;	/* Client firing off this Exit, never NULL! */
char	*comment;	/* Reason for the exit */
{
	aClient	*acptr, *next, *tmp, *last;
	int	scount = 0, nscount = 0;
#ifdef	FNAME_USERLOG
	time_t	on_for;
# if !(defined(USE_SYSLOG) && defined(SYSLOG_USERS))
	char	linebuf[160];
	int	logfile;
# endif
#endif
	char	comment1[HOSTLEN + HOSTLEN + 2];

	if (!MyConnect(sptr))
		/* remote connection */
		goto myconnect_done;

	/* local connection */
	sptr->flags |= FLAGS_CLOSING;
#ifdef FNAME_USERLOG
	if (IsPerson(sptr))
	    {
		on_for = timeofday - sptr->firsttime;
# if defined(USE_SYSLOG) && defined(SYSLOG_USERS)
		syslog(LOG_NOTICE, "%s (%3d:%02d:%02d): %s@%s\n",
			myctime(sptr->firsttime),
			on_for / 3600, (on_for % 3600) / 60,
			on_for % 60,
			sptr->user->username, sptr->user->host);
# else
		/*
		 * stop NFS hangs...most systems should be able to open a
		 * file in 3 seconds. -avalon (curtesy of wumpus)
		 */
		(void)alarm(3);
		logfile = open(FNAME_USERLOG, O_WRONLY|O_APPEND);
		(void)alarm(0);
		/*
	 	 * This conditional makes the logfile active only after
		 * it's been created - thus logging can be turned off by
		 * removing the file.
		 */
		if (logfile >= 0)
		    {
			(void)sprintf(linebuf,
				"%s (%3d:%02d:%02d): %s@%s [%s]\n",
				myctime(sptr->firsttime),
				on_for / 3600, (on_for % 3600) / 60,
				on_for % 60,
				sptr->userstr, sptr->sockhost,
				sptr->auth);
			(void)alarm(3);
			(void)write(logfile, linebuf, strlen(linebuf));
			(void)alarm(0);
			(void)close(logfile);
		    }
# endif
	    }
#endif
	/*
	** *MUST* handle remote tokens for local connections *before*
	** close_connection call because close_connection will make
	** sptr->from NULL ..
	*/
	if (IsServer(sptr) && sptr->serv->rtoken > 0)
	    {
		aToken	*tk;

		if (sptr->from != sptr)
			abort();
		if (tk = find_token(sptr->serv->rtoken, sptr->from))
			remove_token(tk);
		else
			abort();
		sptr->serv->rtoken = -1;
	    }

	/*
	** *MUST* also remove local user from any channels before
	** close_connection call because MyConnect() doesn't work
	** after connection is closed!
	*/
	if (sptr->user)
	    {
		Link	*lp;

		if (sptr->user->channel)
			sendto_common_channels(sptr, ":%s QUIT :%s",
					       sptr->name, comment);
		while (lp = sptr->user->channel)
			remove_user_from_channel(sptr, lp->value.chptr);
	    }

	/*
	** send ERROR message just before closing the connection..
	*/
	if (sptr->fd >= 0)
	    {
		if (cptr != NULL && sptr != cptr)
			sendto_one(sptr, "ERROR :Closing Link: %s %s (%s)",
				   get_client_name(sptr,FALSE),
				   cptr->name, comment);
		else
			sendto_one(sptr, "ERROR :Closing Link: %s (%s)",
				   get_client_name(sptr,FALSE), comment);
	    }

	/*
	** Close the Client connection first and mark it
	** so that no messages are attempted to send to it.
	** (The following *must* make MyConnect(sptr) == FALSE!).
	** It also makes sptr->from == NULL, thus it's unnecessary
	** to test whether "sptr != acptr" in the following loops.
	*/
	close_connection(sptr);

myconnect_done:
	/*
	** Currently only server connections can have
	** depending remote clients..
	*/
	if (!IsServer(sptr))
	    {
		/*
		** non-server exiting
		*/
		if (!(sptr->flags & FLAGS_KILLED))
		    {
			char	*p;
			int	d, l = 0;

			for (d = 0, p = comment; *p && *p != ' '; p++)
				if (*p == '.')
					d++;
			if (*p && d)
			    {
				for (d = 0, ++p; *p && *p != ' '; p++)
					if (*p == '.')
						d++;
				if (!*p && d)
					l++;
			    }
			if (l)
			    {
				if (cptr == sptr || !IsV29(cptr))
				    {
					exit_one_client(cptr, sptr, from,
							sptr->name);
					return cptr == sptr ? FLUSH_BUFFER : 0;
				    }
				sptr->flags |= FLAGS_LOCK;
			    }
		    }
		exit_one_client(cptr, sptr, from, comment);
		return cptr == sptr ? FLUSH_BUFFER : 0;
	    }

	/*
	** Netsplit handling for servers - the following code will locally
	** QUIT all clients and SQUIT all servers behind this link..
	**
	** NOTE	There is no danger of 'cptr' being exited in the
	**	following loops as 'cptr' is a *local* client,
	**	all dependants are *remote* clients.
	*/

	/*
	** flush all queues first
	*/
	flush_connections(me.fd);
	/*
	** loop thru history in one big sweep putting
	** all clients from sptr offline
	*/
	off_history_serv(sptr->serv);
	/*
	** mark all local servers which cannot see
	** sptr hidden..
	*/
	hide_servers_by_name(sptr->name);

	/*
	** QUIT *all* NON-servers behind this link - should be effecient ;-)
	*/
	for (last = sptr, acptr = sptr->prev; acptr; acptr = next)
	    {
		next = acptr->prev;
		if (IsServer(acptr))
		    {
			for (tmp = sptr; tmp != acptr; tmp = tmp->prev)
				if (acptr->where == tmp)
					break;
			last = acptr;
			if (tmp == acptr)
				break;
			if (tmp->serv->servers <= 0)
				abort();
			/*
			** flush all queues
			*/
			flush_connections(me.fd);
			/*
			** loop thru history in one big sweep putting
			** all clients from this server offline
			*/
			off_history_serv(acptr->serv);
			/*
			** mark all local servers which cannot see
			** this server hidden..
			*/
			hide_servers_by_name(acptr->name);
			continue;
		    }
		/*
		** the comment - give out some useful information about
		** where the net broke. the first server is the server
		** this user was on, the second is the server's uplink.
		*/
		sprintf(comment1, "%s %s", acptr->where->name,
			acptr->where->where->name);
		/*
		** mark client as "split away"
		*/
		acptr->flags |= FLAGS_SPLIT;
		exit_one_client(acptr->from, acptr, &me, comment1);
		nscount++;
	    }

	flush_connections(me.fd); /* flush all queues */

	if (acptr && last != sptr)
		last = acptr->next;

	/*
	** SQUIT *all* servers behind this link
	** (the previous loop removed all non servers)
	*/
	for (acptr = last; acptr != sptr; acptr = next)
	    {
		next = acptr->next;
		if (!IsServer(acptr) || acptr->serv->clients ||
		    acptr->serv->servers)
			abort();
		/*
		** mark all local servers which cannot see
		** this server hidden..
		*/
		hide_servers_by_name(acptr->name);
		/*
		** the comment - give out some useful information about
		** where the net broke. the first server is the server
		** itself, the second is the server's uplink.
		*/
		sprintf(comment1, "%s %s", acptr->name, acptr->where->name);
		/*
		** mark server as "split away"
		*/
		acptr->flags |= FLAGS_SPLIT;
		exit_one_client(acptr->from, acptr, &me, comment1);
		scount++;
	    }

	sendto_ops("[%s] SQUIT %d servers - QUIT %d non-servers",
		    sptr->name, scount, nscount);

	/*
	** finally remove the server that split out..
	*/
	hide_servers_by_name(sptr->name);
	exit_one_client(cptr, sptr, from, comment);
	hide_servers_by_name(NULL);
	flush_connections(me.fd); /* flush all queues */
	return cptr == sptr ? FLUSH_BUFFER : 0;
}

/*
** Exit one client, local or remote. Assuming all dependants have
** been already removed, and socket closed for local client.
*/
static	void	exit_one_client(cptr, sptr, from, comment)
aClient *sptr;
aClient *cptr;
aClient *from;
char	*comment;
{
	aClient *acptr;
	int	i;
	Link	*lp;

	/*
	**  For a server or user quitting, propagage the information to
	**  other servers (except to the one where is came from (cptr))
	*/
	if (IsMe(sptr))
		abort(); /* ...must *never* exit self!! */
	else if (IsServer(sptr))
	    {
		if (sptr->flags & FLAGS_SPLIT)
			sendto_ops("SQUIT %s (%s)", sptr->name, comment);
		/*
		** SQUIT going "upstream". This is the remote
		** squit still hunting for the target. Use prefixed
		** form. "from" will be either the oper that issued
		** the squit or some server along the path that
		** didn't have this fix installed. --msa
		**
		** NOTE: sendto_serv_butone() *checks* FLAGS_HIDDEN
		*/
		sendto_serv_butone(cptr, ":%s SQUIT %s :%s",
				   from->name, sptr->name, comment);

		/*
		** free local and remote servertokens if any
		*/
		if (sptr->serv->rtoken > 0)
		    {
			aToken	*tk;

			if (!sptr->from)
				abort();
			if (tk = find_token(sptr->serv->rtoken, sptr->from))
				remove_token(tk);
			else
				abort();
			sptr->serv->rtoken = -1;
		    }
		if (sptr->serv->ltoken > 0)
		    {
			aToken	*tk;

			if (tk = find_token(sptr->serv->ltoken, NULL))
				remove_token(tk);
			else
				abort();
			sptr->serv->ltoken = -1;
		    }
	    }
	else if (!IsPerson(sptr))
		/* ...this test is *dubious*, would need
		** some thougth.. but for now it plugs a
		** nasty hole in the server... --msa
		*/
		; /* Nothing */
	else if (sptr->name[0]) /* ...just clean all others with QUIT... */
	    {
		if (sptr->flags & FLAGS_SPLIT)
		    {
			/*
			** this exit is generated by local
			** netsplit handler..
			*/
			add_lock(sptr->name);	/* lock name */
			/*
			** propagate QUIT to all hidden and v2.8 servers..
			** (except cptr)
			*/
			sendto_hidden_butone(cptr, ":%s QUIT :%s",
					     sptr->name, comment);
		    }
		else if (sptr->flags & FLAGS_KILLED)
			/*
			** this exit is generated from "m_kill", there
			** is no sense in sending the QUIT--KILL's have been
			** sent instead.
			*/
			add_lock(sptr->name);	/* lock name */
		else
		    {
			aLock	*lk;

			if (sptr->flags & FLAGS_LOCK)
				add_lock(sptr->name);	/* lock name */
			else if (lk = find_lock(sptr->name))
				remove_lock(lk);
			/*
			** propagate QUIT to all connected servers except cptr
			** (no servers should be hidden here)
			*/
			sendto_serv_butone(cptr, ":%s QUIT :%s",
					   sptr->name, comment);
		    }
		/*
		** If a person is on a channel, send a QUIT notice
		** to every client (person) on the same channel (so
		** that the client can show the "**signoff" message).
		** (Note: The notice is to the local clients *only*)
		*/
		if (sptr->user)
		    {
			if (sptr->user->channel)
				sendto_common_channels(sptr, ":%s QUIT :%s",
						       sptr->name, comment);
			while (lp = sptr->user->channel)
				remove_user_from_channel(sptr,lp->value.chptr);

			/* Clean up invitefield */
			while ((lp = sptr->user->invited))
				del_invite(sptr, lp->value.chptr);
				/* again, this is all that is needed */
		    }
	    }

	/* Remove sptr from the client list */
	if (sptr->name[0])
	    {
		aClient *ptr = hash_get(clientHash, sptr->name, 0);
		if (ptr == sptr)
			hash_del_last();
	    }
	remove_client(sptr);
	return;
}

void	initstats()
{
	bzero((char *)&ircst, sizeof(ircst));
}

void	tstats(cptr, name)
aClient	*cptr;
char	*name;
{
	aClient	*acptr;
	int	i;
	struct stats	*sp;
	struct	stats	tmp;

	sp = &tmp;
	bcopy((char *)ircstp, (char *)sp, sizeof(*sp));
	for (i = 0; i < MAXCONNECTIONS; i++)
	    {
		if (!(acptr = local[i]))
			continue;
		if (IsServer(acptr))
		    {
			sp->is_sbs += acptr->sendB;
			sp->is_sbr += acptr->receiveB;
			sp->is_sks += acptr->sendK;
			sp->is_skr += acptr->receiveK;
			sp->is_sti += timeofday - acptr->firsttime;
			sp->is_sv++;
			if (sp->is_sbs > 1023)
			    {
				sp->is_sks += (sp->is_sbs >> 10);
				sp->is_sbs &= 0x3ff;
			    }
			if (sp->is_sbr > 1023)
			    {
				sp->is_skr += (sp->is_sbr >> 10);
				sp->is_sbr &= 0x3ff;
			    }
		    }
		else if (IsClient(acptr))
		    {
			sp->is_cbs += acptr->sendB;
			sp->is_cbr += acptr->receiveB;
			sp->is_cks += acptr->sendK;
			sp->is_ckr += acptr->receiveK;
			sp->is_cti += timeofday - acptr->firsttime;
			sp->is_cl++;
			if (sp->is_cbs > 1023)
			    {
				sp->is_cks += (sp->is_cbs >> 10);
				sp->is_cbs &= 0x3ff;
			    }
			if (sp->is_cbr > 1023)
			    {
				sp->is_ckr += (sp->is_cbr >> 10);
				sp->is_cbr &= 0x3ff;
			    }
		    }
		else if (IsUnknown(acptr))
			sp->is_ni++;
	    }

	sendto_one(cptr, ":%s %d %s :accepts %u refused %u",
		   me.name, RPL_STATSDEBUG, name, sp->is_ac, sp->is_ref);
	sendto_one(cptr, ":%s %d %s :unknown commands %u prefixes %u",
		   me.name, RPL_STATSDEBUG, name, sp->is_unco, sp->is_unpf);
	sendto_one(cptr, ":%s %d %s :nick collisions %u unknown closes %u",
		   me.name, RPL_STATSDEBUG, name, sp->is_kill, sp->is_ni);
	sendto_one(cptr, ":%s %d %s :wrong direction %u empty %u",
		   me.name, RPL_STATSDEBUG, name, sp->is_wrdi, sp->is_empt);
	sendto_one(cptr, ":%s %d %s :numerics seen %u mode fakes %u",
		   me.name, RPL_STATSDEBUG, name, sp->is_num, sp->is_fake);
	sendto_one(cptr, ":%s %d %s :auth successes %u fails %u",
		   me.name, RPL_STATSDEBUG, name, sp->is_asuc, sp->is_abad);
	sendto_one(cptr, ":%s %d %s :local connections %u udp packets %u",
		   me.name, RPL_STATSDEBUG, name, sp->is_loc, sp->is_udp);
	sendto_one(cptr, ":%s %d %s :Client Server",
		   me.name, RPL_STATSDEBUG, name);
	sendto_one(cptr, ":%s %d %s :connected %u %u",
		   me.name, RPL_STATSDEBUG, name, sp->is_cl, sp->is_sv);
	sendto_one(cptr, ":%s %d %s :bytes sent %u.%uK %u.%uK",
		   me.name, RPL_STATSDEBUG, name,
		   sp->is_cks, sp->is_cbs, sp->is_sks, sp->is_sbs);
	sendto_one(cptr, ":%s %d %s :bytes recv %u.%uK %u.%uK",
		   me.name, RPL_STATSDEBUG, name,
		   sp->is_ckr, sp->is_cbr, sp->is_skr, sp->is_sbr);
	sendto_one(cptr, ":%s %d %s :time connected %u %u",
		   me.name, RPL_STATSDEBUG, name, sp->is_cti, sp->is_sti);
}
