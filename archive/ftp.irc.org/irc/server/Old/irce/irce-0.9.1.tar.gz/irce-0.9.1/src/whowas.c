/************************************************************************
 *   IRC - Internet Relay Chat, whowas.c
 *   Copyright (C) 1990 Markku Savela
 *   Portions Copyright (C) 1998 Ari Heikkinen
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#undef	WHOWAS_DEBUG

#include "struct.h"
#include "common.h"
#include "sys.h"
#include "numeric.h"
#include "whowas.h"
#include "h.h"

static	aName	*was = NULL;
static	int	ww_index = 0;
	int	ww_len = 512;

static	void	grow_history()
{
	aName	*wp;
	int	new_len;

	new_len = (int)((float)num_clients * 1.1);
	if (new_len <= ww_len)
		abort();
	was = (aName *) MyRealloc((char *)was, sizeof(*was) * new_len);
	for (; ww_len < new_len; ww_len++)
	    {
		wp = &was[ww_len];
		bzero((char *)wp, sizeof(*wp));
		wp->ww_online = NULL, wp->ww_onext = -1;
	    }
	sendto_ops("Whowas array grown.");
	writestate();
}

static	void	off_history_index(cptr, ind)
aClient	*cptr;
int	ind;
{
	aName	*wp, *prev = NULL;
	int	i, n = cptr->user->whowasind;

	while ((i = n) >= 0)
	    {
		wp = &was[i];
		if (wp->ww_online != cptr || (n = wp->ww_onext) >= ww_len)
			abort();
		if (i == ind)
		    {
			if (prev)
				prev->ww_onext = n;
			else
				cptr->user->whowasind = n;
			wp->ww_online = NULL, wp->ww_onext = -1;
#ifdef WHOWAS_DEBUG
			sendto_ops("OFF-IND i=%d (n=%d)", i, n);
#endif
			return;
		    }
		prev = wp;
	    }
	abort();
}

void	add_history(cptr, isoff)
aClient	*cptr;
int	isoff;
{
	aName	*wp = &was[ww_index];

	if (wp->ww_user)
		free_user(wp->ww_user);
	if (wp->ww_serv)
		free_server(wp->ww_serv);
	if (wp->ww_online)
		off_history_index(wp->ww_online, ww_index);
	else if (wp->ww_onext >= 0)
		abort();

	strncpyzt(wp->ww_nick, cptr->name, NICKLEN+1);
	strncpyzt(wp->ww_info, cptr->info, REALLEN+1);
	wp->ww_user = cptr->user;
	wp->ww_serv = cptr->where->serv;
	wp->ww_logout = timeofday;
	wp->ww_online = (!isoff && cptr->from != NULL) ? cptr : NULL;
	if (wp->ww_online)
	    {
#ifdef WHOWAS_DEBUG
		sendto_ops("hist: addind i=%d n=%d",
			   ww_index, cptr->user->whowasind);
#endif
		wp->ww_onext = cptr->user->whowasind;
		cptr->user->whowasind = ww_index;
	    }
	else
	    {
		if (cptr->user->whowasind >= 0)
			abort();
		wp->ww_onext = -1;
#ifdef WHOWAS_DEBUG
		sendto_ops("hist: adding %d (offline)", ww_index);
#endif
	    }
	wp->ww_user->refcnt++;
	wp->ww_serv->refcnt++;

	if (++ww_index >= ww_len && num_clients > ww_len)
		grow_history();
	if (ww_index >= ww_len)
		ww_index = 0;
}

/*
** get_history
**      Return the current client that was using the given
**      nickname within the timelimit. Returns NULL, if no
**      one found...
*/
aClient	*get_history(nick, timelimit)
char	*nick;
time_t	timelimit;
{
	aName	*wp, *wp2;

	wp = wp2 = &was[ww_index];
	timelimit = timeofday - timelimit;

	do {
		wp--;
		if (wp < was)
			wp = &was[ww_len - 1];
		if (wp->ww_logout < timelimit)
			break;
		if (!mycmp(nick, wp->ww_nick))
			return wp->ww_online;
	} while (wp != wp2);
	return NULL;
}

void	off_history_one(cptr)
aClient	*cptr;
{
	aName	*wp;
#ifdef WHOWAS_DEBUG
	aName	*wp2;
#endif
	int	i, n = cptr->user->whowasind;

	while ((i = n) >= 0)
	    {
		wp = &was[i];
		if (wp->ww_online != cptr || (n = wp->ww_onext) >= ww_len)
			abort();
		wp->ww_online = NULL, wp->ww_onext = -1;
#ifdef WHOWAS_DEBUG
		sendto_ops("OFF i=%d (n=%d)", i, n);
#endif
	    }
	cptr->user->whowasind = -1;

#ifdef WHOWAS_DEBUG
	for (wp = was, wp2 = &was[ww_len]; wp != wp2; wp++)
		if (wp->ww_online == cptr
		    || !wp->ww_online && wp->ww_onext >= 0)
			abort();
#endif
}

void	off_history_serv(serv)
aServer	*serv;
{
	aName	*wp, *wp2;

	for (wp = was, wp2 = &was[ww_len]; wp != wp2; wp++)
		if (wp->ww_serv == serv)
		    {
			if (wp->ww_online)
			    {
				wp->ww_online->user->whowasind = -1;
				wp->ww_online = NULL;
			    }
			wp->ww_onext = -1;
		    }
}

void	initwhowas()
{
	aName	*wp, *wp2;

	was = (aName *) MyMalloc(ww_len * sizeof(*was));
	for (wp = was, wp2 = &was[ww_len]; wp != wp2; wp++)
	    {
		bzero((char *)wp, sizeof(*wp));
		wp->ww_online = NULL, wp->ww_onext = -1;
	    }
}

/*
** m_whowas
**	parv[0] = sender prefix
**	parv[1] = nickname queried
*/
int	m_whowas(cptr, sptr, parc, parv)
aClient	*cptr, *sptr;
int	parc;
char	*parv[];
{
	aName	*wp, *wp2 = NULL;
	int	j = 0;
	anUser	*up = NULL;
	int	max = -1;
	char	*p, *nick, *s;

 	if (parc < 2)
	    {
		sendto_one(sptr, err_str(ERR_NONICKNAMEGIVEN),
			   me.name, parv[0]);
		return 0;
	    }
	if (parc > 2)
		max = atoi(parv[2]);
	if (parc > 3)
		if (hunt_server(cptr,sptr,":%s WHOWAS %s %s :%s", 3,parc,parv))
			return 0;

	for (s = parv[1]; (nick = strtoken(&p, s, ",")); s = NULL)
	    {
		wp = wp2 = &was[ww_index];

		do {
			wp--;
			if (wp < was)
				wp = &was[ww_len - 1];
			if (mycmp(nick, wp->ww_nick) == 0)
			    {
				up = wp->ww_user;
				sendto_one(sptr, rpl_str(RPL_WHOWASUSER),
					   me.name, parv[0], wp->ww_nick,
					   up->username,
					   up->host, wp->ww_info);
				sendto_one(sptr, rpl_str(RPL_WHOISSERVER),
					   me.name, parv[0], wp->ww_nick,
					   wp->ww_serv->name,
					   myctime(wp->ww_logout));
				if (up->away)
					sendto_one(sptr, rpl_str(RPL_AWAY),
						   me.name, parv[0],
						   wp->ww_nick, up->away);
				j++;
			    }
			if (max > 0 && j >= max)
				break;
		} while (wp != wp2);

		if (up == NULL)
			sendto_one(sptr, err_str(ERR_WASNOSUCHNICK),
				   me.name, parv[0], parv[1]);

		if (p)
			p[-1] = ',';
	    }
	sendto_one(sptr, rpl_str(RPL_ENDOFWHOWAS), me.name, parv[0], parv[1]);
	return 0;
    }


void	count_whowas_memory(wwu, wws, wwa, wwam)
int	*wwu, *wws, *wwa;
u_long	*wwam;
{
	aName	*tmp, *tmp2;
	anUser	*user;
	aServer	*serv;
	int	u = 0, s = 0, a = 0;
	u_long	am = 0;

	tmp = was, tmp2 = &was[ww_len];
	for (; tmp != tmp2; tmp++)
		if (!tmp->ww_online)
		    {
			if (user = tmp->ww_user)
				user->whowasvar = 0;
			if (serv = tmp->ww_serv)
				serv->whowasvar = 0;
		    }

	tmp = was, tmp2 = &was[ww_len];
	for (; tmp != tmp2; tmp++)
	    {
		if (tmp->ww_online)
			continue;
		if ((user = tmp->ww_user) && !user->whowasvar)
		    {
			u++;
			if (user->away)
			    {
				a++;
				am += strlen(user->away) + 1;
			    }
			user->whowasvar++;
		    }
		/*
		 * if serv->firstclient == NULL the client structure
		 * for this server has already been freed..
		 */
		if ((serv = tmp->ww_serv) && !serv->whowasvar
		    && serv->firstclient == NULL)
		    {
			s++;
			if (serv->user)
				abort();
			serv->whowasvar++;
		    }
	    }

	*wwu = u;
	*wws = s;
	*wwa = a;
	*wwam = am;
}
