/************************************************************************
 *   IRC - Internet Relay Chat, list.c
 *   Copyright (C) 1990 Jarkko Oikarinen and
 *                      University of Oulu, Finland
 *   Portions Copyright (C) 1998 Ari Heikkinen
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "struct.h"
#include "common.h"
#include "sys.h"
#include "h.h"
#include "numeric.h"
#include <arpa/inet.h>

void	free_link PROTO((Link *));
Link	*make_link PROTO(());
void	outofmemory();

static	struct	liststats {
	int	inuse;
} cloc, crem, users, servs, links, classs, aconfs;

static	aLock	*lastlock = NULL;
aLock	*firstlock = NULL;
int	num_locks = 0;

static	aToken	*lasttoken = NULL;
aToken	*firsttoken = NULL;
int	num_tokens = 0, num_ltokens = 0, num_rtokens = 0;
int	highest_ltoken = 0;

aToken	*freeltokens = NULL;

int	num_clients = 0;

void	initlists()
{
	bzero((char *)&cloc, sizeof(cloc));
	bzero((char *)&crem, sizeof(crem));
	bzero((char *)&users, sizeof(users));
	bzero((char *)&servs, sizeof(servs));
	bzero((char *)&links, sizeof(links));
	bzero((char *)&classs, sizeof(classs));
	bzero((char *)&aconfs, sizeof(aconfs));
}

void	outofmemory()
{
	Debug((DEBUG_FATAL, "Out of memory: restarting server..."));
	restart("Out of Memory");
}

/*
** Create a new aClient structure and set it to initial state.
**
**	from == NULL,	create local client (a client connected
**			to a socket).
**
**	from,	create remote client (behind a socket
**			associated with the client defined by
**			'from'). ('from' is a local client!!).
**
**	where,  a server this client is connected to
*/
aClient	*make_client(from, where)
aClient	*from;
aClient	*where;
{
	aClient	*cptr;
	int	size = CLIENT_REMOTE_SIZE;

	if (!from)
		size = CLIENT_LOCAL_SIZE;

	cptr = (aClient *)MyMalloc(size);
	bzero((char *)cptr, size);

	if (size == CLIENT_LOCAL_SIZE)
		cloc.inuse++;
	else
		crem.inuse++;

	cptr->next = cptr->prev = cptr->hnext = NULL;
	cptr->from = from ? from : cptr; /* 'from' of local client is self! */
	cptr->where = where;
	cptr->user = NULL;
	cptr->serv = NULL;
	cptr->fd = -1;
	cptr->status = STAT_UNKNOWN;
	if (size == CLIENT_LOCAL_SIZE)
	    {
		(void)strcpy(cptr->userstr, "<none>");
		cptr->firsttime = cptr->lastread = timeofday;
		cptr->lastact = cptr->since = timeofday;
		cptr->confs = NULL;
		cptr->authfd = -1;
	    }
	return cptr;
}

void	free_client(cptr)
aClient	*cptr;
{
	if (cptr->fd == -2)
		cloc.inuse--;
	else
		crem.inuse--;
	MyFree((char *)cptr);
}

/*
** 'make_user' add's an User information block to a client
** if it was not previously allocated.
*/
anUser	*make_user(cptr)
aClient *cptr;
{
	anUser	*user;

	user = cptr->user;
	if (!user)
	    {
		user = (anUser *)MyMalloc(sizeof(*user));
		bzero((char *)user, sizeof(*user));
		users.inuse++;
		user->refcnt = 1;
		user->joined = 0;
		user->away = NULL;
		user->channel = NULL;
		user->invited = NULL;
		user->whowasind = -1;
		cptr->user = user;
	    }
	return user;
}

aServer	*make_server(cptr)
aClient	*cptr;
{
	aServer	*serv = cptr->serv;

	if (!serv)
	    {
		serv = (aServer *)MyMalloc(sizeof(*serv));
		bzero((char *)serv, sizeof(*serv));
		servs.inuse++;
		serv->refcnt = 1;
		serv->ltoken = 0;
		serv->rtoken = 0;
		serv->clients = 0;
		serv->servers = 0;
		serv->firstclient = cptr;
		serv->user = NULL;
		cptr->serv = serv;
	    }
	strncpyzt(serv->name, cptr->name, HOSTLEN+1);
	return cptr->serv;
}

/*
** free_user
**	Decrease user reference count by one and realease block,
**	if count reaches 0
*/
void	free_user(user)
anUser	*user;
{
	if (--user->refcnt < 0)
		abort();
	else if (!user->refcnt)
	    {
		if (user->away)
			MyFree((char *)user->away);
		/*
		 * sanity check
		 */
		if (user->joined || user->invited || user->channel)
			abort();
		MyFree((char *)user);
		users.inuse--;
	    }
}

/*
** free_server
**	Decrease server reference count by one and realease block,
**	if count reaches 0
*/
void	free_server(serv)
aServer	*serv;
{
	if (--serv->refcnt < 0)
		abort();
	else if (!serv->refcnt)
	    {
		/*
		 * sanity check
		 */
		if (serv->clients || serv->servers)
			abort();
		MyFree((char *)serv);
		servs.inuse--;
	    }
}

/*
 * taken the code from ExitOneClient() for this and placed it here.
 * - avalon
 */
void	remove_client(cptr)
aClient	*cptr;
{
	del_client_from_list(cptr);
	if (IsPerson(cptr) && cptr->user)
	    {
		if (!(cptr->flags & FLAGS_SPLIT))
			off_history_one(cptr);
		add_history(cptr, TRUE);
	    }
	if (cptr->user)
		(void)free_user(cptr->user);
	if (cptr->serv)
	    {
		if (cptr->serv->user)
			free_user(cptr->serv->user);
		cptr->serv->user = NULL;
		cptr->serv->firstclient = NULL;
		free_server(cptr->serv);
	    }
	(void)free_client(cptr);
	return;
}

/*
 * although only a small routine, it appears in a number of places
 * as a collection of a few lines...functions like this *should* be
 * in this file, shouldnt they ?  after all, this is list.c, isnt it ?
 * -avalon
 */
void	add_client_to_list(cptr)
aClient	*cptr;
{
	aClient	*put;

	/*
	** sanity check
	*/
	if (cptr == &me || !cptr->where || cptr->where == cptr)
		abort(); /* abort */
	if (IsServer(cptr))
	    {
		aServer	*serv = cptr->where->serv;
		put = serv->firstclient;
		serv->servers++;
	    }
	else
	    {
		put = cptr->where;
		if (put->serv->firstclient == put)
			put->serv->firstclient = cptr;
		put->serv->clients++;
	    }
	cptr->next = put;
	cptr->prev = put->prev;
	if (put->prev)
		put->prev->next = cptr;
	else
		client = cptr;
	if (cptr->next)
		cptr->next->prev = cptr;
	else
		/*
		** "me" *must* be the last client in list but it wasn't..
		*/
		abort(); /* abort */
	num_clients++;
	return;
}

void	del_client_from_list(cptr)
aClient	*cptr;
{
	if (cptr->prev)
		cptr->prev->next = cptr->next;
	else
	    {
		client = cptr->next;
		client->prev = NULL;
	    }
	if (cptr->next)
		cptr->next->prev = cptr->prev;
	else
		/*
		** "me" *must* be the last client in list but it wasn't..
		*/
		abort(); /* abort */
	if (IsServer(cptr))
	    {
		aServer	*serv = cptr->where->serv;
		serv->servers--;
		if (serv->servers < 0)
			abort();
	    }
	else
	    {
		aServer	*serv = cptr->where->serv;
		serv->clients--;
		if (serv->clients < 0)
			abort();
		else if (!serv->clients)
			serv->firstclient = cptr->where;
		else if (serv->firstclient == cptr)
			serv->firstclient = cptr->next;
	    }
	num_clients--;
}

static	void	add_lock_to_list(lk)
aLock	*lk;
{
	if (lastlock)
		lastlock->next = lk;
	else
	    {
		if (firstlock)
			abort();
		firstlock = lk;
	    }
	lk->prev = lastlock;
	lk->next = NULL;
	lastlock = lk;
	num_locks++;
}

static	void	remove_lock_from_list(lk)
aLock	*lk;
{
	if (lk->prev)
		lk->prev->next = lk->next;
	else
	    {
		firstlock = lk->next;
		if (firstlock)
			firstlock->prev = NULL;
	    }
	if (lk->next)
		lk->next->prev = lk->prev;
	else
	    {
		lastlock = lk->prev;
		if (lastlock)
			lastlock->next = NULL;
	    }
	lk->prev = lk->next = NULL;
	num_locks--;
	/* sanity checks */
	if (firstlock && !lastlock || !firstlock && lastlock ||
	    firstlock && lastlock && num_locks <= 0 ||
	    !firstlock && !lastlock && num_locks)
		abort();
}

static	void	add_token_to_list(tk)
aToken	*tk;
{
	if (lasttoken)
		lasttoken->next = tk;
	else
	    {
		if (firsttoken)
			abort();
		firsttoken = tk;
	    }
	tk->prev = lasttoken;
	tk->next = NULL;
	lasttoken = tk;
	if (tk->from)
		num_rtokens++;
	else
		num_ltokens++;
	num_tokens++;
}

static	void	remove_token_from_list(tk)
aToken	*tk;
{
	if (tk->prev)
		tk->prev->next = tk->next;
	else
	    {
		firsttoken = tk->next;
		if (firsttoken)
			firsttoken->prev = NULL;
	    }
	if (tk->next)
		tk->next->prev = tk->prev;
	else
	    {
		lasttoken = tk->prev;
		if (lasttoken)
			lasttoken->next = NULL;
	    }
	tk->prev = tk->next = NULL;
	if (tk->from)
		num_rtokens--;
	else
		num_ltokens--;
	num_tokens--;
	/* sanity checks */
	if (firsttoken && !lasttoken || !firsttoken && lasttoken ||
	    firsttoken && lasttoken && num_tokens <= 0 ||
	    !firsttoken && !lasttoken && num_tokens)
		abort();
}

void	add_lock(char *str)
{
	aLock	*lk;

	if (lk = find_lock(str))
	    {
		/*
		** found existing lock, move it to the end
		** of the list..
		*/
		remove_lock_from_list(lk);
		add_lock_to_list(lk);
/*
		sendto_ops("Updating existing lock [%s]", lk->lkname);
*/
	    }
	else
	    {
		/*
		** no existing lock found, create a new lock..
		*/
		lk = (aLock *)MyMalloc(sizeof(aLock));
		lk->prev = lk->next = lk->hnext = NULL;
		strncpyzt(lk->lkname, str, sizeof(lk->lkname));
		add_lock_to_list(lk);
		(void)add_to_lock_hash_table(lk->lkname, lk);
/*
		sendto_ops("Created new lock [%s]", lk->lkname);
*/
	    }
	/*
	** update lock release time
	*/
	lk->release = timeofday + LOCKSECONDS;
	if (firstlock == lastlock)
		nextlockrelease = firstlock->release + 20;
}

void	remove_lock(lk)
aLock	*lk;
{
	remove_lock_from_list(lk);
	(void)del_from_lock_hash_table(lk->lkname, lk);
/*
	sendto_ops("Lock released [%s]", lk->lkname);
*/
	MyFree(lk);
}

int	add_token(token, cptr, from)
int	token;
aClient	*cptr, *from;
{
	aToken	*tk;

	if (tk = find_token(token, from))
		/*
		** found an existing token for "from" - this is an error
		** since tokens are unique to each link
		*/
		return -1;

	/*
	** if we're adding local tokens make sure it's the first free one ;-)
	*/
	if (!from)
	    {
		if (freeltokens)
		    {
			if (token != freeltokens->token)
				abort();
		    }
		else if (token != highest_ltoken + 1)
			abort();
	    }

	if (!from && freeltokens)
	    {
		tk = freeltokens;
		freeltokens = freeltokens->next;
	    }
	else
		tk = (aToken *)MyMalloc(sizeof(aToken));

	tk->prev = tk->next = tk->hnext = NULL;
	tk->token = token;
	tk->cptr = cptr;
	tk->from = from;
	add_token_to_list(tk);
	(void)add_to_token_hash_table(tk->token, tk);
	if (!from && token > highest_ltoken)
		highest_ltoken = token;
	return 0;
}

void	remove_token(tk)
aToken	*tk;
{
	/* sanity check */
	if (highest_ltoken <= 0)
		abort();
	remove_token_from_list(tk);
	(void)del_from_token_hash_table(tk->token, tk);
	if (!tk->from && tk->token == highest_ltoken)
		/* search for previous (highest) local token */
		while (--highest_ltoken && !find_token(highest_ltoken, NULL))
			;
	if (tk->from)
		MyFree(tk);
	else
	    {
		tk->next = freeltokens;
		freeltokens = tk;
	    }
}

time_t	release_locks(curtime)
time_t	curtime;
{
	while (firstlock && firstlock->release <= curtime)
		remove_lock(firstlock);
	return firstlock ? firstlock->release + 20 : 0;
}

aLock	*find_lock(str)
char	*str;
{
	return hash_find_lock(str, NULL);
}

aToken	*find_token(token, from)
int	token;
aClient	*from;
{
	return hash_find_token(token, from, NULL);
}

aClient	*find_token_client(token, from)
int	token;
aClient	*from;
{
	aToken	*tk;
	tk = hash_find_token(token, from, NULL);
	return tk ? tk->cptr : NULL;
}

int	next_local_token()
{
	return freeltokens ? freeltokens->token : highest_ltoken + 1;
}

/*
 * Look for ptr (client) in the linked listed pointed to by link.
 */
Link	*find_user_link(lp, ptr)
Link	*lp;
aClient *ptr;
{
	for (; lp; lp = lp->next)
		if (lp->value.cptr == ptr)
			return lp;
	return NULL;
}

/*
 * Look for ptr (channel) in the linked listed pointed to by link.
 */
Link	*find_channel_link(lp, ptr)
Link	*lp;
aChannel *ptr;
{
	for (; lp; lp = lp->next)
		if (lp->value.chptr == ptr)
			return lp;
	return NULL;
}

Link	*make_link()
{
	Link	*lp;

	lp = (Link *)MyMalloc(sizeof(Link));
	links.inuse++;
	return lp;
}

void	free_link(lp)
Link	*lp;
{
	MyFree((char *)lp);
	links.inuse--;
}


aClass	*make_class()
{
	aClass	*tmp;

	tmp = (aClass *)MyMalloc(sizeof(aClass));
	classs.inuse++;
	return tmp;
}

void	free_class(tmp)
aClass	*tmp;
{
	MyFree((char *)tmp);
	classs.inuse--;
}

aConfItem	*make_conf()
{
	aConfItem *aconf;

	aconf = (struct ConfItem *)MyMalloc(sizeof(aConfItem));
	aconfs.inuse++;
	bzero((char *)&aconf->ipnum, sizeof(struct in_addr));
	aconf->next = NULL;
	aconf->host = aconf->passwd = aconf->name = NULL;
	aconf->status = CONF_ILLEGAL;
	aconf->flags = 0;
	aconf->clients = 0;
	aconf->port = 0;
	aconf->hold = 0;
	Class(aconf) = 0;
	return (aconf);
}

void	delist_conf(aconf)
aConfItem	*aconf;
{
	if (aconf == conf)
		conf = conf->next;
	else
	    {
		aConfItem	*bconf;

		for (bconf = conf; aconf != bconf->next; bconf = bconf->next)
			;
		bconf->next = aconf->next;
	    }
	aconf->next = NULL;
}

void	free_conf(aconf)
aConfItem *aconf;
{
	del_queries((char *)aconf);
	MyFree(aconf->host);
	if (aconf->passwd)
		bzero(aconf->passwd, strlen(aconf->passwd));
	MyFree(aconf->passwd);
	MyFree(aconf->name);
	MyFree((char *)aconf);
	aconfs.inuse--;
	return;
}

void	send_listinfo(cptr, name)
aClient	*cptr;
char	*name;
{
	int	inuse = 0, mem = 0, tmp = 0;

	sendto_one(cptr, ":%s %d %s :Local: inuse: %d(%d)",
		   me.name, RPL_STATSDEBUG, name, inuse += cloc.inuse,
		   tmp = cloc.inuse * CLIENT_LOCAL_SIZE);
	mem += tmp;
	sendto_one(cptr, ":%s %d %s :Remote: inuse: %d(%d)",
		   me.name, RPL_STATSDEBUG, name,
		   crem.inuse, tmp = crem.inuse * CLIENT_REMOTE_SIZE);
	mem += tmp;
	inuse += crem.inuse;
	sendto_one(cptr, ":%s %d %s :Users: inuse: %d(%d)",
		   me.name, RPL_STATSDEBUG, name, users.inuse,
		   tmp = users.inuse * sizeof(anUser));
	mem += tmp;
	inuse += users.inuse,
	sendto_one(cptr, ":%s %d %s :Servs: inuse: %d(%d)",
		   me.name, RPL_STATSDEBUG, name, servs.inuse,
		   tmp = servs.inuse * sizeof(aServer));
	mem += tmp;
	inuse += servs.inuse,
	sendto_one(cptr, ":%s %d %s :Links: inuse: %d(%d)",
		   me.name, RPL_STATSDEBUG, name, links.inuse,
		   tmp = links.inuse * sizeof(Link));
	mem += tmp;
	inuse += links.inuse,
	sendto_one(cptr, ":%s %d %s :Classes: inuse: %d(%d)",
		   me.name, RPL_STATSDEBUG, name, classs.inuse,
		   tmp = classs.inuse * sizeof(aClass));
	mem += tmp;
	inuse += classs.inuse,
	sendto_one(cptr, ":%s %d %s :Confs: inuse: %d(%d)",
		   me.name, RPL_STATSDEBUG, name, aconfs.inuse,
		   tmp = aconfs.inuse * sizeof(aConfItem));
	mem += tmp;
	inuse += aconfs.inuse,
	sendto_one(cptr, ":%s %d %s :Totals: inuse %d %d",
		   me.name, RPL_STATSDEBUG, name, inuse, mem);
}

int	add_fd(fd, ary)
int	fd;
FdAry	*ary;
{
	if (fd < 0 || ary->fd_ind[fd] >= 0)
		return -1;
	ary->fd[++ary->highest] = fd;
	ary->fd_ind[fd] = ary->highest;
	return 0;
}

int	del_fd(fd, ary)
int	fd;
FdAry	*ary;
{
	int	rfd, rind;

	if (fd < 0 || ary->fd_ind[fd] < 0)
		return -1;
	rind = ary->fd_ind[fd];
	ary->fd_ind[fd] = -1;
	if (rind != ary->highest)
	    {
		rfd = ary->fd[ary->highest];
		ary->fd[rind] = rfd;
		ary->fd_ind[rfd] = rind;
	    }
	ary->fd[ary->highest--] = -1;
	return 0;
}

int	count_user_local(cptr, chku)
aClient	*cptr;
int	chku;
{
	aClient	*tmp;
	int	i, cnt = 0;

	if (!MyConnect(cptr) || !cptr->user)
		return 0;

	for (i = fduser.highest; i >= 0; i--)
	    {
		if (!(tmp = local[fduser.fd[i]]))
			abort();
		if (!tmp->user)
			abort();
		if (bcmp(&tmp->ip, &cptr->ip, sizeof(cptr->ip)))
			continue;
		if (chku && mycmp(cptr->user->username, tmp->user->username))
			continue;
		cnt++;
	    }
	return cnt;
}

int	count_user_global(cptr, chku)
aClient	*cptr;
int	chku;
{
	aClient	*tmp;
	char	*addr;
	int	cnt = 0;

	if (!MyConnect(cptr) || !cptr->user)
		return 0;

	addr = inet_ntoa(cptr->ip);

	for (tmp = client; tmp; tmp = tmp->next)
	    {
		if (!tmp->user)
			continue;
		if (mycmp(cptr->user->host, tmp->user->host)
		    && mycmp(addr, tmp->user->host))
			continue;
		if (chku && mycmp(cptr->user->username, tmp->user->username))
			continue;
		cnt++;
	    }
	return cnt;
}
