/************************************************************************
 *   IRC - Internet Relay Chat, s_debug.c
 *   Copyright (C) 1990 Jarkko Oikarinen and
 *                      University of Oulu, Computing Center
 *   Portions Copyright (C) 1998 Ari Heikkinen
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "struct.h"
/*
 * Option string.  Must be before #ifdef DEBUGMODE.
 */
char	serveropts[] = {
'A',
#ifdef	CHROOTDIR
'c',
#endif
#ifdef	CMDLINE_CONFIG
'C',
#endif
#ifdef	DO_ID
'd',
#endif
#ifdef	DEBUGMODE
'D',
#endif
#ifdef	LOCOP_REHASH
'e',
#endif
#ifdef	OPER_REHASH
'E',
#endif
#ifdef	NO_FORGED_USERNAMES
'F',
#endif
#ifdef	HUB
'H',
#endif
#ifdef	SHOW_INVISIBLE_LUSERS
'i',
#endif
#ifndef	NO_DEFAULT_INVISIBLE
'I',
#endif
#ifdef	OPER_KILL
# ifdef  LOCAL_KILL_ONLY
'k',
# else
'K',
# endif
#endif
#ifdef	LEAST_IDLE
'L',
#endif
#ifdef	M4_PREPROC
'm',
#endif
#ifdef	IDLE_FROM_MSG
'M',
#endif
#ifdef	CRYPT_OPER_PASSWORD
'p',
#endif
#ifdef	CRYPT_LINK_PASSWORD
'P',
#endif
#ifdef	LOCOP_RESTART
'r',
#endif
#ifdef	OPER_RESTART
'R',
#endif
#ifdef	ENABLE_SUMMON
'S',
#endif
#ifdef	NO_DEFAULT_SECRET
's',
#endif
#ifdef	OPER_REMOTE
't',
#endif
#ifdef	IRCII_KLUDGE
'u',
#endif
#ifdef	ENABLE_USERS
'U',
#endif
#ifdef	UNIXPORT
'X',
#endif
#ifdef	USE_SYSLOG
'Y',
#endif
'8',
'\0'
};

#include "numeric.h"
#include "common.h"
#include "sys.h"
#include "whowas.h"
#ifdef HAVE_SYS_FILEH
# include <sys/file.h>
#endif
#ifdef HAVE_FCNTLH
# include <fcntl.h>
#endif
#ifdef HPUX
# include <sys/syscall.h>
# define getrusage(a,b) syscall(SYS_GETRUSAGE, a, b)
#endif
#ifdef HAVE_GETRUSAGE
# ifdef HAVE_SYS_TIMEH
#  include <sys/time.h>
# endif
# ifdef HAVE_SYS_RESOURCEH
#  include <sys/resource.h>
# endif
# ifdef HAVE_SYS_RUSAGEH
#  include <sys/rusage.h>
# endif
#else
# ifdef HAVE_SYS_TIMES
#  include <sys/times.h>
# endif
#endif
#ifdef HAVE_UNISTDH
# include <unistd.h>
#endif
#include "h.h"

#ifndef ssize_t
#define ssize_t u_int
#endif

#ifdef DEBUGMODE
static	char	debugbuf[1024];

#ifndef	USE_VARARGS
/*VARARGS2*/
void	debug(level, form, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
int	level;
char	*form, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8, *p9, *p10;
{
#else
void	debug(level, form, va_alist)
int	level;
char	*form;
va_dcl
{
	va_list	vl;

	va_start(vl);
#endif
	int	err = errno;

#ifdef	USE_SYSLOG
	if (level == DEBUG_ERROR)
		syslog(LOG_ERR, form, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10);
#endif
	if ((debuglevel >= 0) && (level <= debuglevel))
	    {
#ifndef	USE_VARARGS
		(void)sprintf(debugbuf, form,
				p1, p2, p3, p4, p5, p6, p7, p8, p9, p10);
#else
		(void)vsprintf(debugbuf, form, vl);
#endif
		if (local[2])
		    {
			local[2]->sendM++;
			local[2]->sendB += strlen(debugbuf);
		    }
		(void)fprintf(stderr, "%s", debugbuf);
		(void)fputc('\n', stderr);
	    }
	errno = err;
}
#endif

/*
 * This is part of the STATS replies. There is no offical numeric for this
 * since this isnt an official command, in much the same way as HASH isnt.
 * It is also possible that some systems wont support this call or have
 * different field names for "struct rusage".
 * -avalon
 */
void	send_usage(cptr, nick)
aClient *cptr;
char	*nick;
{
	double	dsecs_u, dsecs_s, dsecs;
	int	rup = timeofday - me.since + 1;
#ifdef _SC_CLK_TCK
	int	hzz = (int)sysconf(_SC_CLK_TCK);
#else
# ifdef CLK_TCK
	int	hzz = CLK_TCK;
# else
#  ifdef hz
	int	hzz = hz;
#  else
#   ifdef HZ
	int	hzz = HZ;
#   else
	int	hzz = 1;
#   endif
#  endif
# endif
#endif

#ifdef HAVE_GETRUSAGE
	struct	rusage	rus;

	if (getrusage(RUSAGE_SELF, &rus) == -1)
	    {
		sendto_one(cptr,":%s NOTICE %s :Getruseage error: %s.",
			   me.name, nick, strerror(errno));
		return;
	    }
	dsecs_u = (double)rus.ru_utime.tv_sec +
		  (double)rus.ru_utime.tv_usec / 1000000;
	dsecs_s = (double)rus.ru_stime.tv_sec +
		  (double)rus.ru_stime.tv_usec / 1000000;
	dsecs = dsecs_u + dsecs_s;

	sendto_one(cptr,
		   ":%s %d %s :CPU secs %.3f user %.3f system %.3f",
		   me.name, RPL_STATSDEBUG, nick, dsecs, dsecs_u, dsecs_s);
	sendto_one(cptr,
		   ":%s %d %s :CPU average %.2f%% user %.2f%% system %.2f%%",
		   me.name, RPL_STATSDEBUG, nick, dsecs / (double)rup * 100,
		   dsecs_u / (double)rup * 100, dsecs_s / (double)rup * 100);
	sendto_one(cptr, ":%s %d %s :RSS %d ShMem %d Data %d Stack %d",
		   me.name, RPL_STATSDEBUG, nick, rus.ru_maxrss,
		   rus.ru_ixrss / (rup * hzz), rus.ru_idrss / (rup * hzz),
		   rus.ru_isrss / (rup * hzz));
	sendto_one(cptr, ":%s %d %s :Swaps %d Reclaims %d Faults %d",
		   me.name, RPL_STATSDEBUG, nick, rus.ru_nswap,
		   rus.ru_minflt, rus.ru_majflt);
	sendto_one(cptr, ":%s %d %s :Block in %d out %d",
		   me.name, RPL_STATSDEBUG, nick, rus.ru_inblock,
		   rus.ru_oublock);
	sendto_one(cptr, ":%s %d %s :Msg Rcv %d Send %d",
		   me.name, RPL_STATSDEBUG, nick, rus.ru_msgrcv, rus.ru_msgsnd);
	sendto_one(cptr, ":%s %d %s :Signals %d Context Vol. %d Invol %d",
		   me.name, RPL_STATSDEBUG, nick, rus.ru_nsignals,
		   rus.ru_nvcsw, rus.ru_nivcsw);
#else
# ifdef HAVE_TIMES
	struct	tms	tms;

	if (times(&tms) == -1)
	    {
		sendto_one(cptr,":%s %d %s :times(2) error: %s.",
			   me.name, RPL_STATSDEBUG, nick, strerror(errno));
		return;
	    }
	dsecs_u = (double)tms.tms_utime / (double)hzz;
	dsecs_s = (double)tms.tms_stime / (double)hzz;
	dsecs = dsecs_u + dsecs_s;
	sendto_one(cptr,
		   ":%s %d %s :CPU secs %.3f user %.3f system %.3f",
		   me.name, RPL_STATSDEBUG, nick, dsecs, dsecs_u, dsecs_s);
	sendto_one(cptr,
		   ":%s %d %s :CPU average %.2f%% user %.2f%% system %.2f%%",
		   me.name, RPL_STATSDEBUG, nick, dsecs / (double)rup * 100,
		   dsecs_u / (double)rup * 100, dsecs_s / (double)rup * 100);
# endif
#endif
	sendto_one(cptr, ":%s %d %s :Reads %d Writes %d",
		   me.name, RPL_STATSDEBUG, nick, readcalls, writecalls);
	sendto_one(cptr,
		   ":%s %d %s :Writes:  <0=%d 0=%d <16=%d <32=%d <64=%d",
		   me.name, RPL_STATSDEBUG, nick,
		   writeb[0], writeb[1], writeb[2], writeb[3], writeb[4]);
	sendto_one(cptr,
		   ":%s %d %s :<128=%d <256=%d <512=%d <1024=%d >1024=%d",
		   me.name, RPL_STATSDEBUG, nick,
		   writeb[5], writeb[6], writeb[7], writeb[8], writeb[9]);
	return;
}

void	send_hash_usage(cptr, nick)
aClient	*cptr;
char	*nick;
{
	int	clmin = 0,	/* client hash min. chain length */
		clmax = 0,	/* client hash max. chain length */
		chmin = 0,	/* channel hash min. chain length */
		chmax = 0,	/* channel hash max. chain length */
		lkmin = 0,	/* lock hash min. chain length */
		lkmax = 0,	/* lock hash max. chain length */
		tkmin = 0,	/* token hash min. chain length */
		tkmax = 0;	/* token hash max. chain length */

	get_hash_stats(&clmin, &clmax, &chmin, &chmax,
		       &lkmin, &lkmax, &tkmin, &tkmax);

	sendto_one(cptr,
		   ":%s %d %s :Hash min/max: cl %d/%d ch %d/%d lk %d/%d"
		   " tk %d/%d",
		   me.name, RPL_STATSDEBUG, nick, clmin, clmax, chmin, chmax,
		   lkmin, lkmax, tkmin, tkmax);
	sendto_one(cptr, ":%s %d %s :Hash hits: cl %d ch %d lk %d tk %d",
		   me.name, RPL_STATSDEBUG, nick,
		   clientHashHits, channelHashHits, lockHashHits,
		   tokenHashHits);
	sendto_one(cptr, ":%s %d %s :Hash miss: cl %d ch %d lk %d tk %d",
		   me.name, RPL_STATSDEBUG, nick,
		   clientHashMiss, channelHashMiss, lockHashMiss,
		   tokenHashMiss);
}

void	count_memory(cptr, nick)
aClient	*cptr;
char	*nick;
{
	extern	aChannel	*channel;
	extern	aClass		*classes;
	extern	aConfItem	*conf;

	aClient *acptr;
	Link *link;
	aLock *lock;
	aToken *token;
	aChannel *chptr;
	aConfItem *aconf;
	aClass *cltmp;

	int	lc = 0,		/* local clients */
		ch = 0,		/* channels */
		lk = 0,		/* locks */
		ltk = 0,	/* local tokens */
		rtk = 0,	/* remote tokens */
		ftk = 0,	/* free tokens */
		lcc = 0,	/* local client conf links */
		rc = 0,		/* remote clients */
		us = 0,		/* user structs */
		chlu = 0,	/* channel local users */
		chu = 0,	/* channel users */
		chi = 0,	/* channel invites */
		chb = 0,	/* channel bans */
		wwu = 0,	/* whowas users */
		wws = 0,	/* whowas servers */
		cl = 0,		/* classes */
		co = 0;		/* conf lines */

	int	usi = 0,	/* users invited */
		usc = 0,	/* users in channels */
		aw = 0,		/* aways set */
		wwa = 0;	/* whowas aways */

	u_long	chm = 0,	/* memory used by channels */
		chbm = 0,	/* memory used by channel bans */
		lcm = 0,	/* memory used by local clients */
		rcm = 0,	/* memory used by remote clients */
		awm = 0,	/* memory used by aways */
		lkm = 0,	/* memory used by locks */
		ltkm = 0,	/* memory used by local tokens */
		rtkm = 0,	/* memory used by remote tokens */
		ftkm = 0,	/* memory used by free tokens */
		wwam = 0,	/* whowas away memory used */
		wwm = 0,	/* whowas array memory used */
		com = 0,	/* memory used by conf lines */
		db = 0,		/* memory used by dbufs */
		fdb = 0,	/* memory used by free dbufs */
		rm = 0,		/* res memory used */
		totcl = 0,
		totch = 0,
		totww = 0,
		tot = 0;

	count_whowas_memory(&wwu, &wws, &wwa, &wwam);
	wwm = sizeof(aName) * ww_len;

	for (acptr = client; acptr; acptr = acptr->next)
	    {
		if (MyConnect(acptr))
		    {
			lc++;
			for (link = acptr->confs; link; link = link->next)
				lcc++;
		    }
		else
			rc++;
		if (acptr->user)
		   {
			us++;
			for (link = acptr->user->invited; link;
			     link = link->next)
				usi++;
			for (link = acptr->user->channel; link;
			     link = link->next)
				usc++;
			if (acptr->user->away)
				aw++;
		   }
	    }
	lcm = lc * CLIENT_LOCAL_SIZE;
	rcm = rc * CLIENT_REMOTE_SIZE;
	awm = aw * (TOPICLEN+1);

	for (chptr = channel; chptr; chptr = chptr->nextch)
	    {
		ch++;
		for (link = chptr->lmembers; link; link = link->next)
			chlu++;
		for (link = chptr->members; link; link = link->next)
			chu++;
		for (link = chptr->invites; link; link = link->next)
			chi++;
		for (link = chptr->banlist; link; link = link->next)
		    {
			chb++;
			chbm += (sizeof(Link) + strlen(link->value.cp) + 1);
		    }
	    }
	chm = ch * sizeof(aChannel);

	for (lock = firstlock; lock; lock = lock->next)
		lk++;
	lkm = lk * sizeof(aLock);

	for (token = firsttoken; token; token = token->next)
		if (token->from)
			rtk++;
		else
			ltk++;
	ltkm = ltk * sizeof(aToken);
	rtkm = rtk * sizeof(aToken);

	for (token = freeltokens; token; token = token->next)
		ftk++;
	ftkm = ftk * sizeof(aToken);

	for (aconf = conf; aconf; aconf = aconf->next)
	    {
		co++;
		com += aconf->host ? strlen(aconf->host)+1 : 0;
		com += aconf->passwd ? strlen(aconf->passwd)+1 : 0;
		com += aconf->name ? strlen(aconf->name)+1 : 0;
		com += sizeof(aConfItem);
	    }

	for (cltmp = classes; cltmp; cltmp = cltmp->next)
		cl++;

	sendto_one(cptr, ":%s %d %s :FD local %d serv %d user %d notice %d",
		   me.name, RPL_STATSDEBUG, nick, highest_fd+1,
		   fdserv.highest+1, fduser.highest+1, fdnotice.highest+1);
	sendto_one(cptr, ":%s %d %s :Client Local %d(%d) Remote %d(%d)",
		   me.name, RPL_STATSDEBUG, nick, lc, lcm, rc, rcm);
	sendto_one(cptr, ":%s %d %s :Users %d(%d) Invites %d(%d) Locks %d(%d)"
		   "[%d]",
		   me.name, RPL_STATSDEBUG, nick, us, us*sizeof(anUser), usi,
		   usi * sizeof(Link), lk, lkm, LOCKSECONDS);
	sendto_one(cptr,
		   ":%s %d %s :Tokens Local %d(%d) Remote %d(%d) Free %d(%d)",
		   me.name, RPL_STATSDEBUG, nick, ltk, ltkm, rtk, rtkm,
		   ftk, ftkm);
	sendto_one(cptr, ":%s %d %s :User channels %d(%d) Aways %d(%d)",
		   me.name, RPL_STATSDEBUG, nick, usc, usc*sizeof(Link),
		   aw, awm);
	sendto_one(cptr, ":%s %d %s :Attached confs %d(%d)",
		   me.name, RPL_STATSDEBUG, nick, lcc, lcc*sizeof(Link));

	totcl = lcm + rcm + us*sizeof(anUser) + usc*sizeof(Link) + awm;
	totcl += lcc*sizeof(Link) + usi*sizeof(Link);

	sendto_one(cptr, ":%s %d %s :Conflines %d(%d)",
		   me.name, RPL_STATSDEBUG, nick, co, com);

	sendto_one(cptr, ":%s %d %s :Classes %d(%d)",
		   me.name, RPL_STATSDEBUG, nick, cl, cl*sizeof(aClass));

	sendto_one(cptr, ":%s %d %s :Channels %d(%d)[%d/%d] Bans %d(%d)",
		   me.name, RPL_STATSDEBUG, nick, ch, chm,
		   MAXCHANNELSPERUSER, MAXCHANNELSPERREMOTEUSER,
		   chb, chbm);
	sendto_one(cptr, ":%s %d %s :Channel membrs local %d(%d) global %d(%d)"
			 " invite %d(%d)",
		   me.name, RPL_STATSDEBUG, nick, chlu, chlu*sizeof(Link),
		   chu, chu*sizeof(Link), chi, chi*sizeof(Link));

	totch = chm + chbm + chlu*sizeof(Link) + chu*sizeof(Link)
		+ chi*sizeof(Link);

	sendto_one(cptr, ":%s %d %s :Whowas users %d(%d) away %d(%d)",
		   me.name, RPL_STATSDEBUG, nick, wwu, wwu*sizeof(anUser),
		   wwa, wwam);
	sendto_one(cptr, ":%s %d %s :Whowas servers %d(%d) array %d(%d)",
		   me.name, RPL_STATSDEBUG, nick, wws, wws*sizeof(aServer),
		   ww_len, wwm);

	totww = wwu*sizeof(anUser) + wws*sizeof(aServer) + wwam + wwm;

	sendto_one(cptr, ":%s %d %s :Hash: cl %d(%d) ch %d(%d) lk %d(%d)"
		   " tk %d(%d)",
		   me.name, RPL_STATSDEBUG, nick, clientHashSize,
		   sizeof(aHashEntry) * clientHashSize,
		   channelHashSize, sizeof(aHashEntry) * channelHashSize,
		   lockHashSize, sizeof(aHashEntry) * lockHashSize,
		   tokenHashSize, sizeof(aHashEntry) * tokenHashSize);

	db = dbufblocks * sizeof(dbufbuf);
	fdb = dbufblocksfree * sizeof(dbufbuf);
	sendto_one(cptr, ":%s %d %s :Dbuf blocks %d(%d) free %d(%d)[%d]",
		   me.name, RPL_STATSDEBUG, nick, dbufblocks, db,
		   dbufblocksfree, fdb, keepdbufblocks);

	rm = cres_mem(cptr);

	tot = totww + totch + totcl + lkm + ltkm + rtkm + ftkm + com
	      + cl*sizeof(aClass) + db + fdb + rm;
	tot += sizeof(aHashEntry) * clientHashSize;
	tot += sizeof(aHashEntry) * channelHashSize;
	tot += sizeof(aHashEntry) * lockHashSize;
	tot += sizeof(aHashEntry) * tokenHashSize;

	sendto_one(cptr,
		   ":%s %d %s :Total: ww %d ch %d cl %d lk %d tk %d"
		   " co %d db %d",
		   me.name, RPL_STATSDEBUG, nick, totww, totch, totcl,
		   lkm, ltkm + rtkm + ftkm, com, db + fdb);
	sendto_one(cptr, ":%s %d %s :TOTAL: %d sbrk(0)-etext: %u",
		   me.name, RPL_STATSDEBUG, nick, tot,
		   (u_int)sbrk((size_t)0)-(u_int)sbrk0);
	return;
}
