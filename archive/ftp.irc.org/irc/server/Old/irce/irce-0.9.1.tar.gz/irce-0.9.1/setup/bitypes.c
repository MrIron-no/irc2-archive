#include <stdio.h>

void	main(void)
{
	if (sizeof(unsigned int) == 4)
		puts("typedef unsigned int UINT32;");
	else if (sizeof(unsigned long) == 4)
		puts("typedef unsigned long UINT32;");
	else
		puts("error Unable to determine 32bit type!");
	if (sizeof(unsigned short) == 2)
		puts("typedef unsigned short UINT16;");
	else if (sizeof(unsigned int) == 2)
		puts("typedef unsigned int UINT16;");
	else
		puts("error Unable to determine 16bit type!");
}
