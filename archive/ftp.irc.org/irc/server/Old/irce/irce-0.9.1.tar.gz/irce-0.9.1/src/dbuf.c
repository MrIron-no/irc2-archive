/************************************************************************
 *   IRC - Internet Relay Chat, dbuf.c
 *   Copyright (C) 1990 Markku Savela
 *   Portions Copyright (C) 1998 Ari Heikkinen
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
** For documentation of the *global* functions implemented here,
** see the header file (dbuf.h).
*/

#include "struct.h"
#include "common.h"
#include "sys.h"

int	dbufblocks = 0, dbufblocksfree = 0, keepdbufblocks = 8;

static	dbufbuf	*free_dbufs = NULL;

/* This is a dangerous define because a broken compiler will set DBUFSIZ
** to 4, which will work but will be very inefficient. However, there
** are other places where the code breaks badly if this is screwed
** up, so... -- Wumpus
*/
#define DBUFSIZ sizeof(((dbufbuf *)0)->data)

/*
** initdbufs - preallocate page aligned memory for dbuf freelist
*/
void	initdbufs()
{
	dbufbuf *ptr;

	while (dbufblocksfree < keepdbufblocks)
	    {
		ptr = (dbufbuf *)valloc(sizeof(dbufbuf));
		if (!ptr)
			return;
		ptr->next = free_dbufs;
		free_dbufs = ptr;
		dbufblocksfree++;
	    }
}

/*
** dbuf_alloc - allocates a dbufbuf structure
*/
static dbufbuf *dbuf_alloc()
{
	dbufbuf *ptr;

	if (ptr = free_dbufs)
	    {
		free_dbufs = free_dbufs->next;
		if (dbufblocksfree-- < 0)
			abort();
	    }
	else
	    {
		int	numErr = 0;
		while (!(ptr = (dbufbuf *)valloc(sizeof(dbufbuf))))
		    {
			numErr++;
			sleep(1);
		    }
		if (numErr > 0)
			/*
			** this memory block was hard to get, keep it! ;-)
			*/
			keepdbufblocks++;
	    }
	dbufblocks++;
	if (!dbufblocksfree && dbufblocks / 4 > keepdbufblocks)
		/*
		** keep 1/4 of max. number of dbufblocks in freelist
		*/
		keepdbufblocks = dbufblocks / 4;
	return ptr;
}

/*
** dbuf_free - free a dbufbuf structure
*/
static	void	dbuf_free(ptr)
dbufbuf	*ptr;
{
	if (dbufblocksfree < keepdbufblocks)
	    {
		/*
		** too less free dbufblocks, move this one to freelist
		*/
		ptr->next = free_dbufs;
		free_dbufs = ptr;
		dbufblocksfree++;
	    }
	else
		free(ptr);
	if (dbufblocks-- < 0)
		abort();
}

int	dbuf_put(dyn, buf, length)
dbuf	*dyn;
char	*buf;
int	length;
{
	dbufbuf	**h, *d;
	int	nbr, off;
	int	chunk;

	off = (dyn->offset + dyn->length) % DBUFSIZ;
	nbr = (dyn->offset + dyn->length) / DBUFSIZ;
	/*
	** Locate the last non-empty buffer. If the last buffer is
	** full, the loop will terminate with 'd==NULL'. This loop
	** assumes that the 'dyn->length' field is correctly
	** maintained, as it should--no other check really needed.
	**
	** What is this? Looking for last dynamic item with a loop
	** instead of using a pointer? This should be fixed to use
	** a pointer instead but leaving this unfixed (for now)
	** because "fixing it" could cause a possible bug in
	** otherwise stable and working code.. --DLR
	*/
	for (h = &(dyn->head); (d = *h) && --nbr >= 0; h = &(d->next));
	/*
	** Append users data to buffer, allocating buffers as needed
	*/
	chunk = DBUFSIZ - off;
	dyn->length += length;
	for ( ;length > 0; h = &(d->next))
	    {
		if ((d = *h) == NULL)
		    {
			d = (dbufbuf *)dbuf_alloc();
			*h = d;
			d->next = NULL;
		    }
		if (chunk > length)
			chunk = length;
		bcopy(buf, d->data + off, chunk);
		length -= chunk;
		buf += chunk;
		off = 0;
		chunk = DBUFSIZ;
	    }
	return 1;
}

char	*dbuf_map(dyn,length)
dbuf	*dyn;
int	*length;
{
	if (dyn->head == NULL)
	    {
		*length = 0;
		return NULL;
	    }
	*length = DBUFSIZ - dyn->offset;
	if (*length > dyn->length)
		*length = dyn->length;
	return (dyn->head->data + dyn->offset);
}

int	dbuf_delete(dyn,length)
dbuf	*dyn;
int	length;
{
	dbufbuf *d;
	int chunk;

	if (length > dyn->length)
		length = dyn->length;
	chunk = DBUFSIZ - dyn->offset;
	while (length > 0)
	    {
		if (chunk > length)
			chunk = length;
		length -= chunk;
		dyn->offset += chunk;
		dyn->length -= chunk;
		if (dyn->offset == DBUFSIZ || dyn->length == 0)
		    {
			d = dyn->head;
			dyn->head = d->next;
			dyn->offset = 0;
			dbuf_free(d);
		    }
		chunk = DBUFSIZ;
	    }
	if (dyn->head == (dbufbuf *)NULL)
		dyn->length = 0;
	return 0;
}

int	dbuf_get(dyn, buf, length)
dbuf	*dyn;
char	*buf;
int	length;
{
	int	moved = 0;
	int	chunk;
	char	*b;

	while (length > 0 && (b = dbuf_map(dyn, &chunk)) != NULL)
	    {
		if (chunk > length)
			chunk = length;
		bcopy(b, buf, (int)chunk);
		(void)dbuf_delete(dyn, chunk);
		buf += chunk;
		length -= chunk;
		moved += chunk;
	    }
	return moved;
}

/*
** dbuf_getmsg
**
** Check the buffers to see if there is a string which is terminted with
** either a \r or \n prsent.  If so, copy as much as possible (determined by
** length) into buf and return the amount copied - else return 0.
*/
int	dbuf_getmsg(dyn, buf, length)
dbuf	*dyn;
char	*buf;
int	length;
{
	dbufbuf	*d;
	char	*s;
	int	dlen;
	int	i;
	int	copy;

getmsg_init:
	d = dyn->head;
	dlen = dyn->length;
	i = DBUFSIZ - dyn->offset;
	if (i <= 0)
		return -1;
	copy = 0;
	if (d && dlen)
		s = dyn->offset + d->data;
	else
		return 0;

	if (i > dlen)
		i = dlen;
	while (length > 0 && dlen > 0)
	    {
		dlen--;
		if (*s == '\n' || *s == '\r')
		    {
			copy = dyn->length - dlen;
			/*
			** Shortcut this case here to save time elsewhere.
			** -avalon
			*/
			if (copy == 1)
			    {
				(void)dbuf_delete(dyn, 1);
				goto getmsg_init;
			    }
			break;
		    }
		length--;
		if (!--i)
		    {
			if ((d = d->next))
			    {
				s = d->data;
				i = MIN(DBUFSIZ, dlen);
			    }
		    }
		else
			s++;
	    }

	if (copy <= 0)
		return 0;

	/*
	** copy as much of the message as wanted into parse buffer
	*/
	i = dbuf_get(dyn, buf, MIN(copy, length));
	/*
	** and delete the rest of it!
	*/
	if (copy - i > 0)
		(void)dbuf_delete(dyn, copy - i);
	if (i >= 0)
		*(buf+i) = '\0';	/* mark end of messsage */

	return i;
}
