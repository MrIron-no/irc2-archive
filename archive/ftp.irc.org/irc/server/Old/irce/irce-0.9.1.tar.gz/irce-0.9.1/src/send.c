/************************************************************************
 *   IRC - Internet Relay Chat, send.c
 *   Copyright (C) 1990 Jarkko Oikarinen and
 *		      University of Oulu, Computing Center
 *   Portions Copyright (C) 1998 Ari Heikkinen
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "struct.h"
#include "common.h"
#include "sys.h"
#include "h.h"

static	char	sendbuf[8192];
static	int	send_message PROTO((aClient *, char *, int));

static	int	sentalong[MAXCONNECTIONS];

/*
** dead_link
**	An error has been detected. The link *must* be closed,
**	but *cannot* call ExitClient (m_bye) from here.
**	Instead, mark it with FLAGS_DEADSOCKET. This should
**	generate ExitClient from the main loop.
**
**	If 'notice' is not NULL, it is assumed to be a format
**	for a message to local opers. I can contain only one
**	'%s', which will be replaced by the sockhost field of
**	the failing link.
**
**	Also, the notice is skipped for "uninteresting" cases,
**	like Persons and yet unknown connections...
*/
static	int	dead_link(to, notice)
aClient *to;
char	*notice;
{
	to->flags |= FLAGS_DEADSOCKET;
	/*
	 * If because of BUFFERPOOL problem then clean dbuf's now so that
	 * notices don't hurt operators below.
	 */
	DBufClear(&to->recvQ);
	DBufClear(&to->sendQ);
	if (!IsPerson(to) && !IsUnknown(to) && !(to->flags & FLAGS_CLOSING))
		sendto_ops(notice, get_client_name(to, FALSE));
	Debug((DEBUG_ERROR, notice, get_client_name(to, FALSE)));
	return -1;
}

/*
** flush_fdary
**	Empty all output buffers for connections in ary.
*/
void	flush_fdary(ary)
FdAry	*ary;
{
	aClient *cptr;
	int	i;

	for (i = ary->highest; i >= 0; i--)
	    {
		if (!(cptr = local[ary->fd[i]]) || !IsRegistered(cptr))
			abort();
		if (DBufLength(&cptr->sendQ) > 0)
			(void)send_queued(cptr);
	    }
}

/*
** flush_connections
**	Used to empty all output buffers for all connections. Should only
**	be called once per scan of connections. There should be a select in
**	here perhaps but that means either forcing a timeout or doing a poll.
**	When flushing, all we do is empty the obuffer array for each local
**	client and try to send it. if we cant send it, it goes into the sendQ
**	-avalon
*/
void	flush_connections(fd)
int	fd;
{
	aClient *cptr;
	int	i;

	if (fd == me.fd)
	    {
		for (i = highest_fd; i >= 0; i--)
			if ((cptr = local[i]) && DBufLength(&cptr->sendQ) > 0)
				(void)send_queued(cptr);
	    }
	else if (fd >= 0 && (cptr = local[fd]) && DBufLength(&cptr->sendQ) > 0)
		(void)send_queued(cptr);
}

/*
** send_message
**	Internal utility which delivers one message buffer to the
**	socket. Takes care of the error handling and buffering, if
**	needed.
*/
static	int	send_message(to, msg, len)
aClient	*to;
char	*msg;	/* if msg is a null pointer, we are flushing connection */
int	len;
{
	if (IsDead(to))
		return 0; /* This socket has already been marked as dead */
	if (DBufLength(&to->sendQ) > get_sendq(to))
	    {
		if (IsServer(to))
			sendto_ops("Max SendQ limit exceeded for %s: %d > %d",
			   	get_client_name(to, FALSE),
				DBufLength(&to->sendQ), get_sendq(to));
		return dead_link(to, "Max Sendq exceeded");
	    }
	else if (dbuf_put(&to->sendQ, msg, len) < 0)
		return dead_link(to, "Buffer allocation error for %s");
	/*
	** Update statistics. The following is slightly incorrect
	** because it counts messages even if queued, but bytes
	** only really sent. Queued bytes get updated in SendQueued.
	*/
	to->sendM += 1;
	me.sendM += 1;
	if (to->acpt != &me)
		to->acpt->sendM += 1;
	/*
	** This little bit is to stop the sendQ from growing too large when
	** there is no need for it to. Thus we call send_queued() every time
	** 8k has been added to the queue since the last non-fatal write.
	** Also stops us from deliberately building a large sendQ and then
	** trying to flood that link with data (possible during the net
	** relinking done by servers with a large load).
	*/
	if (DBufLength(&to->sendQ)/8192 > to->lastsq)
		send_queued(to);
	return 0;
}

/*
** send_queued
**	This function is called from the main select-loop (or whatever)
**	when there is a chance the some output would be possible. This
**	attempts to empty the send queue as far as possible...
*/
int	send_queued(to)
aClient *to;
{
	char	*msg;
	int	len, rlen;

	/*
	** Once socket is marked dead, we cannot start writing to it,
	** even if the error is removed...
	*/
	if (IsDead(to))
	    {
		/*
		** Actually, we should *NEVER* get here--something is
		** not working correct if send_queued is called for a
		** dead socket... --msa
		*/
		abort(); /* abort */
	    }
	while (DBufLength(&to->sendQ) > 0)
	    {
		msg = dbuf_map(&to->sendQ, &len);
					/* Returns always len > 0 */
		if ((rlen = deliver_it(to, msg, len)) < 0)
			return dead_link(to,"Write error to %s, closing link");
		(void)dbuf_delete(&to->sendQ, rlen);
		to->lastsq = DBufLength(&to->sendQ)/8192;
		if (rlen < len) /* ..or should I continue until rlen==0? */
			break;
	    }

	return (IsDead(to)) ? -1 : 0;
}

/*
** send message to single client
*/
#ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_one(to, pattern, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11)
aClient *to;
char	*pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8, *p9, *p10, *p11;
{
#else
void	sendto_one(to, pattern, va_alist)
aClient	*to;
char	*pattern;
va_dcl
{
	va_list	vl;
#endif
	int len;

#ifdef VMS
	extern int goodbye;
	
	if (StrEq("QUIT", pattern)) 
		goodbye = 1;
#endif

#ifdef	USE_VARARGS
	va_start(vl);
	len = vsprintf(sendbuf, pattern, vl);
	va_end(vl);
#else
	len = sprintf(sendbuf, pattern, p1, p2, p3, p4, p5, p6,
		      p7, p8, p9, p10, p11);
#endif
	Debug((DEBUG_SEND,"Sending [%s] to %s", sendbuf, to->name));
	if (to->from)
		to = to->from;
	if (to->fd < 0 || IsMe(to))
		abort();
#ifdef	IRCII_KLUDGE
	if (len > BUFSIZE-1)
		len = BUFSIZE-1;
	sendbuf[len++] = '\n';
#else
	if (len > BUFSIZE-2)
		len = BUFSIZE-2;
	sendbuf[len++] = '\r';
	sendbuf[len++] = '\n';
#endif
	sendbuf[len] = '\0';
	(void)send_message(to, sendbuf, len);
}

# ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_channel_butone(one, from, chptr, pattern,
			      p1, p2, p3, p4, p5, p6, p7, p8)
aClient *one, *from;
aChannel *chptr;
char	*pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8;
{
# else
void	sendto_channel_butone(one, from, chptr, pattern, va_alist)
aClient	*one, *from;
aChannel *chptr;
char	*pattern;
va_dcl
{
	va_list	vl;
# endif
	Link	*lp;
	aClient *acptr;

# ifdef	USE_VARARGS
	va_start(vl);
# endif
	for (lp = chptr->members; lp; lp = lp->next)
		lp->value.cptr->from->tmp = 0;
	for (lp = chptr->members; lp; lp = lp->next)
	    {
		acptr = lp->value.cptr;
		if (acptr->from->tmp)
			continue;	/* already sent to this connection */
		if (acptr->from == one)
			continue;	/* ...was the one I should skip */
# ifdef	USE_VARARGS
		sendto_prefix_one(acptr, from, pattern, vl);
# else
		sendto_prefix_one(acptr, from, pattern, p1, p2,
				  p3, p4, p5, p6, p7, p8);
# endif
		acptr->from->tmp++;	/* mark connection already sent */
	    }
# ifdef	USE_VARARGS
	va_end(vl);
# endif
	return;
}

/*
 * sendto_hidden_butone
 *
 * Send a message to all connected hidden or v2.8 servers except
 * the client 'one'.
 */
# ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_hidden_butone(one, pattern, p1, p2, p3, p4, p5, p6, p7, p8)
aClient *one;
char	*pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8;
{
# else
void	sendto_hidden_butone(one, pattern, va_alist)
aClient	*one;
char	*pattern;
va_dcl
{
	va_list	vl;
# endif
	int	i;
	aClient *cptr;

# ifdef	USE_VARARGS
	va_start(vl);
# endif

	for (i = fdserv.highest; i >= 0; i--)
	    {
		if (!(cptr = local[fdserv.fd[i]]))
			abort();
		if (one && cptr == one->from)
			continue;
		if (!(cptr->flags & FLAGS_HIDDEN) && IsV29(cptr))
			continue;
# ifdef	USE_VARARGS
		sendto_one(cptr, pattern, vl);
	    }
	va_end(vl);
# else
		sendto_one(cptr, pattern, p1, p2, p3, p4,
			   p5, p6, p7, p8);
	    }
# endif
	return;
}

/*
 * sendto_server_butone
 *
 * Send a message to all connected servers except the client 'one'.
 * (also, hidden servers won't get any messages)
 */
# ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_serv_butone(one, pattern, p1, p2, p3, p4, p5, p6, p7, p8)
aClient *one;
char	*pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8;
{
# else
void	sendto_serv_butone(one, pattern, va_alist)
aClient	*one;
char	*pattern;
va_dcl
{
	va_list	vl;
# endif
	int	i;
	aClient *cptr;

# ifdef	USE_VARARGS
	va_start(vl);
# endif

	for (i = fdserv.highest; i >= 0; i--)
	    {
		if (!(cptr = local[fdserv.fd[i]]))
			abort();
		if (one && cptr == one->from)
			continue;
		if (cptr->flags & FLAGS_HIDDEN)
			continue;
# ifdef	USE_VARARGS
		sendto_one(cptr, pattern, vl);
	    }
	va_end(vl);
# else
		sendto_one(cptr, pattern, p1, p2, p3, p4,
			   p5, p6, p7, p8);
	    }
# endif
	return;
}

/*
 * sendto_V28_server_butone
 *
 * Send a message to all connected v2.8 servers except the client 'one'.
 * (also, hidden servers won't get any messages)
 */
# ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_V28_serv_butone(one, pattern, p1, p2, p3, p4, p5, p6, p7, p8)
aClient *one;
char	*pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8;
{
# else
void	sendto_V28_serv_butone(one, pattern, va_alist)
aClient	*one;
char	*pattern;
va_dcl
{
	va_list	vl;
# endif
	int	i;
	aClient *cptr;

# ifdef	USE_VARARGS
	va_start(vl);
# endif

	for (i = fdserv.highest; i >= 0; i--)
	    {
		if (!(cptr = local[fdserv.fd[i]]))
			abort();
		if (one && cptr == one->from)
			continue;
		if (cptr->flags & FLAGS_HIDDEN)
			continue;
		if (!IsV29(cptr))
# ifdef	USE_VARARGS
			sendto_one(cptr, pattern, vl);
	    }
	va_end(vl);
# else
			sendto_one(cptr, pattern, p1, p2, p3, p4,
				   p5, p6, p7, p8);
	    }
# endif
	return;
}

/*
 * sendto_V29_server_butone
 *
 * Send a message to all connected v2.9 servers except the client 'one'.
 * (also, hidden servers won't get any messages)
 */
# ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_V29_serv_butone(one, pattern, p1, p2, p3, p4, p5, p6, p7, p8)
aClient *one;
char	*pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8;
{
# else
void	sendto_V29_serv_butone(one, pattern, va_alist)
aClient	*one;
char	*pattern;
va_dcl
{
	va_list	vl;
# endif
	int	i;
	aClient *cptr;

# ifdef	USE_VARARGS
	va_start(vl);
# endif

	for (i = fdserv.highest; i >= 0; i--)
	    {
		if (!(cptr = local[fdserv.fd[i]]))
			abort();
		if (one && cptr == one->from)
			continue;
		if (cptr->flags & FLAGS_HIDDEN)
			continue;
		if (IsV29(cptr))
# ifdef	USE_VARARGS
			sendto_one(cptr, pattern, vl);
	    }
	va_end(vl);
# else
			sendto_one(cptr, pattern, p1, p2, p3, p4,
				   p5, p6, p7, p8);
	    }
# endif
	return;
}

/*
 * sendto_common_channels()
 *
 * Sends a message to all people (inclusing user) on local server who are
 * in same channel with user.
 */
# ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_common_channels(user, pattern, p1, p2, p3, p4,
				p5, p6, p7, p8)
aClient *user;
char	*pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8;
{
# else
void	sendto_common_channels(user, pattern, va_alist)
aClient	*user;
char	*pattern;
va_dcl
{
	va_list	vl;
# endif
	aClient *cptr;
	Link	*lp, *lp2;

# ifdef	USE_VARARGS
	va_start(vl);
# endif
	for (lp = user->user->channel; lp; lp = lp->next)
		for (lp2 = lp->value.chptr->lmembers; lp2; lp2 = lp2->next)
		    {
			cptr = lp2->value.cptr;
			if (!MyConnect(cptr))
				abort();
			cptr->tmp = 0;
		    }
	for (lp = user->user->channel; lp; lp = lp->next)
		for (lp2 = lp->value.chptr->lmembers; lp2; lp2 = lp2->next)
		    {
			cptr = lp2->value.cptr;
			if (cptr->tmp || cptr == user)
				continue;
# ifdef	USE_VARARGS
			sendto_prefix_one(cptr, user, pattern, vl);
# else
			sendto_prefix_one(cptr, user, pattern,
					  p1, p2, p3, p4,
					  p5, p6, p7, p8);
# endif
			cptr->tmp++;
		    }

	if (MyConnect(user) && !(user->flags & FLAGS_CLOSING))
# ifdef	USE_VARARGS
		sendto_prefix_one(user, user, pattern, vl);
	va_end(vl);
# else
		sendto_prefix_one(user, user, pattern, p1, p2, p3, p4,
					p5, p6, p7, p8);
# endif
	return;
}

/*
 * sendto_channel_butserv
 *
 * Send a message to all members of a channel that are connected to this
 * server.
 */
#ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_channel_butserv(chptr, from, pattern, p1, p2, p3,
			       p4, p5, p6, p7, p8)
aChannel *chptr;
aClient *from;
char	*pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8;
{
#else
void	sendto_channel_butserv(chptr, from, pattern, va_alist)
aChannel *chptr;
aClient *from;
char	*pattern;
va_dcl
{
	va_list	vl;
#endif
	Link	*lp;
	aClient	*acptr;

#ifdef	USE_VARARGS
	for (va_start(vl), lp = chptr->lmembers; lp; lp = lp->next)
	    {
		acptr = lp->value.cptr;
		if (!MyConnect(acptr))
			abort();
		sendto_prefix_one(acptr, from, pattern, vl);
	    }
	va_end(vl);
#else
	for (lp = chptr->lmembers; lp; lp = lp->next)
	    {
		acptr = lp->value.cptr;
		if (!MyConnect(acptr))
			abort();
		sendto_prefix_one(acptr, from, pattern,
				  p1, p2, p3, p4, p5, p6, p7, p8);
	    }
#endif

	return;
}

/*
** send a msg to all ppl on servers/hosts that match a specified mask
** (used for enhanced PRIVMSGs)
**
** addition -- Armin, 8jun90 (gruner@informatik.tu-muenchen.de)
*/

static	int	match_it(one, mask, what)
aClient *one;
char	*mask;
int	what;
{
	switch (what)
	{
	case MATCH_HOST:
		return (matches(mask, one->user->host) == 0);
	case MATCH_SERVER:
	default:
		return (matches(mask, one->where->name) == 0);
	}
}

/*
 * sendto_match_servs
 *
 * send to all servers which match the mask at the end of a channel name
 * (if there is a mask present) or to all if no mask.
 */
#ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_match_servs(chptr, from, format, p1,p2,p3,p4,p5,p6,p7,p8,p9)
aChannel *chptr;
aClient	*from;
char	*format, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8, *p9;
{
#else
void	sendto_match_servs(chptr, from, format, va_alist)
aChannel *chptr;
aClient	*from;
char	*format;
va_dcl
{
	va_list	vl;
#endif
	int	i;
	aClient	*cptr;
	char	*mask;

#ifdef	USE_VARARGS
	va_start(vl);
#endif

	if (chptr)
	    {
		if (*chptr->chname == '&')
			return;
		mask = chptr->mask;
	    }
	else
		mask = (char *)NULL;

	for (i = fdserv.highest; i >= 0; i--)
	    {
		if (!(cptr = local[fdserv.fd[i]]))
			abort();
		if (cptr == from)
			continue;
		if (!BadPtr(mask) && matches(mask, cptr->name))
			continue;
#ifdef	USE_VARARGS
		sendto_one(cptr, format, vl);
	    }
	va_end(vl);
#else
		sendto_one(cptr, format, p1, p2, p3, p4, p5, p6, p7, p8, p9);
	    }
#endif
}

/*
 * sendto_match_butone
 *
 * Send to all clients which match the mask in a way defined on 'what';
 * either by user hostname or user servername.
 */
#ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_match_butone(one, from, mask, what, pattern,
			    p1, p2, p3, p4, p5, p6, p7, p8)
aClient *one, *from;
int	what;
char	*mask, *pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8;
{
#else
void	sendto_match_butone(one, from, mask, what, pattern, va_alist)
aClient *one, *from;
int	what;
char	*mask, *pattern;
va_dcl
{
	va_list	vl;
#endif
	int	i;
	aClient *cptr, *acptr;
  
#ifdef	USE_VARARGS
	va_start(vl);
#endif
	for (i = 0; i <= highest_fd; i++)
	    {
		if (!(cptr = local[i]))
			continue;       /* that clients are not mine */
 		if (cptr == one)	/* must skip the origin !! */
			continue;
		if (IsServer(cptr))
		    {
			for (acptr = client; acptr; acptr = acptr->next)
				if (IsRegisteredUser(acptr)
				    && match_it(acptr, mask, what)
				    && acptr->from == cptr)
					break;
			/* a person on that server matches the mask, so we
			** send *one* msg to that server ...
			*/
			if (acptr == NULL)
				continue;
			/* ... but only if there *IS* a matching person */
		    }
		/* my client, does he match ? */
		else if (!(IsRegisteredUser(cptr) &&
			 match_it(cptr, mask, what)))
			continue;
#ifdef	USE_VARARGS
		sendto_prefix_one(cptr, from, pattern, vl);
	    }
	va_end(vl);
#else
		sendto_prefix_one(cptr, from, pattern,
				  p1, p2, p3, p4, p5, p6, p7, p8);
	    }
#endif
	return;
}

/*
 * sendto_all_butone.
 *
 * Send a message to all connections except 'one'. The basic wall type
 * message generator.
 */
#ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_all_butone(one, from, pattern, p1, p2, p3, p4, p5, p6, p7, p8)
aClient *one, *from;
char	*pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8;
{
#else
void	sendto_all_butone(one, from, pattern, va_alist)
aClient *one, *from;
char	*pattern;
va_dcl
{
	va_list	vl;
#endif
	int	i;
	aClient *cptr;

#ifdef	USE_VARARGS
	for (va_start(vl), i = 0; i <= highest_fd; i++)
		if ((cptr = local[i]) && !IsMe(cptr) && one != cptr)
			sendto_prefix_one(cptr, from, pattern, vl);
	va_end(vl);
#else
	for (i = 0; i <= highest_fd; i++)
		if ((cptr = local[i]) && !IsMe(cptr) && one != cptr)
			sendto_prefix_one(cptr, from, pattern,
					  p1, p2, p3, p4, p5, p6, p7, p8);
#endif

	return;
}

/*
 * sendto_ops
 *
 *	Send to *local* ops only.
 */
#ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_ops(pattern, p1, p2, p3, p4, p5, p6, p7, p8)
char	*pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8;
{
#else
void	sendto_ops(pattern, va_alist)
char	*pattern;
va_dcl
{
	va_list	vl;
#endif
	aClient *cptr;
	int	i;
	char	nbuf[1024];

#ifdef	USE_VARARGS
	va_start(vl);
#endif
	for (i = fdnotice.highest; i >= 0; i--)
	    {
		if (!(cptr = local[fdnotice.fd[i]]))
			abort();
		(void)sprintf(nbuf, ":%s NOTICE %s :*** Notice -- %s",
			      me.name, cptr->name, pattern);
#ifdef	USE_VARARGS
		sendto_one(cptr, nbuf, va_alist);
#else
		sendto_one(cptr, nbuf, p1, p2, p3, p4, p5, p6, p7, p8);
#endif
	    }
#ifdef	USE_VARARGS
	va_end(vl);
#endif
	return;
}

/*
** sendto_ops_butone
**	Send message to all operators.
** one - client not to send message to
** from- client which message is from *NEVER* NULL!!
*/
#ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_ops_butone(one, from, pattern, p1, p2, p3, p4, p5, p6, p7, p8)
aClient *one, *from;
char	*pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8;
{
#else
void	sendto_ops_butone(one, from, pattern, va_alist)
aClient *one, *from;
char	*pattern;
va_dcl
{
	va_list	vl;
#endif
	int	i;
	aClient *cptr;

#ifdef	USE_VARARGS
	va_start(vl);
#endif
	for (i = 0; i <= highest_fd; i++)
		sentalong[i] = 0;
	for (cptr = client; cptr; cptr = cptr->next)
	    {
		if (!SendWallops(cptr))
			continue;
		if (MyClient(cptr) && !(IsServer(from) || IsMe(from)))
			continue;
		i = cptr->from->fd;	/* find connection oper is on */
		if (sentalong[i])	/* sent message along it already ? */
			continue;
		if (cptr->from == one)
			continue;	/* ...was the one I should skip */
		sentalong[i] = 1;
# ifdef	USE_VARARGS
      		sendto_prefix_one(cptr->from, from, pattern, vl);
	    }
	va_end(vl);
# else
      		sendto_prefix_one(cptr->from, from, pattern,
				  p1, p2, p3, p4, p5, p6, p7, p8);
	    }
# endif
	return;
}

/*
 * to - destination client
 * from - client which message is from
 *
 * NOTE: NEITHER OF THESE SHOULD *EVER* BE NULL!!
 * -avalon
 */
#ifndef	USE_VARARGS
/*VARARGS*/
void	sendto_prefix_one(to, from, pattern, p1, p2, p3, p4, p5, p6, p7, p8)
aClient *to;
aClient *from;
char	*pattern, *p1, *p2, *p3, *p4, *p5, *p6, *p7, *p8;
{
#else
void	sendto_prefix_one(to, from, pattern, va_alist)
aClient *to;
aClient *from;
char	*pattern;
va_dcl
{
	va_list	vl;
#endif
	static	char	sender[HOSTLEN+NICKLEN+USERLEN+5];
	anUser	*user;
	char	*par;
	int	flag = 0;

#ifdef	USE_VARARGS
	va_start(vl);
	par = va_arg(vl, char *);
#else
	par = p1;
#endif
	if (to && from && MyClient(to) && IsPerson(from) &&
	    !mycmp(par, from->name))
	    {
		user = from->user;
		(void)strcpy(sender, from->name);
		if (user)
		    {
			if (*user->username)
			    {
				(void)strcat(sender, "!");
				(void)strcat(sender, user->username);
			    }
			if (*user->host && !MyConnect(from))
			    {
				(void)strcat(sender, "@");
				(void)strcat(sender, user->host);
				flag = 1;
			    }
		    }
		/*
		** flag is used instead of index(sender, '@') for speed and
		** also since username/nick may have had a '@' in them. -avalon
		*/
		if (!flag && MyConnect(from) && *user->host)
		    {
			(void)strcat(sender, "@");
			if (IsUnixSocket(from))
				(void)strcat(sender, user->host);
			else
				(void)strcat(sender, from->sockhost);
		    }
#ifdef	USE_VARARGS
		par = sender;
	    }
	sendto_one(to, pattern, par, vl);
	va_end(vl);
#else
		par = sender;
	    }
	sendto_one(to, pattern, par, p2, p3, p4, p5, p6, p7, p8);
#endif
}
