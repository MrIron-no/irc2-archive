#!/bin/sh
for f in *.c
do
	c=`echo $f | cut -f1 -d.`.c
	o=`echo $f | cut -f1 -d.`.o
	cat << EOF

$o:	../src/$c setup.h config.h
		$(CC) $(CFLAGS) -c ../src/$c -o $o
EOF
done
