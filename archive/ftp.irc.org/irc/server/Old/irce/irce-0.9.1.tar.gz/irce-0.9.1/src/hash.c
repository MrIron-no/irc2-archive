/************************************************************************
 *   IRC - Internet Relay Chat, hash.c
 *   Copyright (C) 1991 Darren Reed
 *   Portions Copyright (C) 1998 Ari Heikkinen
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "struct.h"
#include "common.h"
#include "sys.h"
#include "h.h"
#ifdef HAVE_MATHH
# include <math.h>
#endif
static	aHashEntry	*clientTable = NULL;
static	aHashEntry	*channelTable = NULL;
static	aHashEntry	*lockTable = NULL;
static	aHashEntry	*tokenTable = NULL;

int	clientHashSize = 64;
int	channelHashSize = 16;
int	lockHashSize = 64;
int	tokenHashSize = 8;

int	clientHashHits = 0, clientHashMiss = 0;
int	channelHashHits = 0, channelHashMiss = 0;
int	lockHashHits = 0, lockHashMiss = 0;
int	tokenHashHits = 0, tokenHashMiss = 0;

static	int	*hash_tab = NULL;

/*
 * Hashing.
 *
 *   The server uses a chained hash table to provide quick and efficient
 * hash table mantainence (providing the hash function works evenly over
 * the input range).  The hash table is thus not susceptible to problems
 * of filling all the buckets or the need to rehash.
 *    It is expected that the hash table would look somehting like this
 * during use:
 *                   +-----+    +-----+    +-----+   +-----+
 *                ---| 224 |----| 225 |----| 226 |---| 227 |---
 *                   +-----+    +-----+    +-----+   +-----+
 *                      |          |          |
 *                   +-----+    +-----+    +-----+
 *                   |  A  |    |  C  |    |  D  |
 *                   +-----+    +-----+    +-----+
 *                      |
 *                   +-----+
 *                   |  B  |
 *                   +-----+
 *
 * A - GOPbot, B - chang, C - hanuaway, D - *.mu.OZ.AU
 *
 * The order shown above is just one instant of the server.  Each time a
 * lookup is made on an entry in the hash table and it is found, the entry
 * is moved to the top of the chain.
 */

static	int	make_prime(val)
int	val;
{
	int	i, sq;

	if (val < 7)
		return 7;
	val |= 1;
	for (;; val += 2)
	    {
		sq = (int)sqrt((double)val);
		for (i = 2; i <= sq; i++)
			if (!(val % i))
				break;
		if (i > sq)
			return val;
	    }
}

static	void	rebuild_client_hash()
{
	aHashEntry	*new;
	aClient		*cptr;

	clientHashSize = make_prime(clientHashSize);
	new = (aHashEntry *)MyMalloc(clientHashSize * sizeof(aHashEntry));
	bzero((char *)new, sizeof(aHashEntry) * clientHashSize);
	if (clientTable)
	    {
		MyFree(clientTable);
		clientTable = new;
		for (cptr = client; cptr; cptr = cptr->next)
			cptr->hnext = NULL;
		for (cptr = client; cptr; cptr = cptr->next)
			(void)add_to_client_hash_table(cptr->name, cptr);
	    }
	else
		clientTable = new;
	clientHashHits = 0;
	clientHashMiss = 0;
}

static	void	rebuild_channel_hash()
{
	aHashEntry	*new;
	aChannel	*chptr;

	channelHashSize = make_prime(channelHashSize);
	new = (aHashEntry *)MyMalloc(channelHashSize * sizeof(aHashEntry));
	bzero((char *)new, sizeof(aHashEntry) * channelHashSize);
	if (channelTable)
	    {
		MyFree(channelTable);
		channelTable = new;
		for (chptr = channel; chptr; chptr = chptr->nextch)
			chptr->hnextch = NULL;
		for (chptr = channel; chptr; chptr = chptr->nextch)
			(void)add_to_channel_hash_table(chptr->chname, chptr);
	    }
	else
		channelTable = new;
	channelHashMiss = 0;
	channelHashHits = 0;
}

static	void	rebuild_lock_hash()
{
	aHashEntry	*new;
	aLock		*lptr;

	lockHashSize = make_prime(lockHashSize);
	new = (aHashEntry *)MyMalloc(lockHashSize * sizeof(aHashEntry));
	bzero((char *)new, sizeof(aHashEntry) * lockHashSize);
	if (lockTable)
	    {
		MyFree(lockTable);
		lockTable = new;
		for (lptr = firstlock; lptr; lptr = lptr->next)
			lptr->hnext = NULL;
		for (lptr = firstlock; lptr; lptr = lptr->next)
			(void)add_to_lock_hash_table(lptr->lkname, lptr);
	    }
	else
		lockTable = new;
	lockHashMiss = 0;
	lockHashHits = 0;
}

static	void	rebuild_token_hash()
{
	aHashEntry	*new;
	aToken		*tptr;

	tokenHashSize = make_prime(tokenHashSize);
	new = (aHashEntry *)MyMalloc(tokenHashSize * sizeof(aHashEntry));
	bzero((char *)new, sizeof(aHashEntry) * tokenHashSize);
	if (tokenTable)
	    {
		MyFree(tokenTable);
		tokenTable = new;
		for (tptr = firsttoken; tptr; tptr = tptr->next)
			tptr->hnext = NULL;
		for (tptr = firsttoken; tptr; tptr = tptr->next)
			(void)add_to_token_hash_table(tptr->token, tptr);
	    }
	else
		tokenTable = new;
	tokenHashMiss = 0;
	tokenHashHits = 0;
}

void	inithash()
{
	int	i;

	rebuild_client_hash();
	rebuild_channel_hash();
	rebuild_lock_hash();
	rebuild_token_hash();
	if (hash_tab)
		MyFree(hash_tab);
	hash_tab = (int *)MyMalloc(256 * sizeof(*hash_tab));
	for (i = 0; i < 256; i++)
		hash_tab[i] = tolower(i) * 587;
}

/*
 * hash_string
 *
 * this function must be *quick*.  Thus there should be no multiplication
 * or division or modulus in the inner loop.  subtraction and other bit
 * operations allowed.
 */
static	int	hash_string(string, max, hashsize)
char	*string;
int	max;
int	hashsize;
{
	u_char	*str = (u_char *)string;
	u_char	ch;
	int	hash = 0, i;

	if (max > 0)
		for (i = max; i && (ch = *str); i--, str++)
		    {
			hash <<= 1;
			hash += hash_tab[ch];
		    }
	else
		for (; (ch = *str); str++)
		    {
			hash <<= 1;
			hash += hash_tab[ch];
		    }
	if (hash < 0)
		hash = -hash;
	hash %= hashsize;
	return hash;
}

/*
 * hash_int
 */
static	int	hash_int(i, hashsize)
int	i, hashsize;
{
	int	hash;

	hash = i * 18013;
	if (hash < 0)
		hash = -hash;
	hash %= hashsize;
	return hash;
}

/*
 * add_to_client_hash_table
 */
int	add_to_client_hash_table(name, cptr)
char	*name;
aClient	*cptr;
{
	int	hashv;

	hashv = hash_string(name, 0, clientHashSize);
	cptr->hnext = (aClient *)clientTable[hashv].list;
	clientTable[hashv].list = (void *)cptr;
	clientTable[hashv].links++;
	clientTable[hashv].hits++;
	if (num_clients > clientHashSize)
	    {
		clientHashSize = (int)((float)num_clients * 1.3);
		rebuild_client_hash();
		sendto_ops("Client hashtable rebuilt for bigger size.");
		writestate();
	    }
	return 0;
}

/*
 * add_to_channel_hash_table
 */
int		add_to_channel_hash_table(name, chptr)
char		*name;
aChannel	*chptr;
{
	int	hashv;

	hashv = hash_string(name, 20, channelHashSize);
	chptr->hnextch = (aChannel *)channelTable[hashv].list;
	channelTable[hashv].list = (void *)chptr;
	channelTable[hashv].links++;
	channelTable[hashv].hits++;
	if (num_channels > channelHashSize)
	    {
		channelHashSize = (int)((float)num_channels * 1.3);
		rebuild_channel_hash();
		sendto_ops("Channel hashtable rebuilt for bigger size.");
		writestate();
	    }
	return 0;
}

/*
 * add_to_lock_hash_table
 */
int	add_to_lock_hash_table(name, lptr)
char	*name;
aLock	*lptr;
{
	int	hashv;

	hashv = hash_string(name, 20, lockHashSize);
	lptr->hnext = (aLock *)lockTable[hashv].list;
	lockTable[hashv].list = (void *)lptr;
	lockTable[hashv].links++;
	lockTable[hashv].hits++;
	if (num_locks > lockHashSize)
	    {
		lockHashSize = (int)((float)num_locks * 1.3);
		rebuild_lock_hash();
		sendto_ops("Lock hashtable rebuilt for bigger size.");
		writestate();
	    }
	return 0;
}

/*
 * add_to_token_hash_table
 */
int	add_to_token_hash_table(token, tptr)
int	token;
aToken	*tptr;
{
	int	hashv;

	hashv = hash_int(token, tokenHashSize);
	tptr->hnext = (aToken *)tokenTable[hashv].list;
	tokenTable[hashv].list = (void *)tptr;
	tokenTable[hashv].links++;
	tokenTable[hashv].hits++;
	if (num_tokens > tokenHashSize)
	    {
		tokenHashSize = (int)((float)num_tokens * 1.3);
		rebuild_token_hash();
		sendto_ops("Token hashtable rebuilt for bigger size.");
		writestate();
	    }
	return 0;
}

/*
 * del_from_client_hash_table
 */
int	del_from_client_hash_table(name, cptr)
char	*name;
aClient	*cptr;
{
	aClient	*tmp, *prev = NULL;
	int	hashv;

	hashv = hash_string(name, 0, clientHashSize);
	for (tmp = (aClient *)clientTable[hashv].list; tmp; tmp = tmp->hnext)
	    {
		if (tmp == cptr)
		    {
			if (prev)
				prev->hnext = tmp->hnext;
			else
				clientTable[hashv].list = (void *)tmp->hnext;
			tmp->hnext = NULL;
			if (clientTable[hashv].links > 0)
			    {
				clientTable[hashv].links--;
				return 1;
			    } 
			else
				abort();
		    }
		prev = tmp;
	    }
	return 0;
}

/*
 * del_from_channel_hash_table
 */
int		del_from_channel_hash_table(name, chptr)
char		*name;
aChannel	*chptr;
{
	aChannel	*tmp, *prev = NULL;
	int	hashv;

	hashv = hash_string(name, 20, channelHashSize);
	for (tmp = (aChannel *)channelTable[hashv].list; tmp;
	     tmp = tmp->hnextch)
	    {
		if (tmp == chptr)
		    {
			if (prev)
				prev->hnextch = tmp->hnextch;
			else
				channelTable[hashv].list=(void *)tmp->hnextch;
			tmp->hnextch = NULL;
			if (channelTable[hashv].links > 0)
			    {
				channelTable[hashv].links--;
				return 1;
			    }
			else
				abort();
		    }
		prev = tmp;
	    }
	return 0;
}

/*
 * del_from_lock_hash_table
 */
int	del_from_lock_hash_table(name, lptr)
char	*name;
aLock	*lptr;
{
	aLock	*tmp, *prev = NULL;
	int	hashv;

	hashv = hash_string(name, 20, lockHashSize);
	for (tmp = (aLock *)lockTable[hashv].list; tmp; tmp = tmp->hnext)
	    {
		if (tmp == lptr)
		    {
			if (prev)
				prev->hnext = tmp->hnext;
			else
				lockTable[hashv].list = (void *)tmp->hnext;
			tmp->hnext = NULL;
			if (lockTable[hashv].links > 0)
			    {
				lockTable[hashv].links--;
				return 1;
			    }
			else
				abort();
		    }
		prev = tmp;
	    }
	return 0;
}

/*
 * del_from_token_hash_table
 */
int	del_from_token_hash_table(token, tptr)
int	token;
aToken	*tptr;
{
	aToken	*tmp, *prev = NULL;
	int	hashv;

	hashv = hash_int(token, tokenHashSize);
	for (tmp = (aToken *)tokenTable[hashv].list; tmp; tmp = tmp->hnext)
	    {
		if (tmp == tptr)
		    {
			if (prev)
				prev->hnext = tmp->hnext;
			else
				tokenTable[hashv].list = (void *)tmp->hnext;
			tmp->hnext = NULL;
			if (tokenTable[hashv].links > 0)
			    {
				tokenTable[hashv].links--;
				return 1;
			    }
			else
				abort();
		    }
		prev = tmp;
	    }
	return 0;
}

/*
 * hash_find_client
 */
aClient	*hash_find_client(name, cptr)
char	*name;
aClient	*cptr;
{
	aClient	*tmp;
	aClient	*prv = NULL;
	aHashEntry	*tmp3;
	int	hashv;

	hashv = hash_string(name, 0, clientHashSize);
	tmp3 = &clientTable[hashv];

	/*
	 * Got the bucket, now search the chain.
	 */
	for (tmp = (aClient *)tmp3->list; tmp; prv = tmp, tmp = tmp->hnext)
		if (mycmp(name, tmp->name) == 0)
			goto c_move_to_top;
	clientHashMiss++;
	return (cptr);
c_move_to_top:
	clientHashHits++;
	/*
	 * If the member of the hashtable we found isnt at the top of its
	 * chain, put it there.  This builds a most-frequently used order into
	 * the chains of the hash table, giving speadier lookups on those nicks
	 * which are being used currently.  This same block of code is also
	 * used for channels and servers for the same performance reasons.
	 */
	if (prv)
	    {
		aClient *tmp2;

		tmp2 = (aClient *)tmp3->list;
		tmp3->list = (void *)tmp;
		prv->hnext = tmp->hnext;
		tmp->hnext = tmp2;
	    }
	return (tmp);
}

/*
 * hash_find_nickserver
 */
aClient	*hash_find_nickserver(name, cptr)
char	*name;
aClient *cptr;
{
	aClient	*tmp;
	aClient	*prv = NULL;
	aHashEntry	*tmp3;
	int	hashv;
	char	*serv;

	serv = index(name, '@');
	*serv++ = '\0';
	hashv = hash_string(name, 0, clientHashSize);
	tmp3 = &clientTable[hashv];

	/*
	 * Got the bucket, now search the chain.
	 */
	for (tmp = (aClient *)tmp3->list; tmp; prv = tmp, tmp = tmp->hnext)
		if (mycmp(name, tmp->name) == 0 && tmp->user &&
		    mycmp(serv, tmp->where->name) == 0)
			goto c_move_to_top;

	clientHashMiss++;
	*--serv = '\0';
	return (cptr);

c_move_to_top:
	clientHashHits++;
	/*
	 * If the member of the hashtable we found isnt at the top of its
	 * chain, put it there.  This builds a most-frequently used order into
	 * the chains of the hash table, giving speadier lookups on those nicks
	 * which are being used currently.  This same block of code is also
	 * used for channels and servers for the same performance reasons.
	 */
	if (prv)
	    {
		aClient *tmp2;

		tmp2 = (aClient *)tmp3->list;
		tmp3->list = (void *)tmp;
		prv->hnext = tmp->hnext;
		tmp->hnext = tmp2;
	    }
	*--serv = '\0';
	return (tmp);
}

/*
 * hash_find_server
 */
aClient	*hash_find_server(server, cptr)
char	*server;
aClient *cptr;
{
	aClient	*tmp, *prv = NULL;
	char	*t;
	char	ch;
	aHashEntry	*tmp3;

	int hashv;

	hashv = hash_string(server, 0, clientHashSize);
	tmp3 = &clientTable[hashv];

	for (tmp = (aClient *)tmp3->list; tmp; prv = tmp, tmp = tmp->hnext)
	    {
		if (!IsServer(tmp) && !IsMe(tmp))
			continue;
		if (mycmp(server, tmp->name) == 0)
			goto s_move_to_top;
	    }
	t = ((char *)server + strlen(server));
	/*
	 * Whats happening in this next loop ? Well, it takes a name like
	 * foo.bar.edu and proceeds to earch for *.edu and then *.bar.edu.
	 * This is for checking full server names against masks although
	 * it isnt often done this way in lieu of using matches().
	 */
	for (;;)
	    {
		t--;
		for (; t >= server; t--)
			if (*(t+1) == '.')
				break;
		if (t < server || *t == '*')
			break;
		ch = *t;
		*t = '*';
		/*
	 	 * Dont need to check IsServer() here since nicknames cant
		 *have *'s in them anyway.
		 */
		if (((tmp = hash_find_client(t, cptr))) != cptr)
		    {
			*t = ch;
			return (tmp);
		    }
		*t = ch;
	    }
	clientHashMiss++;
	return (cptr);
s_move_to_top:
	clientHashHits++;
	if (prv)
	    {
		aClient *tmp2;

		tmp2 = (aClient *)tmp3->list;
		tmp3->list = (void *)tmp;
		prv->hnext = tmp->hnext;
		tmp->hnext = tmp2;
	    }
	return (tmp);
}

/*
 * hash_find_channel
 */
aChannel	*hash_find_channel(name, chptr)
char		*name;
aChannel	*chptr;
{
	int	hashv;
	aChannel	*tmp, *prv = NULL;
	aHashEntry	*tmp3;

	hashv = hash_string(name, 20, channelHashSize);
	tmp3 = &channelTable[hashv];

	for (tmp = (aChannel *)tmp3->list; tmp; prv = tmp, tmp = tmp->hnextch)
		if (mycmp(name, tmp->chname) == 0)
			goto c_move_to_top;
	channelHashMiss++;
	return chptr;
c_move_to_top:
	channelHashHits++;
	if (prv)
	    {
		aChannel *tmp2;

		tmp2 = (aChannel *)tmp3->list;
		tmp3->list = (void *)tmp;
		prv->hnextch = tmp->hnextch;
		tmp->hnextch = tmp2;
	    }
	return (tmp);
}

/*
 * hash_find_lock
 */
aLock	*hash_find_lock(name, lptr)
char	*name;
aLock	*lptr;
{
	int	hashv;
	aLock	*tmp, *prv = NULL;
	aHashEntry	*tmp3;

	hashv = hash_string(name, 20, lockHashSize);
	tmp3 = &lockTable[hashv];

	for (tmp = (aLock *)tmp3->list; tmp; prv = tmp, tmp = tmp->hnext)
		if (mycmp(name, tmp->lkname) == 0)
			goto l_move_to_top;
	lockHashMiss++;
	return lptr;
l_move_to_top:
	lockHashHits++;
	if (prv)
	    {
		aLock *tmp2;

		tmp2 = (aLock *)tmp3->list;
		tmp3->list = (void *)tmp;
		prv->hnext = tmp->hnext;
		tmp->hnext = tmp2;
	    }
	return (tmp);
}

/*
 * hash_find_token
 */
aToken	*hash_find_token(token, from, tptr)
int	token;
aClient	*from;
aToken	*tptr;
{
	int	hashv;
	aToken	*tmp, *prv = NULL;
	aHashEntry	*tmp3;

	hashv = hash_int(token, tokenHashSize);
	tmp3 = &tokenTable[hashv];

	for (tmp = (aToken *)tmp3->list; tmp; prv = tmp, tmp = tmp->hnext)
		if (tmp->from == from && tmp->token == token)
			goto t_move_to_top;
	tokenHashMiss++;
	return tptr;
t_move_to_top:
	tokenHashHits++;
	if (prv)
	    {
		aToken *tmp2;

		tmp2 = (aToken *)tmp3->list;
		tmp3->list = (void *)tmp;
		prv->hnext = tmp->hnext;
		tmp->hnext = tmp2;
	    }
	return (tmp);
}

void	get_hash_stats(clmin, clmax, chmin, chmax, lkmin, lkmax, tkmin, tkmax)
int	*clmin, *clmax, *chmin, *chmax, *lkmin, *lkmax, *tkmin, *tkmax;
{
	aHashEntry *tmp, *tmp2;
	int	cl_min = 0, cl_max = 0, ch_min = 0, ch_max = 0;
	int	lk_min = 0, lk_max = 0, tk_min = 0, tk_max = 0;

	tmp = clientTable, tmp2 = &clientTable[clientHashSize];
	for (; tmp != tmp2; tmp++)
		if (tmp->links)
		    {
			if (!cl_min)
				cl_min++;
			cl_min = MIN(tmp->links, cl_min);
			cl_max = MAX(tmp->links, cl_max);
		    }

	tmp = channelTable, tmp2 = &channelTable[channelHashSize];
	for (; tmp != tmp2; tmp++)
		if (tmp->links)
		    {
			if (!ch_min)
				ch_min++;
			ch_min = MIN(tmp->links, ch_min);
			ch_max = MAX(tmp->links, ch_max);
		    }

	tmp = lockTable, tmp2 = &lockTable[lockHashSize];
	for (; tmp != tmp2; tmp++)
		if (tmp->links)
		    {
			if (!lk_min)
				lk_min++;
			lk_min = MIN(tmp->links, lk_min);
			lk_max = MAX(tmp->links, lk_max);
		    }

	tmp = tokenTable, tmp2 = &tokenTable[tokenHashSize];
	for (; tmp != tmp2; tmp++)
		if (tmp->links)
		    {
			if (!tk_min)
				tk_min++;
			tk_min = MIN(tmp->links, tk_min);
			tk_max = MAX(tmp->links, tk_max);
		    }

	*clmin = cl_min;
	*clmax = cl_max;
	*chmin = ch_min;
	*chmax = ch_max;
	*lkmin = lk_min;
	*lkmax = lk_max;
	*tkmin = tk_min;
	*tkmax = tk_max;
}
