#include <stdio.h>
#include <stdlib.h>

void	*my_valloc(int size)
{
	void	*ptr;

	if (!(ptr = valloc(size)))
	    {
		printf("error Unable to determine DBUF_DATASIZE\n");
		exit(0);
	    }
	return ptr;
}

void	main(void)
{
	void	*p1, *p2;
	int	i, pageSize;

	p1 = my_valloc(16), p2 = my_valloc(16);
	pageSize = (unsigned long)p2 - (unsigned long)p1;
	free(p2); free(p1);
	for (i = pageSize; i > 0; i -= sizeof(void *))
	    {
		p1 = my_valloc(i), p2 = my_valloc(i);
		if ((unsigned long)p2 - (unsigned long)p1 == pageSize)
		    {
			free(p2); free(p1);
			break;
		    }
		free(p2); free(p1);
	    }
	if (i > 0)
	    {
		printf("/* pageSize=%d pageBlock=%d sizeof(void *)=%d */\n",
		       pageSize, i, sizeof(void *));
		printf("#define DBUF_DATASIZE %d\n", i - sizeof(void *));
	    }
	else
		printf("error Unable to determine DBUF_DATASIZE\n");
	exit(0);
}
