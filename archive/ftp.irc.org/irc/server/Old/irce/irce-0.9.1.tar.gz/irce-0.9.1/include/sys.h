/************************************************************************
 *   IRC - Internet Relay Chat, sys.h
 *   Copyright (C) 1990 University of Oulu, Computing Center
 *   Portions Copyright (C) 1998 Ari Heikkinen
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef	__sys_include__
#define __sys_include__

#ifdef ISC202
# include <net/errno.h>
#else
# include <sys/errno.h>
#endif

#ifdef HAVE_ERRNOH
# include <errno.h>
#endif

#include "setup.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#ifdef HAVE_SYS_PARAMH
# include <sys/param.h>
#endif
#ifdef	HAVE_UNISTDH
# include <unistd.h>
#endif

#ifdef	HAVE_STRINGSH
# include <strings.h>
#else
# ifdef	HAVE_STRINGH
#  include <string.h>
# endif
#endif

#define	strcasecmp	mycmp
#define	strncasecmp	myncmp

#if !defined(bzero) && !defined(HAVE_BZERO)
# define bzero(a, b) memset((a), 0, (b))
#endif
#if !defined(bcopy) && !defined(HAVE_BCOPY)
# define bcopy(a, b, c) memcpy((b), (a), (c))
#endif
#if !defined(bcmp) && !defined(HAVE_BCMP)
# define bcmp(a, b, c) memcmp((b), (a), (c))
#endif

#ifndef HAVE_INDEX
#define   index   strchr
#define   rindex  strrchr
/*
extern	char	*index PROTO((char *, char));
extern	char	*rindex PROTO((char *, char));
*/
#endif

#ifdef HAVE_SYS_SELECTH
# include <sys/select.h>
#endif
#ifdef HAVE_TIMEH
# include <time.h>
#endif
#ifdef HAVE_SYS_TIMEH
# include <sys/time.h>
#endif

#if !defined(DEBUGMODE)
#define	MyFree(x)	do{if((x)!=NULL)free(x);}while(0)
#else
#define	free(x)		MyFree(x)
#endif

#ifdef NEXT
# define VOIDSIG int	/* whether signal() returns int of void */
#else
# define VOIDSIG void	/* whether signal() returns int of void */
#endif

extern	VOIDSIG	dummy();

#ifdef	DYNIXPTX
# define NO_U_TYPES
#endif

#ifdef	NO_U_TYPES
typedef	u_char	u_char;
typedef	u_short	u_short;
typedef	u_long	u_long;
typedef	u_int	u_int;
#endif

#ifdef	USE_VARARGS
# include <varargs.h>
#endif

#endif /* __sys_include__ */
