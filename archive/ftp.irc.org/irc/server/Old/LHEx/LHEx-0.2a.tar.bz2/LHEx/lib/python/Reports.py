"""
This module defines some classes allow incidents to be reported and
the incident database to be searched as appropriate.

Classes:	

Author:		Andrew Snare (ajs@pigpond.com)
Date:		November 18, 1998

Version:	$Id$
"""
from DocumentTemplate import HTMLFile
import os
import Config

# Shortcut
join = os.path.join

class Reports:
    """
    Class that simply holds the documents for our report types.
    """
    def __init__(self):
	"""
	Initialize the incident attributes.
	"""
	# None to initialize yet.
	return

    # Allow any known user to do the report stuff
    __roles__ = ["AnyUser"]

    menu = HTMLFile(join(Config.DTML_LOC,"ReportMenu.dhtml"),
		    Config=Config)
    # Show the menu by default
    index_html = menu

# End
