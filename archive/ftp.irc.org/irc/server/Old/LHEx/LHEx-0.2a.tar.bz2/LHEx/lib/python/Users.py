"""
This module defines some classes that model users.

Classes:	User, UserList

Author:		Andrew Snare (ajs@pigpond.com)
Date:		November 18, 1998

Version:	$Id$
"""
from DocumentTemplate import HTMLFile
import BoboPOS
import string, md5, os, sys
import Config
from ExternalFile import ExternalFile

# Shortcut
join = os.path.join

class User(BoboPOS.Persistent):
    """
    Encapsulates the data pertaining to a user.
    """
    def __init__(self,
		 username='',			# Username
		 id=None,			# ID number of this user
		 passhash='*',			# Hashed password
		 realname='',			# Real name of user
		 email='',			# Email address of user
		 url='',			# URL for user (Homepage?)
		 owner=0):			# Creator/owner of user
	"""
	Initialize the user attributes.
	"""
	# Simply store the provided data
	self.username = username
	self.id = id
	self.passhash = passhash
	self.realname = realname
	self.email = email
	self.url = url
	self.owner = owner

	# And update the authentication to allow the user to edit
	# themselves. Note this should probably be the ID, for if
	# we decide to allow username changes. Ugh. This is also messy 
	# due to BoboPOS limitations on noticing changes.
	roles = self.update__roles__ + ['User:'+self.username]
	self.update__roles__ = self.edit__roles__ = \
	    self.changepass__roles__ = self.chpass__roles__ = roles
	return

    # Allow any known user to view this record
    __roles__ = ["AnyUser"]

    def _setpass(self,password):
	"""
	Set the password for this user.
	"""
	# Generate an MD5 hash of the password and store it.
	m = md5.new()
	m.update(password)
	self.passhash = m.digest()
	return

    def _checkpass(self,password):
	"""
	Check the password for a user.
	"""
	# Generate the MD5 hash of the password and compare to stored value.
	m = md5.new()
	m.update(password)
	return (m.digest() == self.passhash)

    def _hashstr(self):
	"""
	Return a printable string of the password hash.
	"""
	# Use the standard format for printing MD5 sums
	return string.join(map(lambda x:"%02X"%x,map(ord,s)),'')

    def _verifypassword(self,password):
	"""
	Verifies a password is acceptable. For now we only check the
	length.
	"""
	return 6 <= len(password)

    def update(self,realname,email,url,REQUEST):
	"""
	Updates the information associated with a user.
	"""
	if not realname:
	    return HTMLFile(join(Config.DTML_LOC,"InvalidName.dhtml"))\
		   (REQUEST,{'Config':Config,})
	if not email:
	    return HTMLFile(join(Config.DTML_LOC,"InvalidEmail.dhtml"))\
		   (REQUEST,{'Config':Config,})

	# Make the actual changes
	self.realname = realname
	self.email = email
	self.url = url

	# Document that acknowledges the changes
	return HTMLFile(join(Config.DTML_LOC,"UserChanged.dhtml"))\
	       (REQUEST,{'Config':Config, 'username':self.username})

    update__roles__ = ['Admin']			# Only admin can edit users

    def changepass(self,newpass,passrep,REQUEST):
	"""
	Allows the user to change their password.
	"""
	if newpass != passrep:
	    return HTMLFile(join(Config.DTML_LOC,"DiffPass.dhtml"))\
		   (REQUEST,{'Config':Config, 'password':newpass})
	
	# Do the actual password change.
	self._setpass(newpass)

	# Acknowledge the password change
	return HTMLFile(join(Config.DTML_LOC,"PassChanged.dhtml"))\
	       (REQUEST,{'Config':Config, 'username':self.username})	

    changepass__roles__ = update__roles__

    show = HTMLFile(join(Config.DTML_LOC,"UserInfo.dhtml"),
		    Config=Config)
    edit = HTMLFile(join(Config.DTML_LOC,"EditUser.dhtml"),
		    Config=Config)
    edit__roles__ = update__roles__		# Prevention better than cure
    chpass = HTMLFile(join(Config.DTML_LOC,"ChangePass.dhtml"),
	     Config=Config)
    chpass__roles__ = changepass__roles__      	# Prevention better than cure
    # Use the showuser method by default
    index_html = show
    # Some support graphics
    edit_jpg = ExternalFile(join(Config.DTML_LOC,"Edit.jpg"),"image/jpeg")
    chpass_jpg = ExternalFile(join(Config.DTML_LOC,"ChangePass.jpg"),
			      "image/jpeg")

class UserList(BoboPOS.Persistent):
    """
    Manages a list of users.
    """
    def __init__(self):
	"""
	Initialize the list of users we know about.
	"""
	self.userids = []			# Start off empty
	self.usernames = {}			# Maps to ID, not object

    def __getitem__(self,key):
	"""
	Allow hash lookup to map onto the userlist.
	"""
	try:
	    try:
		id = string.atoi(key)
		return self.userids[id]
	    except ValueError:
		return self.userids[self.usernames[key]]
	except IndexError,KeyError:
	    raise "Not Found"
	return					# Never reached

    # Make this object viewable by any known user
    __roles__ = ["AnyUser"]

    def _verifyusername(self,username):
	"""
	Determines if a username is acceptable and not already used.
	"""
	# Usernames must be at least 3 characters long, and only
	# alphanumeric

	# Probably inefficient, but easy anyway
	hash = {}
	for char in string.lowercase + string.uppercase + string.digits:
	    hash[char] = None

	return (len(username) >= 3) and \
	       (len(username) == len(filter(hash.has_key,username))) and \
	       (not self.usernames.has_key(username))

    def _adduser(self,username,password,realname,email,url,owner):
	"""
	Adds a new user to the userlist.
	"""
	# Work out the next ID and add it to the list
	nextid = len(self.userids)
	newuser = User(username,nextid,None,realname,email,url,owner)
	newuser._setpass(password)
	self.userids = self.userids + [newuser]	# Need to act immutably
	self.usernames[username] = nextid
	self.usernames = self.usernames		# So that POS picks up change

	return

    def createuser(self,username,password,passrep,realname,email,url,REQUEST):
	"""
	Exported web interface for adding a new user to the userlist.
	"""
	# Check the supplied parameters for validity
	if not self._verifyusername(username):
	    return HTMLFile(join(Config.DTML_LOC,"InvalidUser.dhtml"))\
		   (REQUEST,{'Config':Config, 'username':username,
			     'usernames':self.usernames})
	if password != passrep:
	    return HTMLFile(join(Config.DTML_LOC,"DiffPass.dhtml"))\
		   (REQUEST,{'Config':Config, 'password':password})
	if not realname:
	    return HTMLFile(join(Config.DTML_LOC,"InvalidName.dhtml"))\
		   (REQUEST,{'Config':Config})
	if not email:
	    return HTMLFile(join(Config.DTML_LOC,"InvalidEmail.dhtml"))\
		   (REQUEST,{'Config':Config})
	# Do the actual work
	self._adduser(username,password,realname,email,url,
		      REQUEST['AUTHENTICATED_USER'].id)

	# Return something to indicate the user was successfully added
	retdoc = HTMLFile(join(Config.DTML_LOC,"UserAdded.dhtml"))\
		 (REQUEST,{'Config':Config, 'username':username})
	return retdoc
    
    createuser__roles__ = ['Admin']		# Only admin can create users

    adduser = HTMLFile(join(Config.DTML_LOC,"AddUser.dhtml"),
		       Config=Config)
    adduser__roles__ = createuser__roles__	# Prevention better than cure

    listusers = HTMLFile(join(Config.DTML_LOC,"UserList.dhtml"),
			 Config=Config)
    index_html = listusers

# End
