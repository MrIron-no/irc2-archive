"""
This module contains the definition and default values for
configurable LHEx items.
"""
class Admin:
    """
    Holds information about the administrator of this LHEx site.
    """
    username = "Lamer"
    realname = "Someone-who-hasn't-read-the-documentation"
    email = "doofus@localhost"
    url = "http://localhost/"

admin = Admin()

class Version:
    """
    Holds version information for the current LHEx package.
    """
    major = 0
    minor = 2
    release = "a"
    date = "$Date: 1998/09/13 15:09:16 $"[1:-2]
    def __str__(self):
	"""
	Returns the version string.
	"""
	return "%d.%d%s (%s)" % (self.major,self.minor,
				 self.release,self.date)

version = Version()

# Default string printed at the bottom
footer = "LHEx %s" % str(version)

# Try to guess the location of our software. This can be a relative or
# explicit path.
import os
basedir = os.path.join(os.path.dirname(__file__),'../../..')

# Location of HTML files, templates and other miscellany.
DTML_LOC=os.path.join(basedir,"lib/www")
# Location of the database files
DATA_LOC=os.path.join(basedir,"var")

# End.
