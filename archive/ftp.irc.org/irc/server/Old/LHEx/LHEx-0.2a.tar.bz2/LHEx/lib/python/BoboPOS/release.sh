#!/bin/sh

R=$1
M=BoboPOS

StructuredText -t < $M.stx > $M.html
StructuredText -t <release.notes >../BoboPOS-rn.html
StructuredText -t <release.notes >BoboPOS-rn.html
StructuredText -t <release.notes >release.html
StructuredText -t <BoboPOS.stx >BoboPOS.html
rm -rf "$M-$R"
mkdir  "$M-$R" "$M-$R/$M"
echo
for f in `cat pyfiles`; do
  python1.5 -c "import sys; sys.path.append('..'); from tabnanny import *; f='$f'; check(f)"
  cp f "$M-$R/$M"
done 
echo
for f in `cat other_files`; do
  cp f "$M-$R
done 
tar cvf "$M-$R.tar" "$M-$R"
rm -f "$M-$R.tar.gz" "$M-$R
gzip "$M-$R.tar"
