/*****************************************************************************
  
  Zope Public License (ZPL) Version 0.9.5
  ---------------------------------------
  
  Copyright (c) Digital Creations.  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are
  met:
  
  1. Redistributions in source code must retain the above copyright
     notice, this list of conditions, and the following disclaimer.
  
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions, and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.
  
  3. Any use, including use of the Zope software to operate a website,
     must either comply with the terms described below under
     "Attribution" or alternatively secure a separate license from
     Digital Creations.  Digital Creations will not unreasonably
     deny such a separate license in the event that the request
     explains in detail a valid reason for withholding attribution.
  
  4. All advertising materials and documentation mentioning
     features derived from or use of this software must display
     the following acknowledgement:
  
       "This product includes software developed by Digital Creations
       for use in the Z Object Publishing Environment
       (http://www.zope.org/)."
  
     In the event that the product being advertised includes an
     intact Zope distribution (with copyright and license included)
     then this clause is waived.
  
  5. Names associated with Zope or Digital Creations must not be used to
     endorse or promote products derived from this software without
     prior written permission from Digital Creations.
  
  6. Modified redistributions of any form whatsoever must retain
     the following acknowledgment:
  
       "This product includes software developed by Digital Creations
       for use in the Z Object Publishing Environment
       (http://www.zope.org/)."
  
     Intact (re-)distributions of any official Zope release do not
     require an external acknowledgement.
  
  7. Modifications are encouraged but must be packaged separately as
     patches to official Zope releases.  Distributions that do not
     clearly separate the patches from the original work must be clearly
     labeled as unofficial distributions.  Modifications which do not
     carry the name Zope may be packaged in any form, as long as they
     conform to all of the clauses above.
  
  
  Disclaimer
  
    THIS SOFTWARE IS PROVIDED BY DIGITAL CREATIONS ``AS IS'' AND ANY
    EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL DIGITAL CREATIONS OR ITS
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
    USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
    OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGE.
  
  Attribution
  
    Individuals or organizations using this software as a web site must
    provide attribution by placing the accompanying "button" and a link
    to the accompanying "credits page" on the website's main entry
    point.  In cases where this placement of attribution is not
    feasible, a separate arrangment must be concluded with Digital
    Creations.  Those using the software for purposes other than web
    sites must provide a corresponding attribution in locations that
    include a copyright using a manner best suited to the application
    environment.  Where attribution is not possible, or is considered
    to be onerous for some other reason, a request should be made to
    Digital Creations to waive this requirement in writing.  As stated
    above, for valid requests, Digital Creations will not unreasonably
    deny such requests.
  
  This software consists of contributions made by Digital Creations and
  many individuals on behalf of Digital Creations.  Specific
  attributions are listed in the accompanying credits file.
  
 ****************************************************************************/
static char cTree_module_documentation[] = 
""
"\n$Id: iTree.c,v 1.6 1998/12/04 20:15:27 jim Exp $"
;

#include <limits.h>
#include "ExtensionClass.h"

static void PyVar_Assign(PyObject **v, PyObject *e) { Py_XDECREF(*v); *v=e;}
#define ASSIGN(V,E) PyVar_Assign(&(V),(E))
#define UNLESS(E) if(!(E))
#define UNLESS_ASSIGN(V,E) ASSIGN(V,E); UNLESS(V)
#define RETURN_NONE Py_INCREF(Py_None); return Py_None

#define MIN_BUCKET_ALLOC 8
#define MAX_SIZE(N) 16

typedef struct {
  PyObject_HEAD
  int size, len;
  int *data;
} Bucketobject;

staticforward PyExtensionClass BucketType;

#define BUCKET(O) ((Bucketobject*)(O))
#define Bucket_Check(O) ((O)->ob_type==(PyTypeObject*)&BucketType)

#define BLOCK_SHIFT 2
#define BLOCK_SIZE 4
#define BLOCK_MASK 3
#define ITEM_SIZE 5

static void *
PyMalloc(size_t sz)
{
  void *r;

  if(r=malloc(sz)) return r;
  PyErr_NoMemory();
  return NULL;
}

static void *
PyRealloc(void *p, size_t sz)
{
  void *r;

  if(r=realloc(p,sz)) return r;
  PyErr_NoMemory();
  return NULL;
}

static PyObject *
b_get(Bucketobject *self, PyObject *args)
{
  int min, max, i, l, k, key, voff;

  UNLESS(PyArg_Parse(args,"i",&key)) return NULL;
  
  /* Get value offset, based on remainder of division by 4 */
  voff=(key&BLOCK_MASK)+1;  
  key >>= BLOCK_SHIFT;
  
  for(min=0, max=self->len, i=max/2, l=max; i != l; l=i, i=(min+max)/2)
    {
      k=self->data[i*ITEM_SIZE];
      if(k == key)
	{
	  i=self->data[i*ITEM_SIZE+voff];
	  if(i==INT_MIN) break;
	  return PyInt_FromLong(i);
	}
      if(k > key) max=i;
      else min=i;
    }
  PyErr_SetObject(PyExc_KeyError, args);
  return NULL;
}

static int
b_setitem(Bucketobject *self, PyObject *key, PyObject *v)
{
  int min, max, i, l, s, *data, k, iv, ikey, voff;
  
  ikey=PyInt_AsLong(key);
  if(ikey == -1 && PyErr_Occurred()) return -1;
  if(v)
    {
      iv=PyInt_AsLong(v);
      if(iv == -1 && PyErr_Occurred()) return -1;
    }
  else iv=INT_MIN;
  
  voff=(ikey&BLOCK_MASK)+1;  
  ikey >>= BLOCK_SHIFT;
  
  data=self->data;

  for(min=0, max=self->len, i=max/2, l=max; i != l; l=i, i=(min+max)/2)
    {
      k=data[i*ITEM_SIZE];
      if(k == ikey)
	{
	  data[i*ITEM_SIZE+voff]=iv;
	  return 0;
	}
      if(k > ikey) max=i;
      else min=i;
      
    }
  if(!v)
    {
      PyErr_SetObject(PyExc_KeyError, key);
      return -1;
    }
  if(self->len==self->size)
    {
      if(self->data)
	{
	  UNLESS(data=PyRealloc(self->data,
				sizeof(int)*(self->size*2*ITEM_SIZE)))
	    return -1;
	  self->data=data;
	  self->size*=2;
	}
      else
	{
	  UNLESS(self->data=PyMalloc(sizeof(int)*(MIN_BUCKET_ALLOC*ITEM_SIZE)))
	    return -1;
	  self->size=MIN_BUCKET_ALLOC;
	}
    }
  if(max != i) i++;
  data=self->data+ITEM_SIZE*i;
  if(self->len > i)memmove(data+ITEM_SIZE,data,
			   (self->len-i)*ITEM_SIZE*sizeof(int));
  *data=ikey;
  for(i=1; i < ITEM_SIZE; i++) data[i]=INT_MIN;
  data[voff]=iv;
  self->len++;
  return 0;
}

static PyObject *
b_keys(Bucketobject *self, PyObject *args)
{
  PyObject *r, *item;
  int i, l, voff, k, *d, v;

  UNLESS(r=PyList_New(0)) return NULL;

  for(i=0, l=self->len, d=self->data; i < l; i++, d+=ITEM_SIZE)
    for(voff=1; voff < ITEM_SIZE; voff++)
      {
	v=d[voff];
	if(v!=INT_MIN)
	  {
	    k=((*d) << BLOCK_SHIFT) + voff - 1;
	    UNLESS(item=PyInt_FromLong(k)) goto err;
	    if(PyList_Append(r, item) < 0) goto err;
	    Py_DECREF(item);
	  }
      }

  return r;

err:
  Py_DECREF(r);
  return NULL;
}

static PyObject *
b_values(Bucketobject *self, PyObject *args)
{
  PyObject *r, *item;
  int i, l, voff, *d, v;

  UNLESS(r=PyList_New(0)) return NULL;

  for(i=0, l=self->len, d=self->data; i < l; i++, d+=ITEM_SIZE)
    for(voff=1; voff < ITEM_SIZE; voff++)
      {
	v=d[voff];
	if(v!=INT_MIN)
	  {
	    UNLESS(item=PyInt_FromLong(v)) goto err;
	    if(PyList_Append(r, item) < 0) goto err;
	    Py_DECREF(item);
	  }
      }

  return r;

err:
  Py_DECREF(r);
  return NULL;
}

static PyObject *
b_items(Bucketobject *self, PyObject *args)
{
  PyObject *r, *item;
  int i, l, voff, k, *d, v;

  UNLESS(r=PyList_New(0)) return NULL;

  for(i=0, l=self->len, d=self->data; i < l; i++, d+=ITEM_SIZE)
    for(voff=1; voff < ITEM_SIZE; voff++)
      {
	v=d[voff];
	if(v!=INT_MIN)
	  {
	    k=((*d) << BLOCK_SHIFT) + voff - 1;
	    UNLESS(item=Py_BuildValue("ii",k,v)) goto err;
	    if(PyList_Append(r, item) < 0) goto err;
	    Py_DECREF(item);
	  }
      }
  
  return r;

err:
  Py_DECREF(r);
  return NULL;
}

static PyObject *
b___getstate__(Bucketobject *self, PyObject *args)
{
  return PyString_FromStringAndSize((char*)self->data,
				    self->len*ITEM_SIZE*sizeof(int));
}
  
static PyObject *
b_clear(Bucketobject *self, PyObject *args)
{
  self->len=0;
  RETURN_NONE;
}

static PyObject *
b___setstate__list(Bucketobject *self, PyObject *data)
{
  PyObject *ok=0, *ov=0, *r=0;
  int i, k, v, l;

  if((l=PyObject_Length(data)) < 0) return NULL;

  b_clear(self, NULL);
  
  for(i=0; i < l; i+= 2)
    {
      UNLESS_ASSIGN(ok,PySequence_GetItem(data,i  )) goto err;
      UNLESS_ASSIGN(ov,PySequence_GetItem(data,i+1)) goto err;
      if(b_setitem(self,ok,ov) < 0) goto err;
    }

  r=Py_None;
  Py_INCREF(r);

err:
  Py_XDECREF(ok);
  Py_XDECREF(ov);
  return r;
}

static PyObject *
b___setstate__(Bucketobject *self, PyObject *args)
{
  PyObject *data;
  char *cdata;
  int *d;
  int l;

  UNLESS(PyArg_ParseTuple(args,"O",&data)) return NULL;
  UNLESS(PyString_Check(data)) return b___setstate__list(self, data);
  UNLESS(cdata=PyString_AsString(data)) return NULL;
  if((l=PyString_Size(data)) < 0) return NULL;

  l /= ITEM_SIZE*sizeof(int);
  self->len=self->size=l;
  l *= ITEM_SIZE*sizeof(int);  
  UNLESS(d=PyRealloc(self->data,l)) return NULL;
  self->data=d;
  memcpy(d, cdata, l);
  Py_INCREF(Py_None);
  return Py_None;
}  

static PyObject *
has_key(Bucketobject *self, PyObject *args)
{
  PyObject *key;

  UNLESS(PyArg_ParseTuple(args,"O",&key)) return NULL;
  if(args=b_get(self,key))
    {
      Py_DECREF(args);
      return PyInt_FromLong(1);
    }
  PyErr_Clear();
  return PyInt_FromLong(0);
}

static PyObject *
max_key(Bucketobject *self, PyObject *args)
{
  int *d, v, k, i, m=INT_MIN, voff;

  for(i=self->len, d=self->data+(self->len-1)*ITEM_SIZE; --i >= 0;
      d-=ITEM_SIZE)
    for(voff=ITEM_SIZE; --voff > 0; )
      {
	v=d[voff];
	if(v > m)
	  {
	    m=v;
	    k=((*d) << BLOCK_SHIFT) + voff - 1;
	  }
	if(m != INT_MIN) return PyInt_FromLong(k);
      }
  return PyInt_FromLong(0);
}

static PyObject *
max_value(Bucketobject *self, PyObject *args)
{
  int max=INT_MIN, i, j, k, v;
  
  for(i=self->len; --i >= 0; )
    {
      for(k=i*ITEM_SIZE, j=k+ITEM_SIZE; j > k; j--)
	{
	  v=self->data[j];
	  if(v > max) max=v;
	}
    }

  return PyInt_FromLong(max);
}

static struct PyMethodDef Bucket_methods[] = {
  {"has_key",	(PyCFunction)has_key,	METH_VARARGS,
   "has_key(key) -- Test whether the tree has the given key"},
  {"max_key",	(PyCFunction)max_key,	METH_VARARGS,
   "max_key() -- Return the largest key"},
  {"max_value",	(PyCFunction)max_value,	METH_VARARGS,
   "max_value() -- Return the largest value"},
  {"keys",	(PyCFunction)b_keys,	METH_VARARGS,
   "keys() -- Return the keys"},
  {"values",	(PyCFunction)b_values,	METH_VARARGS,
   "values() -- Return the values"},
  {"items",	(PyCFunction)b_items,	METH_VARARGS,
   "items() -- Return the items"},
  {"clear",	(PyCFunction)b_clear,	METH_VARARGS,
   "clear() -- Remove all of the items from the bucket"},  
  {"__getstate__",	(PyCFunction)b___getstate__,	METH_VARARGS,
   "__getstate__() -- get the persistent state"},  
  {"__setstate__",	(PyCFunction)b___setstate__,	METH_VARARGS,
   "__setstate__() -- set the persistent state"},  
  {NULL,		NULL}		/* sentinel */
};

static void
Bucket_dealloc(Bucketobject *self)
{
  free(self->data);
  PyMem_DEL(self);
}

static PyObject *
Bucket_getattr(Bucketobject *self, PyObject *name)
{
  return Py_FindAttr((PyObject *)self, name);
}


/* Code to access Bucket objects as mappings */

static int
Bucket_length( Bucketobject *self)
{
  return self->len;
}

static PyMappingMethods Bucket_as_mapping = {
  (inquiry)Bucket_length,		/*mp_length*/
  (binaryfunc)b_get,		/*mp_subscript*/
  (objobjargproc)b_setitem,	/*mp_ass_subscript*/
};

static PyObject *
b_repr(Bucketobject *self)
{
  static PyObject *format;
  PyObject *r;

  UNLESS(format) UNLESS(format=PyString_FromString("Bucket(%s)")) return NULL;
  UNLESS(r=b_items(self,NULL)) return NULL;
  ASSIGN(r,Py_BuildValue("(O)",r));
  if(r) ASSIGN(r,PyString_Format(format,r));
  return r;
}

static PyExtensionClass BucketType = {
  PyObject_HEAD_INIT(NULL)
  0,				/*ob_size*/
  "Bucket",			/*tp_name*/
  sizeof(Bucketobject),	/*tp_basicsize*/
  0,				/*tp_itemsize*/
  /* methods */
  (destructor)Bucket_dealloc,	/*tp_dealloc*/
  (printfunc)0,	/*tp_print*/
  (getattrfunc)0,		/*obsolete tp_getattr*/
  (setattrfunc)0,		/*obsolete tp_setattr*/
  (cmpfunc)0,	/*tp_compare*/
  (reprfunc)b_repr,		/*tp_repr*/
  0,		/*tp_as_number*/
  0,		/*tp_as_sequence*/
  &Bucket_as_mapping,		/*tp_as_mapping*/
  (hashfunc)0,		/*tp_hash*/
  (ternaryfunc)0,	/*tp_call*/
  (reprfunc)0,		/*tp_str*/
  (getattrofunc)Bucket_getattr,			/*tp_getattro*/
  0,			/*tp_setattro*/
  
  /* Space for future expansion */
  0L,0L,
  "Integer mapping type implemented as sorted list of items", 
  METHOD_CHAIN(Bucket_methods),
  EXTENSIONCLASS_BASICNEW_FLAG,
};

static struct PyMethodDef module_methods[] = {
  {NULL,		NULL}		/* sentinel */
};

void
initiTree()
{
  PyObject *m, *d;
  char *rev="$Revision: 1.6 $";

  /* Create the module and add the functions */
  m = Py_InitModule4("iTree", module_methods,
		     cTree_module_documentation,
		     (PyObject*)NULL,PYTHON_API_VERSION);

  /* Add some symbolic constants to the module */
  d = PyModule_GetDict(m);

  PyExtensionClass_Export(d,"Bucket",BucketType);

  PyDict_SetItemString(d, "__version__",
		       PyString_FromStringAndSize(rev+11,strlen(rev+11)-2));
  
	
  /* Check for errors */
  if (PyErr_Occurred())
    Py_FatalError("can't initialize module iTree");
}

/*****************************************************************************
Revision Log:

  $Log: iTree.c,v $
  Revision 1.6  1998/12/04 20:15:27  jim
  Detabification and new copyright.

  Revision 1.5  1997/12/12 23:47:46  jim
  Added basicnew support.

  Revision 1.4  1997/07/30 17:43:33  jim
  Added max_values method.

  Revision 1.3  1997/07/18 15:07:40  jim
  Changed way getstate/setstate work to use (non-portable) string image
  of data.

  Revision 1.2  1997/05/09 15:21:44  jim
  Added has_key and max_key methods.

  Revision 1.1  1997/05/08 19:28:28  jim
  *** empty log message ***

  $Revision 1.1  1997/02/24 23:25:42  jim
  $initial
  $

*****************************************************************************/
