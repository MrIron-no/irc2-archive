"""
This is the configuration file for LHEx. It should be tailored for
each installation. Defaults are found in ConfigDefaults.py.
"""
from Defaults import *

# All configuration should be done here. See configDefaults.py for what
# can be configured.
admin.username = "ajs"
admin.realname = "Andrew Snare"
admin.email = "ajs@pigpond.com"
admin.url = "http://www.pigpond.com/~earthpig"

# End.
