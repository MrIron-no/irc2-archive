"""
This module defines a single class (ExternalFile) used for returning
files (as static objects).

Author: Andrew
  Date: 8th January, 1999
    ID: $Id$

XXX: Hmmm. Need to put copyright and stuff in here.
"""
import os

class ExternalFile:
    """
    Object containing data stored in (static) external file.
    Inspired by Zope's ImageFile object.
    """

    def __init__(self,path,mimetype="text/html"):
	"""
	Simply initialize the data we need to know.
	"""

	self.path = path
	self.content_type = mimetype
	self.__name__ = os.path.split(path)[1]
	return

    def index_html(self,RESPONSE):
	"""
	Return the image data.
	"""
	f = open(self.path, 'rb')		# Lazy evaluation.
	imagedata = f.read()
	f.close()
	RESPONSE['content-type'] = self.content_type
	return imagedata

# End.
