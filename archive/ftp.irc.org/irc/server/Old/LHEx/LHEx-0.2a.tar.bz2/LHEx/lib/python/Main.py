"""
This application (LHEx) is a tool for the management of K-Lines for an
IRC Server. It was developed using Bobo.

Author: Andrew Snare
  Date: 9th September, 1998
    ID: $Id: Main.py,v 1.1 1998/09/13 15:09:15 earthpig Exp $

XXX: Hmmm. Need to put the copyright and license information in here.
"""
import DocumentTemplate, BoboPOS
import Config
import Users
import LHEx

# The application we're publishing:
global app
app = LHEx.Application()
bobo_application = app

# This sets the realm we use for Basic authentication
__bobo_realm__ = "LHEx"

# This enables (visible) traceback dumps upon error.
__bobo_hide_tracebacks__ = 0

# End.
