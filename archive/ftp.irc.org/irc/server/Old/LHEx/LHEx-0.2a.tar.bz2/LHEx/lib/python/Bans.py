"""
This module defines some classes that model bans.

Classes:	Ban
		BanList

Author:		Andrew Snare (ajs@pigpond.com)
Date:		February 8, 1999.

Version:	$Id$
"""
from DocumentTemplate import HTMLFile
import BoboPOS
import Config, Util
import os, re, fnmatch, time, string
import thread

# Shortcut
join = os.path.join

class Ban(BoboPOS.Persistent):
    """
    Encapsulates a single ban.
    """
    def __init__(self,banmask=""):
	"""
	Initialize the ban.
	"""
	self.banmask = banmask
	self._regex = re.compile(fnmatch.translate(banmask), re.IGNORECASE)
	self.incidents = []
	
	self.expiry = None
	self._calcexpiry()

	return

    def _calcexpiry(self):
	"""
	Calculates when we expire.
	"""
	expires = None
	_banlock.acquire()
	for incident in self.incidents:
	    check = incident.expiry
	    if (not (check is None)) and (check > expires):
		expires = check
	self.expiry = expires
	_banlock.release()

	return expires

    def _addincident(self,incident):
	"""
	Adds an incident that references this ban.
	"""
	# Add the new incident to the list
	_banlock.acquire()
	if incident not in self.incidents:
	    self.incidents.append(incident)
	    self.incidents = self.incidents		# So BoboPOS gets it

	# Recalc our expiry (incrementally).
	check = incident.expiry
	if (not (check is None)) and (check > self.expiry):
	    self.expiry = check
	_banlock.release()
	
	return

    def _delincident(self,incident):
	"""
	Deletes an incident that references this ban.
	"""
	# Remove the incident from the list (if we can)
	try:
	    _banlock.acquire()
	    del self.incidents[self.incidents.index(incident)]
	    self.incidents = self.incidents		# So BoboPOS gets it
	except ValueError:
	    _banlock.release()
	else:
	    _banlock.release()
	    self._calcexpiry()

	return

    def expired(self):
	"""
	Returns true if this ban has expired.
	"""
	return time.time() >= self.expiry

    def _match(self,userhost):
	"""
	Returns true if this ban hasn't expired and the user@host
	provided matches this ban.
	"""
	return not self.expired() and self._regex.match(userhost)

    __roles__ = ['AnyUser']

    show = HTMLFile(join(Config.DTML_LOC,"BanInfo.dhtml"),
		    ctime=Util.ctime, time=time.time, Config=Config)

    # By default, simply show the ban information
    index_html = show

class BanList(BoboPOS.Persistent):
    """
    Encapsulates a list of bans.
    """
    def __init__(self):
	"""
	Initialize our hash table and stuff.
	"""
	self.bans = {}
	return

    def __getitem__(self,key):
	"""
	Allow a hash lookup to map onto the ban list.
	"""
	try:
	    return self.bans[key]
	except ValueError:
	    raise "Not Found"
	return						# Never reached

    def _addban(self,ban,incident):
	"""
	Adds a ban to our list.
	"""
	# If the ban doesn't already exist, make it
	_listlock.acquire()
	if not self.bans.has_key(ban):
	    self.bans[ban] = Ban(ban)
	    self.bans = self.bans			# So BoboPOS gets it
	_listlock.release()

	# Add a reference to our incident
	self.bans[ban]._addincident(incident)

	return

    def _matchbans(self,userhost):
	"""
	Returns all bans which match the user@host given.
	"""
	matching = []
	for ban in self.bans.values():
	    if ban._match(userhost):
		matching.append(ban)

	return matching
	
    def _matchincidents(self,userhost):
	"""
	Returns all incidents which contain a ban referring
	to the given user@host.
	"""
	bans = self._matchbans(userhost)
	incidents = {}
	# For each ban, we first expunge all expired incidents and
	# then merge them with our list
	for ban in bans:
	    for incident in ban.incidents:
		if not incident.expired():
		    incidents[incident.id] = incident

	# *grumble* This sorting thing slows us down a bit
	ids = incidents.keys()
	ids.sort()
	incidentlist = []
	for id in ids:
	    incidentlist.append(incidents[id])
	return incidentlist

    def match(self,userhost,REQUEST):
	"""
	Performs a search for bans/incidents that match the given.
	userhost.
	"""
	bans = self._matchbans(userhost)
	incidents = self._matchincidents(userhost)

	# Document that formats the search results
	return HTMLFile(join(Config.DTML_LOC,"BanMatches.dhtml"))\
	       (REQUEST,{'Config':Config, 'userhost':userhost, 'bans':bans,
			 'incidents':incidents, 'ctime':Util.ctime})

    __roles__ = ["AnyUser"]

    check = HTMLFile(join(Config.DTML_LOC,"BanCheck.dhtml"), Config=Config)

    listall = HTMLFile(join(Config.DTML_LOC,"BanList.dhtml"), Config=Config)
    listall__roles__ = ["AnyUser"]

    # For now, by default, we list all the K-lines.
    index_html = check

# These locks shouldn't be global, but unfortunately they can't be pickled.
_listlock = thread.allocate_lock()
_banlock = thread.allocate_lock()		# Serializes ban stuff... DOH!

# End.
