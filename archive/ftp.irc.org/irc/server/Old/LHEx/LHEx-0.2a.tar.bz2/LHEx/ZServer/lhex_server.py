import socket, string
from medusa import asynchat, asyncore, producers

from Main import app

class lhex_server(asyncore.dispatcher):

    def __init__(self, port):
	asyncore.dispatcher.__init__(self)
	self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
	self.set_reuse_addr()
	here = ('', port)
	self.bind(here)
	self.listen(5)
	return

    def handle_accept(self):
	lhex_receiver(self, self.accept())
	return

class lhex_receiver(asynchat.async_chat):

    channel_counter = 0

    def __init__(self, server, (conn, addr)):
	asynchat.async_chat.__init__(self,conn)
	self.set_terminator('\n')
	self.server = server
	self.id = self.channel_counter
	self.channel_counter = self.channel_counter + 1
	self.buffer = ''
	return

    def collect_incoming_data(self, data):
	self.buffer = self.buffer + data
	return

    def found_terminator(self):
	data = self.buffer
	self.buffer = ''
	self.push_with_producer(lhex_factory(data))
	return
	
    def handle_close(self):
	self.close()
	return

def lhex_factory(request):
    """
    Factory that returns a producer with the required data.
    """
    print "Request:", request
    components = { 'ident': '*',
		   'host' : '*',
		   'id'   : 0 }
    for component in string.split(request):
	try:
	    (type, info) = string.split(component, ':')
	    components[type] = info
	except ValueError: pass

    userhost = '%s@%s' % (components['ident'], components['host'])
    incidents = app.bans._matchincidents(userhost)
    id = components['id']

    reply = []
    
    if incidents:
	reply.append('%s: You are not permitted to use this IRC server.' % id)
	reply.append('%s: Not OK' % id)
    else:
	reply.append('%s: OK' % id)

    print "Replying:", `reply`

    return producers.lines_producer(reply)

# End.
