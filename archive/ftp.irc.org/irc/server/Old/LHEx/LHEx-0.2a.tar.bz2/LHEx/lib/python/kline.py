"""
This module defines some classes that model a K-line.

Classes:	Hostmask
		KLine

Author:		Andrew Snare (ajs@pigpond.com)
Date:		April 10, 1998.

Version:	0.1

NOTE: THIS WAS AN EARLY VERSION, NO LONGER IN USE. IT IS SUPERSEDED
      BY THE REST OF THE MODULES, AND IS PURELY HERE FOR HISTORICAL
      REASONS.
"""
import string
from types import ListType
from time import time, ctime

class Hostmask:
    """
    Encapsulates the description of a host.
    """
    def __init__(self, hostname=None, ip=None, netmask=None, resolving=0):
	"""
	Initialise the host description. By default we match everything.
	"""
	self.hostname = hostname
	self.ip = ip
	self.netmask = netmask
	self.resolving = resolving

    def __str__(self):
	"""
	Returns a string representation of the hostmask
	(understandable by ircd).
	"""
	return self.gethost()

    def __repr__(self):
	"""
	Returns a more readable string representation of the hostmask.
	"""
	return self.hostdesc()

    def gethost(self):
	"""
	Return a description of the hostmask that ircd will understand.
	"""
	if self.hostname:
	    return self.hostname
	elif self.ip:
	    if self.resolving:
		retstr = '=' + self.ip
	    else:
		retstr = self.ip
	else:
	    retstr = '*'
	if self.netmask:
	    if string.find(self.ip,'*') == -1:
		try:
		    retstr = retstr + '/' + self.netmask
		except TypeError:
		    retstr = retstr + '/' + `self.netmask`
	return retstr

    def hostdesc(self):
	"""
	Returns a description of the hostmask we describe.
	Not very smart right now.
	"""
	if self.hostname == '*':
	    return 'All'
	else:
	    return self.gethost()

class Incident:
    """
    Encapsulates the behavious of an incident.
    """
    def __init__(self,
		 klines=[KLine('*@*')],         # Default to a single K-Line
		 reason='',			# No reason for user
		 id=None,			# Unique ID for the K-Line
		 owner='',			# No-one owns the K-line
		 offendhosts=[],		# List of offending hosts empty
		 logs=[],			# No logs associated
		 type=None,			# Type of offence undefined
		 date=None,			# K-line created now
		 expires=None,			# K-Line time of the K-Line
		 checked=None,			# Date last checked
		 reviewdate=None,		# Date of next review
		 xrefs={},			# Cross-references
		 remarks=''):			# No (internal use) comments
	"""
	Initialize the K-line attributes.
	"""
	self.hostmask = hostmask
	self.authmask = authmask
	self.reason = reason
	if not id:
	    # No ID supplied, need to generate a unique ID
	    self.id = self.generateid()
	else:
	    self.id = id
	self.offendhosts = offendhosts
	self.logs = logs
	self.type = type
	self.owner = owner
	if date:
	    self.date = date
	else:
	    self.date = time()
	self.expires = expires
	self.checked = checked
	self.reviewdate = reviewdate
	self.xrefs = xrefs
	self.remarks = remarks
	return

    def __str__(self):
	"""
	Return a string representation of the K-Line that ircd understands.
	"""
	return self.formatkline()

    def __repr__(self):
	"""
	Return a string representation of the K-Line that people
	understand.
	"""
	return self.prettyprint()

    def formatkline(self):
	"""
	Formats the k-line in a way that ircd can understand.
	"""
	return 'K:%s:%s:%s:0:' % (str(self.hostmask),
				   self.reason,
				   self.authmask)

    def prettytabify(self,s):
	"""
	Formats a (multi-line) string nicely to display for
	prettyprint.
	"""
	return string.join(s,'\n\t          ')

    def prettyprint(self):
	"""
	Format the k-line in a more readable manner with all
	information given.
	"""
	if self.authmask == '*':
	    authmask = 'All'
	else:
	    authmask = self.authmask
	if not self.reason:
	    reason = 'None'
	else:
	    reason = self.reason
	if not self.id:
	    id = 'None'
	else:
	    id = str(self.id)
	if not self.offendhosts:
	    offendhosts = 'None'
	else:
	    offendhosts = self.prettytabify(self.offendhosts)
	if not self.logs:
	    logs = 'None'
	else:
	    logs = string.join(map(self.prettytabify,
				   map(string.split,self.logs)),
			       '\n\t          ---\n\t          ')
	if not self.type:
	    type = 'Unclassified'
	else:
	    type = str(self.type)
	if not self.owner:
	    owner = 'Unknown'
	else:
	    owner = self.owner
	if not self.expires:
	    expires = 'Never'
	else:
	    expires = ctime(self.expires)
	if not self.checked:
	    checked = 'Never'
	else:
	    checked = ctime(self.checked)
	if not self.reviewdate:
	    reviewdate = 'Never'
	else:
	    reviewdate = ctime(self.reviewdate)
	if not self.xrefs:
	    xrefs = 'None'
	else:
	    keys = map(str,self.xrefs.keys())
	    keys.sort()
	    xrefs = string.join(keys,'\n\t           ')
	if not self.remarks:
	    remarks = 'None'
	else:
	    remarks = self.prettytabify(string.split(self.remarks,'\n'))
	return """\
K-Line Information:
	Hostmask: %s
	Authmask: %s
	  Reason: %s
            Type: %s
	      ID: %s
	Added By: %s
	    Date: %s
         Expires: %s
	 Checked: %s
	  Review: %s
	   Hosts: %s
            Logs: %s
	 Remarks: %s""" % (`self.hostmask`, authmask, reason, type,
	                   id, owner, ctime(self.date), expires,
			   checked, reviewdate, offendhosts, logs,
			   remarks)

    def generateid(self):
	"""
	Stub function that is meant to generate a unique ID for the
	K-Line. Intended to be over-riden/replaced.
	"""
	return time()

# End.
