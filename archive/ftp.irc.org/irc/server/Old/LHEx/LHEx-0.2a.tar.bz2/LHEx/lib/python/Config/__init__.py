"""
Initialisation for the Config package.
"""
from config import *

# End.
