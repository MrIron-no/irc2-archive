"""
Module that defines some utility functions for the application.

Author: Andrew Snare
  Date: 9th September, 1998
    ID: $Id$

XXX: Hmmm. Need to put the copyright and license information in here.
"""
import time

def ctime(secs):
    """
    Our own version of the standard ctime() function. However, we
    add timezone information and handle the "Never" case.
    """

    if secs is None:
	return "Never"

    return time.strftime("%a %b %d %I:%M:%S%p (%Z) %Y",
			 time.localtime(secs))

# End.
