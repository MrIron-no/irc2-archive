/*****************************************************************************
  
  Zope Public License (ZPL) Version 0.9.5
  ---------------------------------------
  
  Copyright (c) Digital Creations.  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are
  met:
  
  1. Redistributions in source code must retain the above copyright
     notice, this list of conditions, and the following disclaimer.
  
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions, and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.
  
  3. Any use, including use of the Zope software to operate a website,
     must either comply with the terms described below under
     "Attribution" or alternatively secure a separate license from
     Digital Creations.  Digital Creations will not unreasonably
     deny such a separate license in the event that the request
     explains in detail a valid reason for withholding attribution.
  
  4. All advertising materials and documentation mentioning
     features derived from or use of this software must display
     the following acknowledgement:
  
       "This product includes software developed by Digital Creations
       for use in the Z Object Publishing Environment
       (http://www.zope.org/)."
  
     In the event that the product being advertised includes an
     intact Zope distribution (with copyright and license included)
     then this clause is waived.
  
  5. Names associated with Zope or Digital Creations must not be used to
     endorse or promote products derived from this software without
     prior written permission from Digital Creations.
  
  6. Modified redistributions of any form whatsoever must retain
     the following acknowledgment:
  
       "This product includes software developed by Digital Creations
       for use in the Z Object Publishing Environment
       (http://www.zope.org/)."
  
     Intact (re-)distributions of any official Zope release do not
     require an external acknowledgement.
  
  7. Modifications are encouraged but must be packaged separately as
     patches to official Zope releases.  Distributions that do not
     clearly separate the patches from the original work must be clearly
     labeled as unofficial distributions.  Modifications which do not
     carry the name Zope may be packaged in any form, as long as they
     conform to all of the clauses above.
  
  
  Disclaimer
  
    THIS SOFTWARE IS PROVIDED BY DIGITAL CREATIONS ``AS IS'' AND ANY
    EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL DIGITAL CREATIONS OR ITS
    CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
    USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
    OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGE.
  
  Attribution
  
    Individuals or organizations using this software as a web site must
    provide attribution by placing the accompanying "button" and a link
    to the accompanying "credits page" on the website's main entry
    point.  In cases where this placement of attribution is not
    feasible, a separate arrangment must be concluded with Digital
    Creations.  Those using the software for purposes other than web
    sites must provide a corresponding attribution in locations that
    include a copyright using a manner best suited to the application
    environment.  Where attribution is not possible, or is considered
    to be onerous for some other reason, a request should be made to
    Digital Creations to waive this requirement in writing.  As stated
    above, for valid requests, Digital Creations will not unreasonably
    deny such requests.
  
  This software consists of contributions made by Digital Creations and
  many individuals on behalf of Digital Creations.  Specific
  attributions are listed in the accompanying credits file.
  
 ****************************************************************************/
static char cPickleJar_module_documentation[] = 
""
"\n$Id: cPickleJar.c,v 1.6 1998/12/04 20:15:27 jim Exp $"
;

#include "ExtensionClass.h"

static PyObject *ErrorObject;

/* ----------------------------------------------------- */

static void PyVar_Assign(PyObject **v, PyObject *e) { Py_XDECREF(*v); *v=e;}
#define ASSIGN(V,E) PyVar_Assign(&(V),(E))
#define UNLESS(E) if(!(E))
#define UNLESS_ASSIGN(V,E) ASSIGN(V,E); UNLESS(V)
#define OBJECT(O) ((PyObject*)(O))
#define LIST(O) ((PyListObject*)(O))


static PyObject *Pickler, *StringIO, *arg0, *arg1,
  *py__p_oid, *py__p_jar, *py_new_oid, *py__p_changed, *py_persistent_id,
  *py_db, *py_store, *py_seek, *py_getvalue, *py_cache, *py_dump,
  *py_clear_memo, *py___class__, *py___getinitargs__,
  *py___getstate__, *py___changed__, *py_info, *one, *py_oid,
  *py___module__, *py___name__;

/* Declarations for objects of type pid */

typedef struct {
  PyObject_HEAD
  PyObject *jar;
  PyObject *stack;  
} pidobject;

staticforward PyTypeObject PidType;
#define PID(O) ((pidobject*)(O))

static int
po(PyObject *o)
{
  int r;
  r=PyObject_Print(o, stderr, 0);
  fprintf(stderr,"\n");
  fflush(stderr);
  return r;
}

static pidobject *
newpid(PyObject *jar, PyObject *stack)
{
  pidobject *self;
	
  UNLESS(self = PyObject_NEW(pidobject, &PidType)) return NULL;
  Py_INCREF(jar);
  self->jar=jar;
  Py_INCREF(stack);
  self->stack=stack;
  return self;
}

static void
pid_dealloc(pidobject *self)
{
  Py_DECREF(self->jar);
  Py_DECREF(self->stack);
  PyMem_DEL(self);
}

static PyObject *
pid_plan(pidobject *self, PyObject *object)
{
  PyObject *oid=0, *jar=0, *cls=0;

  UNLESS(oid=PyObject_GetAttr(object, py__p_oid)) goto not_persistent;
  if(oid != Py_None) UNLESS(jar=PyObject_GetAttr(object, py__p_jar)) goto err;
  if(jar != self->jar)
    {
      UNLESS_ASSIGN(oid, PyObject_GetAttr(self->jar, py_new_oid)) goto err;
      UNLESS_ASSIGN(oid, PyObject_CallObject(oid, NULL)) goto err;
      if(PyObject_SetAttr(object, py__p_oid, oid) < 0) goto err;
      if(PyObject_SetAttr(object, py__p_jar, self->jar) < 0) goto err;
      if(PyList_Append(self->stack, object) < 0) goto err;
    }
  else
    {
      UNLESS_ASSIGN(jar,PyObject_GetAttr(object, py__p_changed)) goto err;
      if(PyObject_IsTrue(jar) && PyList_Append(self->stack, object) < 0)
	goto err;
    }
  Py_XDECREF(jar);

  UNLESS(cls=PyObject_GetAttr(object, py___class__)) goto err;
  UNLESS(jar=PyObject_GetAttr(cls, py___getinitargs__))
    {
      PyErr_Clear();
      UNLESS(jar=PyObject_GetAttr(cls,py___module__)) goto err;
      UNLESS_ASSIGN(cls, PyObject_GetAttr(cls,py___name__)) goto err;
      UNLESS_ASSIGN(oid, Py_BuildValue("O(OO)", oid, jar, cls)) goto err;
    }
  Py_DECREF(jar);
  Py_DECREF(cls);

  return oid;

err:
  Py_XDECREF(jar);
  Py_XDECREF(cls);
  Py_DECREF(oid);
  return NULL;

not_persistent:
  PyErr_Clear();
  Py_INCREF(Py_None);
  return Py_None;
}  

static PyObject *
pid_call(pidobject *self, PyObject *args, PyObject *kw)
{
  PyObject *object;

  UNLESS(PyArg_ParseTuple(args,"O",&object)) return NULL;
  object=pid_plan(self,object);
  return object;
}  

static PyTypeObject PidType = {
  PyObject_HEAD_INIT(NULL)
  0,				/*ob_size*/
  "pid",			/*tp_name*/
  sizeof(pidobject),		/*tp_basicsize*/
  0,				/*tp_itemsize*/
  /**************** methods *******************/
  (destructor)pid_dealloc,	/*tp_dealloc*/
  (printfunc)0,			/*tp_print*/
  (getattrfunc)0,		/*obsolete tp_getattr*/
  (setattrfunc)0,		/*obsolete tp_setattr*/
  (cmpfunc)0,			/*tp_compare*/
  (reprfunc)0,			/*tp_repr*/
  0,				/*tp_as_number*/
  0,				/*tp_as_sequence*/
  0,				/*tp_as_mapping*/
  (hashfunc)0,			/*tp_hash*/
  (ternaryfunc)pid_call,	/*tp_call*/
  (reprfunc)0,			/*tp_str*/
  (getattrofunc)0,		/*tp_getattro*/
  (setattrofunc)0,		/*tp_setattro*/
  
  /* Space for future expansion */
  0L,0L,
  "internal type used in pickle jars"
};

static int 
call_sub(PyObject *sub, PyObject *args)
{
  UNLESS(sub=PyObject_CallObject(sub,args)) return -1;
  Py_DECREF(sub);
  return 0;
}

static PyObject *
pj_store(PyObject *self, PyObject *args)
{
  PyObject *object, *T=0, *stack, *state=0, *topoid=0, *file=0, *pickler=0,
    *store=0, *seek=0, *cache=0, *dump=0, *clear_memo=0,
    *o=0, *oid=0, *r=0;
  int l;

  UNLESS(PyArg_ParseTuple(args,"O|O",&object,&T)) return NULL;
  args=NULL;
  UNLESS(stack=PyList_New(0)) return NULL;
  UNLESS(state=OBJECT(newpid(self,stack))) goto err;
  UNLESS(topoid=pid_plan(PID(state),object)) goto err;
  if((l=PyList_Size(stack)) < 0) goto err;
  if(! l)
    {
      Py_DECREF(stack);
      Py_DECREF(state);
      return topoid;
    }
  if(T)
    {
      UNLESS(T=PyObject_GetAttr(T,py_info)) goto err;
      UNLESS_ASSIGN(T,PyObject_CallObject(T,NULL)) goto err;
    }
  else UNLESS(T=PyString_FromString("")) goto err;

  UNLESS(file=PyObject_CallObject(StringIO, NULL)) goto err;
  UNLESS(pickler=PyObject_CallFunction(Pickler,"Oi",file,1)) goto err;
  if(PyObject_SetAttr(pickler, py_persistent_id, state) < 0) goto err;
  UNLESS(store=PyObject_GetAttr(self,py_db)) goto err;
  UNLESS_ASSIGN(store,PyObject_GetAttr(store,py_store)) goto err;
  UNLESS(seek=PyObject_GetAttr(file,py_seek)) goto err;
  UNLESS_ASSIGN(file, PyObject_GetAttr(file, py_getvalue)) goto err;
  UNLESS(cache=PyObject_GetAttr(self,py_cache)) goto err;
  UNLESS(dump=PyObject_GetAttr(pickler, py_dump)) goto err;
  UNLESS(clear_memo=PyObject_GetAttr(pickler, py_clear_memo)) goto err;
  
  while(l)
    {
      ASSIGN(o,PyList_GET_ITEM(LIST(stack),l-1));
      Py_INCREF(o);
      if(PyList_SetSlice(stack,l-1,l,NULL) < 0) goto err;
      UNLESS_ASSIGN(oid,PyObject_GetAttr(o,py__p_oid)) goto err;

      UNLESS_ASSIGN(state,PyObject_GetAttr(o,py___class__)) goto err;
      ASSIGN(args,PyObject_GetAttr(state,py___getinitargs__));
      if(args)
	{
	  UNLESS_ASSIGN(args, PyObject_CallObject(args, NULL)) goto err;
	}
      else
	{
	  PyErr_Clear();
	  args=Py_None;
	  Py_INCREF(args);
	}
      UNLESS_ASSIGN(args, Py_BuildValue("OO",state,args)) goto err;
      UNLESS_ASSIGN(args, Py_BuildValue("(O)",args)) goto err;
      if(call_sub(seek,arg0) < 0) goto err;
      if(call_sub(clear_memo,NULL) < 0) goto err;
      UNLESS_ASSIGN(state, PyObject_CallObject(dump, args));

      UNLESS_ASSIGN(state, PyObject_GetAttr(o, py___getstate__)) goto err;
      UNLESS_ASSIGN(state, PyObject_CallObject(state, NULL)) goto err;
      UNLESS_ASSIGN(state, Py_BuildValue("(O)",state)) goto err;
      UNLESS_ASSIGN(state, PyObject_CallObject(dump,state)) goto err;

      UNLESS_ASSIGN(state, PyObject_CallObject(file,arg1)) goto err;
      UNLESS_ASSIGN(state, Py_BuildValue("OOO",oid,state,T)) goto err;
      UNLESS_ASSIGN(state, PyObject_CallObject(store,state)) goto err;

      if(PyObject_SetItem(cache,oid,o) < 0) goto err;
      UNLESS_ASSIGN(o, PyObject_GetAttr(o, py___changed__)) goto err;
      UNLESS_ASSIGN(o, PyObject_CallObject(o, arg0)) goto err;
      
      if((l=PyList_Size(stack)) < 0) goto err;
    }

  r=topoid;
  topoid=NULL;

err:
  Py_DECREF(stack);
  Py_XDECREF(T);
  Py_XDECREF(state);
  Py_XDECREF(topoid);
  Py_XDECREF(file);
  Py_XDECREF(pickler);
  Py_XDECREF(store);
  Py_XDECREF(seek);
  Py_XDECREF(cache);
  Py_XDECREF(dump);
  Py_XDECREF(clear_memo);
  Py_XDECREF(o);
  Py_XDECREF(oid);

  return r;
}

static PyObject *
pj_new_oid(PyObject *self, PyObject *args)
{
  PyObject *r;

  UNLESS(r=PyObject_GetAttr(self, py_oid)) return NULL;
  UNLESS_ASSIGN(r,PyNumber_Add(r,one)) return NULL;
  if(PyObject_SetAttr(self,py_oid,r) < 0)
    {
      Py_DECREF(r);
      return NULL;
    }
  return r;
}

/* List of methods defined in the module */

static struct PyMethodDef Module_Level__methods[] = {  
  {NULL, (PyCFunction)NULL, 0, NULL}		/* sentinel */
};

/* Initialization function for the module (*must* be called initcPickleJar) */

static struct PyMethodDef PickleJar_methods[] = {
  {"store",(PyCFunction)pj_store,1,"store an object"},  
  {"new_oid",(PyCFunction)pj_new_oid,1,"Get the next available object id"},  
  {NULL,		NULL}		/* sentinel */
};

void
initcPickleJar()
{
  PyObject *m, *d;
  char *rev="$Revision: 1.6 $";
  PURE_MIXIN_CLASS(PickleJar,"",PickleJar_methods);

  UNLESS(Pickler=PyImport_ImportModule("cPickle")) return;
  UNLESS_ASSIGN(Pickler, PyObject_GetAttrString(Pickler, "Pickler")) return;
  UNLESS(StringIO=PyImport_ImportModule("cStringIO")) return;
  UNLESS_ASSIGN(StringIO, PyObject_GetAttrString(StringIO, "StringIO")) return;
#define INIT_STRING(S) if(!(py_ ## S = PyString_FromString(#S))) return

  INIT_STRING(_p_oid);
  INIT_STRING(oid);
  INIT_STRING(_p_jar);
  INIT_STRING(new_oid);
  INIT_STRING(_p_changed);
  INIT_STRING(persistent_id);
  INIT_STRING(db);
  INIT_STRING(store);
  INIT_STRING(seek);
  INIT_STRING(getvalue);
  INIT_STRING(cache);
  INIT_STRING(dump);
  INIT_STRING(clear_memo);
  INIT_STRING(__class__);
  INIT_STRING(__getinitargs__);
  INIT_STRING(__getstate__);
  INIT_STRING(__changed__);
  INIT_STRING(__module__);
  INIT_STRING(__name__);
  INIT_STRING(info);

  UNLESS(arg0=Py_BuildValue("(i)",0)) return;
  UNLESS(arg1=Py_BuildValue("(i)",1)) return;

  UNLESS(one=PyInt_FromLong(1)) return;

  /* Create the module and add the functions */
  m = Py_InitModule4("cPickleJar", Module_Level__methods,
		     cPickleJar_module_documentation,
		     (PyObject*)NULL,PYTHON_API_VERSION);

  /* Add some symbolic constants to the module */
  d = PyModule_GetDict(m);
  PyExtensionClass_Export(d,"PickleJar",PickleJarType);

  PidType.ob_type=&PyType_Type;

  PyDict_SetItemString(d, "__version__",
		       PyString_FromStringAndSize(rev+11,strlen(rev+11)-2));
  	
  /* Check for errors */
  if (PyErr_Occurred())
    Py_FatalError("can't initialize module cPickleJar");
}

/*****************************************************************************
Revision Log:

  $Log: cPickleJar.c,v $
  Revision 1.6  1998/12/04 20:15:27  jim
  Detabification and new copyright.

  Revision 1.5  1998/05/07 22:14:17  jim
  Changed the way object references are saved.  Rather than saving the
  class, we save the class mosule and class name.  This allows us to
  handle import errors ourself.

  Revision 1.4  1997/12/16 21:29:25  jim
  Moved new_oid method to C.

  Revision 1.3  1997/12/15 16:36:15  jim
  Updated to use new pickling protocol.

  Revision 1.2  1997/09/08 18:59:55  jim
  Added binary output flag. Waaaaaaa!

  Revision 1.1  1997/05/08 19:28:05  jim
  *** empty log message ***

  $Revision 1.1  1997/02/24 23:25:42  jim
  $initial
  $

*****************************************************************************/
