"""
Module that defines the class that encapsulates the application.

Author: Andrew Snare
  Date: 9th September, 1998
    ID: $Id$

XXX: Hmmm. Need to put the copyright and license information in here.
"""
import sys, os
import DocumentTemplate, BoboPOS
import Config
import Users
import Auth
import Incidents
import Bans
import Reports
from ExternalFile import ExternalFile

# Shortcut
join = os.path.join

class Application:
    """
    Encapsulates the LHEx application as a whole.
    """

    def __init__(self):
	"""
	Initialize the application data.
	"""

	# Here we open the persistent database and create the initial
	# databases if they're not already present
	self._DB = BoboPOS.PickleDictionary(join(Config.DATA_LOC,"LHEx.data"))

	if not self._DB.has_key("users"):
	    self._DB["users"] = Users.UserList()
	    self._DB["users"]._adduser(Config.admin.username,
				       "epr0cks",
				       Config.admin.realname,
				       Config.admin.email,
				       Config.admin.url,
				       None)
	    get_transaction().commit()
	self.users = self._DB["users"]

	if not self._DB.has_key("bans"):
	    self._DB["bans"] = Bans.BanList()
	    get_transaction().commit()
	self.bans = self._DB["bans"]

	if not self._DB.has_key("incidents"):
	    self._DB["incidents"] = Incidents.IncidentList(self.bans)
	    get_transaction().commit()
	self.incidents = self._DB["incidents"]

	self.reports = Reports.Reports()

	# For stuff that needs to be authenticated, use this user
	# database (this can't be static, since self.users needs to
	# exist prior to instantiation).
	self.__allow_groups__ = Auth.Authentication(self.users)

	return

    # This object is "public".
    __roles__ = None

    # Default document that gets displayed:
    index_html = DocumentTemplate.HTMLFile(join(Config.DTML_LOC,"LHEx.dhtml"),
					   Config=Config)

    # Publish our stylesheet:
    LHEx_css = ExternalFile(join(Config.DTML_LOC,"LHEx.css"),"text/css")
    # And some images we need:
    LHEx_jpg = ExternalFile(join(Config.DTML_LOC,"LHEx.jpg"),"image/jpeg")
    info_jpg = ExternalFile(join(Config.DTML_LOC,"info.jpg"),"image/jpeg")
    mark_jpg = ExternalFile(join(Config.DTML_LOC,"mark.jpg"),"image/jpeg")
    questio_jpg = ExternalFile(join(Config.DTML_LOC,"questio.jpg"),
			       "image/jpeg")
    # This is a neat JavaScript thing we can use from forms:
    BoboValidate_js = ExternalFile(join(Config.DTML_LOC,"BoboValidate.js"),
				   "application/x-javascript")

# End.
