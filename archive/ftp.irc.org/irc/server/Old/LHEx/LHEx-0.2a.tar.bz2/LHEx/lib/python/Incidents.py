"""
This module defines some classes that model incidents.

Classes:	Incident, IncidentList

Author:		Andrew Snare (ajs@pigpond.com)
Date:		November 18, 1998

Version:	$Id$
"""
from DocumentTemplate import HTMLFile
import BoboPOS
import sys, os, time, string
import Config, Util

# Shortcut
join = os.path.join

# Default data for an Incident
IncidentDefaults = {
    'reference'  : None,
    'owner'      : 0,
    'description': "",
    'pubreason'  : "No reason given",
    'logs'       : "",
    'hosts'      : [],
    'bans'       : [],
    'created'    : None,
    'expiry'     : None,
    'lastreview' : None,
    'nextreview' : None }

class Incident(BoboPOS.Persistent):
    """
    Encapsulates the meta-data pertaining to an incident.
    """
    def __init__(self,
		 reference=None,		# ref ID for this incident
		 owner=0,			# Owner of this incident
		 description="",		# Description of incident
		 pubreason="No reason given",	# "Reason" showed to users
		 logs="",			# Logs for the incident
		 hosts=[],			# Hosts involved in incident
		 bans=[],			# Bans for the incident
		 created=None,			# Time incident was logged
		 expiry=None,			# When incident expires
		 lastreview=None,		# Time of last review
		 nextreview=None):		# Time of next review
	"""
	Initialize the incident attributes.
	"""
	# Simply store the provided data
	self.id = reference
	self.owner = owner
	self.description = description
	self.pubreason = pubreason
	self.logs = logs
	self.hosts = hosts
	self.bans = bans
	if created:
	    self.created = created
	else:
	    self.created = time.time()
	if expiry:
	    self.expiry = expiry
	else:
	    self.expiry = self.created
	if lastreview:
	    self.lastreview = lastreview
	else:
	    self.lastreview = self.created
	if nextreview:
	    self.nextreview = nextreview
	else:
	    self.nextreview = self.created + (7*24*60*60)# Default, 1 week

	return

    def __getattr__(self,key):
	"""
	We're not meant to override this, but I think we can do it
	relatively safely. Fingers crossed.
	"""
	# Basically we use the inherited __getattr__, but fall back
	# on data insertion if we need to.
	try:
	    return BoboPOS.Persistent.__getattr__(self,key)
	except AttributeError, info:
	    if IncidentDefaults.has_key(key):
		data = IncidentDefaults[key]
		self.__setattr__(key, data)
		return data
	    raise AttributeError, info, sys.exc_info()[2]
	return						# Never reached

    def expired(self):
	"""
	Returns true if this incident has expired.
	"""
	return time.time() >= self.expiry

    # Allow any known user to view this incident
    __roles__ = ["AnyUser"]

    show = HTMLFile(join(Config.DTML_LOC,"IncidentInfo.dhtml"),
		    Config=Config, ctime=Util.ctime)
    # Use the showuser method by default
    index_html = show

class IncidentList(BoboPOS.Persistent):
    """
    Manages a list of incidents.
    """
    def __init__(self,banlist=None):
	"""
	Initialize the list of users we know about.
	"""
	self.incidents = {}			# Start off empty
	self._banlist = banlist

    def __getitem__(self,key):
	"""
	Allow hash lookup to map onto the incident list.
	"""
	try:
	    return self.incidents[string.atoi(key)]
	except ValueError:
	    raise "Not Found"
	return					# Never reached

    def _addincident(self,owner,description,pubreason,logs,hosts,bans,
		     time,expiry,review):
	"""
	Actually adds the new incident to the list.
	"""
	ID = len(self.incidents)		# Work out the next ID
	newone = Incident(ID,owner,description,pubreason,logs,hosts,bans,
			  time,expiry,time,review)
	self.incidents[ID] = newone
	self.__changed__(1)			# So BoboPOS picks it up

	# Register the bans in the banlist
	if self._banlist:
	    for ban in bans:
		self._banlist._addban(ban,newone)

	return newone

    def search(self,reference,REQUEST,RESPONSE):
	"""
	Redirects the request via the hash-lookup interface.
	"""
	RESPONSE.redirect("%s/%d" % (REQUEST['URL1'], reference))
	return					# Never reached

    def createincident(self,description,pubreason,logs,hosts,bans,
		       exprelabs,expirequant,expireunit,expireday,
		       expiremonth,expireyear,revrelabs,revquant,
		       revunit,revday,revmonth,revyear,REQUEST,RESPONSE):
	"""
	Exported web interface for adding a new incident.
	"""
	if not description:
	    return HTMLFile(join(Config.DTML_LOC,"InvalidDesc.dhtml"))\
		   (REQUEST,{'Config':Config})
	if not pubreason:
	    return HTMLFile(join(Config.DTML_LOC,"InvalidReason.dhtml"))\
		   (REQUEST,{'Config':Config})
	# Split up the hosts and bans
	hosts = map(string.strip,string.split(str(hosts)))
	bans = map(string.strip,string.split(str(bans)))
	# Timestamp of this "incident"
	now = time.time()
	# Calculate the expiry of the incident
	if exprelabs == "Relative":
	    # Calculate the current time
	    expiry = now
	    if expireunit == "minutes":
		expiry = expiry + expirequant * 60
	    elif expireunit == "hours":
		expiry = expiry + expirequant * 60*60
	    elif expireunit == "days":
		expiry = expiry + expirequant * 60*60*24
	    elif expireunit == "weeks":
		expiry = expiry + expirequant * 60*60*24*7
	    elif expireunit == "months":
		timeparts = map(None, time.localtime(expiry))
		(years,months) = divmod(timeparts[1]+expirequant-1,12)
		timeparts[0] = timeparts[0] + years
		timeparts[1] = months + 1
		expiry = time.mktime(tuple(timeparts))
	    elif expireunit == "years":
		timeparts = map(None, time.localtime(expiry))
		timeparts[0] = timeparts[0] + expirequant
		expiry = time.mktime(tuple(timeparts))
	    else:
		raise "Bad Request"
	elif exprelabs == "Absolute":
	    # Generate an absolute time
	    timeparts = (expireyear, expiremonth, expireday, 0,0,0,0,0,-1)
	    expiry = time.mktime(timeparts)
	elif exprelabs == "Never":
	    expiry = None
	else:
	    raise "Bad Request"

	# Do the same for the time of next review
	if revrelabs == "Relative":
	    # Calculate the current time
	    review = now
	    if revunit == "minutes":
		review = review + revquant * 60
	    elif revunit == "hours":
		review = review + revquant * 60*60
	    elif revunit == "days":
		review = review + revquant * 60*60*24
	    elif revunit == "weeks":
		review = review + revquant * 60*60*24*7
	    elif revunit == "months":
		timeparts = map(None, time.localtime(review))
		(years,months) = divmod(timeparts[1]+revquant-1,12)
		timeparts[0] = timeparts[0] + years
		timeparts[1] = months + 1
		review = time.mktime(tuple(timeparts))
	    elif revunit == "years":
		timeparts = map(None, time.localtime(review))
		timeparts[0] = timeparts[0] + revquant
		review = time.mktime(tuple(timeparts))
	    else:
		raise "Bad Request"
	elif revrelabs == "Absolute":
	    # Generate an absolute time
	    timeparts = (revyear, revmonth, revday, 0,0,0,0,0,-1)
	    review = time.mktime(timeparts)
	elif revrelabs == "Never":
	    review = None
	else:
	    raise "Bad Request"

	# Actually add the incident to our list
	new = self._addincident(REQUEST["AUTHENTICATED_USER"],
				description,pubreason,logs,hosts,bans,
				now,expiry,review)

	# Redirect them to the newly created incident
	return self.search(new.id,REQUEST,RESPONSE)

    # Allow the admin to clear all known incidents -- debugging only
    def clearall(self):
	"""
	Clears all incidents from the database.
	"""
	self.incidents = {}
	return "All incidents have been removed. Bogus, dude!"
    
    clearall__roles__ = ["Admin"]

    # Make this object viewable by any known user
    __roles__ = ["AnyUser"]

    addincident = HTMLFile(join(Config.DTML_LOC,"AddIncident.dhtml"),
			   Config=Config)

    # If an incident isn't specified, we simply allow a search for one
    findincident = HTMLFile(join(Config.DTML_LOC,"IncidentFind.dhtml"),
			    Config=Config)
    index_html = findincident

# End
