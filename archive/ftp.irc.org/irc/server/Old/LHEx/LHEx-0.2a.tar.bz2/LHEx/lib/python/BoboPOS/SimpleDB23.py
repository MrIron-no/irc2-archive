##############################################################################
# 
# Zope Public License (ZPL) Version 0.9.5
# ---------------------------------------
# 
# Copyright (c) Digital Creations.  All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
# 
# 1. Redistributions in source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
# 
# 3. Any use, including use of the Zope software to operate a website,
#    must either comply with the terms described below under
#    "Attribution" or alternatively secure a separate license from
#    Digital Creations.  Digital Creations will not unreasonably
#    deny such a separate license in the event that the request
#    explains in detail a valid reason for withholding attribution.
# 
# 4. All advertising materials and documentation mentioning
#    features derived from or use of this software must display
#    the following acknowledgement:
# 
#      "This product includes software developed by Digital Creations
#      for use in the Z Object Publishing Environment
#      (http://www.zope.org/)."
# 
#    In the event that the product being advertised includes an
#    intact Zope distribution (with copyright and license included)
#    then this clause is waived.
# 
# 5. Names associated with Zope or Digital Creations must not be used to
#    endorse or promote products derived from this software without
#    prior written permission from Digital Creations.
# 
# 6. Modified redistributions of any form whatsoever must retain
#    the following acknowledgment:
# 
#      "This product includes software developed by Digital Creations
#      for use in the Z Object Publishing Environment
#      (http://www.zope.org/)."
# 
#    Intact (re-)distributions of any official Zope release do not
#    require an external acknowledgement.
# 
# 7. Modifications are encouraged but must be packaged separately as
#    patches to official Zope releases.  Distributions that do not
#    clearly separate the patches from the original work must be clearly
#    labeled as unofficial distributions.  Modifications which do not
#    carry the name Zope may be packaged in any form, as long as they
#    conform to all of the clauses above.
# 
# 
# Disclaimer
# 
#   THIS SOFTWARE IS PROVIDED BY DIGITAL CREATIONS ``AS IS'' AND ANY
#   EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
#   IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
#   PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL DIGITAL CREATIONS OR ITS
#   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
#   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
#   ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
#   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
#   OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
#   SUCH DAMAGE.
# 
# Attribution
# 
#   Individuals or organizations using this software as a web site must
#   provide attribution by placing the accompanying "button" and a link
#   to the accompanying "credits page" on the website's main entry
#   point.  In cases where this placement of attribution is not
#   feasible, a separate arrangment must be concluded with Digital
#   Creations.  Those using the software for purposes other than web
#   sites must provide a corresponding attribution in locations that
#   include a copyright using a manner best suited to the application
#   environment.  Where attribution is not possible, or is considered
#   to be onerous for some other reason, a request should be made to
#   Digital Creations to waive this requirement in writing.  As stated
#   above, for valid requests, Digital Creations will not unreasonably
#   deny such requests.
# 
# This software consists of contributions made by Digital Creations and
# many individuals on behalf of Digital Creations.  Specific
# attributions are listed in the accompanying credits file.
# 
##############################################################################
__doc__='''Version 2 to version 3 file conversion routines.

$Id: SimpleDB23.py,v 1.6 1998/12/04 20:15:26 jim Exp $'''
__version__='$Revision: 1.6 $'[11:-2]

from SimpleDB import *  # I'm a lazy bum.

def convert23(file,file_name):
        import os
        dest_name=file_name+'.v3'
        dest=open(dest_name,'wb')
        convert23_(file,dest)
        file.close()
        dest.close()
        os.rename(file_name, file_name+'.v2')
        os.rename(dest_name, file_name)

def convert23_(src,dest, debug=None):
    """\
    Copy a MultipleRevision Rev 2.0 simple database

    Also getting rid of unwanted records.

    This is harder than it at first appears due to the simple format
    of the file.  I can't know till fairly late in the game whether a
    record should appear in the output.  I actually have to build up a
    list of records to be kept and then sort these before wring the
    file. :-(.
    """ #'

    kept_records=[]
    index={}
    dpos=pos=len(MultipleRevision.packed_version2)
    hs2=len(pack("iidi",0,0,0.0,0))
    sseek=src.seek
    dseek=dest.seek
    read=src.read
    write=dest.write

    while 1:
        sseek(pos)
        h=read(hs2)
        if len(h) != hs2: break
        oid,prev,start,plen=unpack("iidi",h)

        if debug: debug("r %d: %d %16.16g %d\n" %
                        (src.tell(),oid,start,plen))

        newpos=pos+hs2+plen

        if oid:
            if prev: kept_records.append(index[oid])
            index[oid]=start,pos
        pos=newpos

    kept_records=kept_records+index.values()
    index={}
    kept_records.sort()

    dseek(0)
    write(MultipleRevision.packed_version)
    for start,pos in kept_records:
        sseek(pos)
        h=read(hs2)
        oid,prev,start,plen=unpack("iidi",h)
        tlen=28+plen
        p=read(plen)
        if plen==0:
            plen=-1
        try: prev=index[oid]
        except: prev=0
        h=pack(">iidii",oid,prev,start,tlen,plen)
        dseek(dpos)
        write(h)
        write(p)
        write(h[16:20])
        dpos=dpos+tlen
    dest.flush()
