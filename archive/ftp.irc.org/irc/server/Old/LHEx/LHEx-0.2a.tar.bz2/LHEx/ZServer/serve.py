#!/usr/bin/env python

"""Sample ZServer start script"""

# configuration variables
#
IP_ADDRESS=''
DNS_IP='203.36.167.161'
HTTP_PORT=9673
LHEX_PORT=9674
PID_FILE='var/lhex.pid'
LOG_FILE='var/lhex.log'
MODULE='Main'

from medusa import resolver,logger,http_server,asyncore,status_handler

import zope_handler
import lhex_server
import os

rs = resolver.caching_resolver(DNS_IP)
lg = logger.file_logger(LOG_FILE)

hs = http_server.http_server(
	ip=IP_ADDRESS,
	port=HTTP_PORT,
	resolver=rs,
	logger_object=lg)

ls = lhex_server.lhex_server(LHEX_PORT)
	
zh = zope_handler.zope_handler(MODULE,'')
hs.install_handler(zh)

#sh = status_handler.status_extension([hs,rs,ls])
#hs.install_handler(hs)

try:
	pidfile = open(PID_FILE,"wt")
	pid = os.getpid()
	pidfile.write(str(pid)+'\n')
	pidfile.close()
except: pass

asyncore.loop()
