##############################################################################
# 
# Zope Public License (ZPL) Version 0.9.5
# ---------------------------------------
# 
# Copyright (c) Digital Creations.  All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
# 
# 1. Redistributions in source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
# 
# 3. Any use, including use of the Zope software to operate a website,
#    must either comply with the terms described below under
#    "Attribution" or alternatively secure a separate license from
#    Digital Creations.  Digital Creations will not unreasonably
#    deny such a separate license in the event that the request
#    explains in detail a valid reason for withholding attribution.
# 
# 4. All advertising materials and documentation mentioning
#    features derived from or use of this software must display
#    the following acknowledgement:
# 
#      "This product includes software developed by Digital Creations
#      for use in the Z Object Publishing Environment
#      (http://www.zope.org/)."
# 
#    In the event that the product being advertised includes an
#    intact Zope distribution (with copyright and license included)
#    then this clause is waived.
# 
# 5. Names associated with Zope or Digital Creations must not be used to
#    endorse or promote products derived from this software without
#    prior written permission from Digital Creations.
# 
# 6. Modified redistributions of any form whatsoever must retain
#    the following acknowledgment:
# 
#      "This product includes software developed by Digital Creations
#      for use in the Z Object Publishing Environment
#      (http://www.zope.org/)."
# 
#    Intact (re-)distributions of any official Zope release do not
#    require an external acknowledgement.
# 
# 7. Modifications are encouraged but must be packaged separately as
#    patches to official Zope releases.  Distributions that do not
#    clearly separate the patches from the original work must be clearly
#    labeled as unofficial distributions.  Modifications which do not
#    carry the name Zope may be packaged in any form, as long as they
#    conform to all of the clauses above.
# 
# 
# Disclaimer
# 
#   THIS SOFTWARE IS PROVIDED BY DIGITAL CREATIONS ``AS IS'' AND ANY
#   EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
#   IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
#   PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL DIGITAL CREATIONS OR ITS
#   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
#   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
#   ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
#   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
#   OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
#   SUCH DAMAGE.
# 
# Attribution
# 
#   Individuals or organizations using this software as a web site must
#   provide attribution by placing the accompanying "button" and a link
#   to the accompanying "credits page" on the website's main entry
#   point.  In cases where this placement of attribution is not
#   feasible, a separate arrangment must be concluded with Digital
#   Creations.  Those using the software for purposes other than web
#   sites must provide a corresponding attribution in locations that
#   include a copyright using a manner best suited to the application
#   environment.  Where attribution is not possible, or is considered
#   to be onerous for some other reason, a request should be made to
#   Digital Creations to waive this requirement in writing.  As stated
#   above, for valid requests, Digital Creations will not unreasonably
#   deny such requests.
# 
# This software consists of contributions made by Digital Creations and
# many individuals on behalf of Digital Creations.  Specific
# attributions are listed in the accompanying credits file.
# 
##############################################################################
__doc__='''Indexes for supporting LRTs

$Id: MetaIndex.py,v 1.4 1998/12/04 20:15:25 jim Exp $'''
__version__='$Revision: 1.4 $'[11:-2]

from SimpleDB import Index

class MetaIndex:
    """Provide a mapping from names and object ids to file positions.

    The names are typically transaction names.  This implementation is
    based on the Index class.  It uses a separate Index instance for
    each name encountered.
    """

    def __init__(self):
        self._data={}

    def __getitem__(self,key):
        oid,name=key
        return self._data[name][oid]

    def subindex(self,name,create=0):
        if create:
            data=self._data
            try: index=data[name]
            except KeyError: data[name]=index=Index()
            return index
        else: return self._data[name]

    def hassubindex(self,name): return self._data.has_key(name)
    def subindexes(self): return self._data.values()
    def removeSubindex(self,name): del self._data[name]

    def has_key(self,key):
        try: self[key]
        except: return 0
        return 1

    def __setitem__(self,key,v):
        oid,name=key
        data=self._data
        try: index=data[name]
        except KeyError: data[name]=index=Index()
        index[oid]=v

    def __delitem__(self,key):
        oid,name=key
        del self._data[name][oid]

    def __len__(self):
        data=self._data
        if not data: return 0
        return reduce(lambda x,y: x+y,
                      map(lambda index: len(index), data.values())
                      )

    def values(self):
        data=self._data
        if not data: return []
        return reduce(lambda x,y: x+y,
                      map(lambda index: index.values(), data.values())
                      )

    def items(self):
        r=[]
        for name,index in self._data.items():
            for oid, pos in index.items():
                r.append(((oid,oid),pos))
        return r

    def keys(self):
        r=[]
        for name, index in self._data.items():
            for oid in index.keys():
                r.append((oid,name))
        return r

    def max_key(self):
        r=[]
        for index in self._data.values():
            try: m=index.max_key()
            except:
                m=index.keys()
                m=m and max(m) or 0
            r.append(m)
        return r and max(r) or 0
