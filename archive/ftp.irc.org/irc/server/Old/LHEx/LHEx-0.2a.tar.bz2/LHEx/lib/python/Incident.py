"""
This module defines some classes that model an incident.

Classes:	Incident
		IncidentList

Author:		Andrew Snare (ajs@pigpond.com)
Date:		September 09, 1998

Version:	$Id$
"""
from BoboPOS import Persistent
import time

class Incident(Persistent):
    """
    Encapsulates the reported data for an incident.
    """
    def __init__(self,
		 bans = [],			
                 reason='',                     # No reason for user
                 id=None,                       # Unique ID for the K-Line
                 owner='',                      # No-one owns the K-line
                 offendhosts=[],                # List of offending hosts empty
                 logs=[],                       # No logs associated
                 type=None,                     # Type of offence undefined
                 date=None,                     # K-line created now
                 expires=None,                  # K-Line time of the K-Line
                 checked=None,                  # Date last checked
                 reviewdate=None,               # Date of next review
                 xrefs={},                      # Cross-references
                 remarks=''):                   # No (internal use) comments
        """
        Initialize the incident attributes.
        """
	# This is a list of (usermask, hostmask) tuples.
	self.bans = bans
        self.reason = reason
	# Should generate a unique new ID but there's no way to know
	# what has already been used.
	self.id = id
        self.owner = owner
        if date:
            self.date = date
        else:
            self.date = time()
        self.offendhosts = offendhosts
        self.logs = logs
        self.type = type
	# None means "never".
        self.expires = expires
        self.checked = checked
        self.reviewdate = reviewdate
        self.xrefs = xrefs
        self.remarks = remarks
        return

    def Expired(self):
	"""
	Determines whether the incident has expired or not.
	"""
	return (self.expires and
		self.expires <= time.time())

    def Overdue(self):
	"""
	Determines whether the incident is overdue for review or not.
	"""
	return (self.reviewdate and 
		self.checked <= self.reviewdate <= time.time())

# End
