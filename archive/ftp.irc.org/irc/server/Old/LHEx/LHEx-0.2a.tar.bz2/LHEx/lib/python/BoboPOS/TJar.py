##############################################################################
# 
# Zope Public License (ZPL) Version 0.9.5
# ---------------------------------------
# 
# Copyright (c) Digital Creations.  All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
# 
# 1. Redistributions in source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
# 
# 3. Any use, including use of the Zope software to operate a website,
#    must either comply with the terms described below under
#    "Attribution" or alternatively secure a separate license from
#    Digital Creations.  Digital Creations will not unreasonably
#    deny such a separate license in the event that the request
#    explains in detail a valid reason for withholding attribution.
# 
# 4. All advertising materials and documentation mentioning
#    features derived from or use of this software must display
#    the following acknowledgement:
# 
#      "This product includes software developed by Digital Creations
#      for use in the Z Object Publishing Environment
#      (http://www.zope.org/)."
# 
#    In the event that the product being advertised includes an
#    intact Zope distribution (with copyright and license included)
#    then this clause is waived.
# 
# 5. Names associated with Zope or Digital Creations must not be used to
#    endorse or promote products derived from this software without
#    prior written permission from Digital Creations.
# 
# 6. Modified redistributions of any form whatsoever must retain
#    the following acknowledgment:
# 
#      "This product includes software developed by Digital Creations
#      for use in the Z Object Publishing Environment
#      (http://www.zope.org/)."
# 
#    Intact (re-)distributions of any official Zope release do not
#    require an external acknowledgement.
# 
# 7. Modifications are encouraged but must be packaged separately as
#    patches to official Zope releases.  Distributions that do not
#    clearly separate the patches from the original work must be clearly
#    labeled as unofficial distributions.  Modifications which do not
#    carry the name Zope may be packaged in any form, as long as they
#    conform to all of the clauses above.
# 
# 
# Disclaimer
# 
#   THIS SOFTWARE IS PROVIDED BY DIGITAL CREATIONS ``AS IS'' AND ANY
#   EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
#   IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
#   PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL DIGITAL CREATIONS OR ITS
#   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
#   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
#   ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
#   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
#   OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
#   SUCH DAMAGE.
# 
# Attribution
# 
#   Individuals or organizations using this software as a web site must
#   provide attribution by placing the accompanying "button" and a link
#   to the accompanying "credits page" on the website's main entry
#   point.  In cases where this placement of attribution is not
#   feasible, a separate arrangment must be concluded with Digital
#   Creations.  Those using the software for purposes other than web
#   sites must provide a corresponding attribution in locations that
#   include a copyright using a manner best suited to the application
#   environment.  Where attribution is not possible, or is considered
#   to be onerous for some other reason, a request should be made to
#   Digital Creations to waive this requirement in writing.  As stated
#   above, for valid requests, Digital Creations will not unreasonably
#   deny such requests.
# 
# This software consists of contributions made by Digital Creations and
# many individuals on behalf of Digital Creations.  Specific
# attributions are listed in the accompanying credits file.
# 
##############################################################################
__doc__='''New Bobobase classes to support long-running transactions.

Notes:

  We no longer use these objects for transient transactions.

    The transactions used here are assumed to be useful over time and to
    committed/aborted many times.  So, for example, we don\'t GC
    these transactions or worry about the fact that they have circular
    references.  This allows simplification of a number of routines and
    makes it easier to provide additional useful data structures, such as 
    pools of pickle caches and tables that mark modified objects.

  We will use different objects, that may subclass from these objects,
  for transient LR transactions. 

$Id: TJar.py,v 1.27 1998/12/04 20:15:26 jim Exp $'''
__version__='$Revision: 1.27 $'[11:-2]

from SingleThreadedTransaction import PickleDictionary
from SingleThreadedTransaction import Persistent
import sys
import PickleJar, SimpleDB
import traceback
from string import find, split, join
from time import time, sleep

try: from IIBTree import BTree
except: BTree=lambda: {}

class TM:
    '''Transaction Manager -- Manages long-running transactions

    This object can be thought of as a root object in an object space
    that has a sub-space for each LRT.  Each subspace is a
    transactional pickle dictionary.
    '''

    def __init__(self, pd, create=None, file_name=None):
        """Create a transaction manager

        Arguments:

          pd -- Either a PickleDictionary or the name of a pickle
                dictionary.

          create -- A flag indicating whether a new database is to be
                    created.

          file_name -- The file name for the transaction file.
              If ommitted, then base_file_name.trans will be used.
        """
                
        if type(pd) is type(''):
            base_file_name=pd
            pd=PickleDictionary(base_file_name)
        else:
            base_file_name=pd.file_name
        self.PD=pd
        if file_name is None: file_name=base_file_name+'.trans'
        TDB=self.TDB=SimpleDB.MultipleRevision(
            file_name, create=create, meta_index=1)
        if TDB.index:
            oid,m=max(TDB.index.keys())
            jar=pd._jar
            jar.oid=max(jar.oid,oid)
        transactions=self.Transactions={}
        has_key=transactions.has_key
        self.jars=[]
        self.pds=pds=[]
        self.locks=locks=BTree()
        shared=pd._jar.db.index.has_key
        for name, subindex in TDB.index._data.items():
            T=self[name]
            l=T.jar.tno
            for oid in subindex.keys():
                if shared(oid): locks[oid]=l

    def keys(self): return self.Transactions.keys()

    def __getitem__(self,tname):
        """Get a pickle dictionary for a given transaction name, tname

        If the transaction does not exist, it will be created.
        """
        try: return self.Transactions[tname]
        except: pass

        v=TPD(self.PD, self.TDB, tname)
        v.manager=self
        v.jar.tno=len(self.pds)
        self.Transactions[tname]=v
        self.jars.append(v.jar)
        self.pds.append(v)
        return v

    def maybe_commit_objects(self, objects):
        locks=self.locks
        locked=locks.has_key
        
        for o in objects:
            if not o._p_changed:
                # Don't check if no actual change
                continue 
            oid=o._p_oid
            if oid is None:
                # This thing is probably a foreign TM, like a StupidBase
                # TM.  We need a separate hook for this in the
                # future.
                continue
            if not locked(oid): continue
            i=locks[oid]
            T=self.pds[i]
            if o._p_jar is T.jar: continue

            if hasattr(o, 'title_and_id'): name=o.title_and_id()
            elif hasattr(o, '__name__'): name=o.__name__
            else: name='a %s' % o.__class__.__name__

            index=self.TDB.index
            if (not index.hassubindex(T.name) or
                not index.subindex(T.name).has_key(oid)):
                # Hm, this lock is not valid
                del locks[oid]
                continue

            raise 'Conflict Error', (
                '''This operation is attempting to modify an object,
                <em>%s</em> that was modified in an unsaved session,
                <em>%s</em>.  The session must be saved or discarded
                before the object can be modified.
                ''' % (name, T.name))

        # OK, there aren't any conflicts, 
        for o in objects:
            if not o._p_changed:
                # Don't lock if no actual change
                continue 
            oid=o._p_oid
            if oid is None:
                # This thing is probably a foreign TM, like a StupidBase
                # TM.  We need a separate hook for this in the
                # future.
                continue
            jar=o._p_jar
            if hasattr(jar,'tno'): locks[o._p_oid]=jar.tno
                

    def verify_lock(self, oid):
        try:
            T=self.pds[self.locks[oid]].name
            index=self.TDB.index
            if (not index.hassubindex(T) or
                not index.subindex(T).has_key(oid)):
                del self.locks[oid]
                return 0
            return 1
        finally: pass
        #except: return 0

    def reload_objects(self, objects):
        if objects:
            oids=[]
            append=oids.append
            for o in objects: append(o._p_oid)
            for jar in self.jars: jar.reload_oids(oids)

    def reload_oids(self, oids):
        if oids:
            for jar in self.jars: jar.reload_oids(oids)

    def committer(self):
        # Hack, hack...
        """Return a function that replaces the
        SingleThreadedTransaction.Transaction.commit method with a
        method that notifies the TM of object commits so that LRT
        cached objects can be invalidated."""

        def commit(self, TM=self):
            'Finalize a transaction'
            objects=self._objects
            try:
                TM.maybe_commit_objects(objects)

                for o in tuple(self._objects):
                    o.__inform_commit__(self,self.now)

                TM.reload_objects(objects)
            except:
                t,v,tb=sys.exc_type, sys.exc_value, sys.exc_traceback
                try:
                    self.abort()
                    sys.exc_type, sys.exc_value, sys.exc_traceback=t,v,tb
                except: pass
                tb=None
                raise sys.exc_type, sys.exc_value, sys.exc_traceback
            
            self._clear()

        return commit       

class TPD:
    """Transactional pickle dictionary

    Note that transactional pickle dictionaries cannot particpate in
    LRTs themselves, meaning that you can\'t change the key for a
    transactional pickle dictionary in a LRT.
    """

    def __init__(self, PD, DB, name):
        """Create a transactional pickle dictionary

        Arguments:

        PD -- The base pickle dictionary associated with this
              transactional pickle dictionary. This pickle dictionary
              holds the committed data for the database.

        DB -- The simple DB holding the transaction's records (until
              they are committed).

        name -- The transaction's name.
        """
        self.PD=PD
        self.DB=DB
        self.name = name
        self.jar=Tjar(PD._jar, DB, name)
        self.jar.db.basedb=PD._jar.db

    def __getitem__(self, key):
        return self.jar[self.PD.oid(key)]

    def abort(self):
        jar=self.jar
        db=jar.db
        locks=self.manager.locks
        locked=locks.has_key
        for oid in db.index.subindex(self.name).keys():
            if locked(oid): del locks[oid]
        db.remove_transaction(self.name)
        jar.cache.minimize()

    def commit(self, comment, wait=1):
        'Commit my changes'
        jar=self.PD._jar
        basedb=jar.db
        name=self.name
        try: info=get_transaction().info()
        except: info=''
        info=("%s\t%s, %s %s" %
              ((split(info,'\t')[1:2] or ('',))[0], name, comment, info)
              )
        oldpos=basedb.current_pos()
        mydb=self.jar.db
        # Put base DB in readonly mode.
        # This will allow us to do commit work without
        # blocking read requests.
        jar.db.readonly_mode(1,wait)
        try:
            oids, tindex, newpos=mydb.transaction_records(name,jar.db,info)
            jar.commit(oids, tindex, newpos)
            jar.db.readonly_mode(0)
            self.manager.reload_oids(oids)
        except:
            basedb.current_pos(oldpos)
            jar.db.readonly_mode(0)  
        self.abort()

    def nonempty(self):
        name=self.name
        index=self.jar.db.index
        return index.hassubindex(name) and len(index.subindex(name))

class StupidCache:
    """Stupid cache to make it possible for LRT objects to continue
    to have a moderately useful life after transaction completion.
    """

    def __getitem__(self, key): raise KeyError, key
    def __setitem__(self, key, v): pass

class TDB:
    def __init__(self,db,name):
        self.db=db
        self.name=name

    def __getitem__(self,oid):   return self.db[oid,self.name]
    def store(self,oid,v,m=''): self.db.store((oid,self.name),v,m)
    def __setitem__(self,oid,v): self.db[oid,self.name]=v
    def __delitem__(self,oid):   del self.db[oid,self.name]
    def __len__(self): return len(self.db.index[self.name])
    def ooops(self,oid,s,now): return self.db.ooops((oid,self.name),s,now)
    def doops(self,oid,s,now): return self.db.doops((oid,self.name),s,now)
    def transaction_info(self, start, end, prefix='', *ignored, **also):
        return self.db.transaction_info(start, end, prefix, self.name+' ')

    def mtime(self,oid): return self.db.mtime((oid, self.name))

    
    def exportoid(self, oid, output_file):
        return self.db.exportoid(oid, output_file, self.basedb.record,
                                 self.db.index.subindex(self.name,1))

    def importoid(self, oid, input_file):
        return self.db.importoid(oid, input_file,
                                 self.db.index.subindex(self.name,1),
                                 self.name)
        

    def __getattr__(self,name): return getattr(self.db,name)

class Tjar(PickleJar.PickleJar):
    """Transactional pickle jar

    Transactional pickle jars are used by transactional pickle
    dictionaried to manage data for long-running transactions.
    """

    def __init__(self, jar, db, name, cache_size=100):
        self.base=jar
        self.basedb=jar.db
        self.new_oid=jar.new_oid
        self.db=TDB(db,name)
        self.name=name
        self.cache_size=cache_size
        cache=self.cache=PickleJar.PickleCache(cache_size)

    def full_sweep(self): self.cache.full_sweep()

    def raw(self,oid):
        try: return self.db[oid]
        except KeyError: return self.basedb[oid]
    
    def has_key(self,oid):
        try: self[oid]
        except: return 0
        return 1

    def mtime(self,object):
        try:
            t=self.db.mtime(object._p_oid)
            if t is not None: return t      
        except: pass
        return self.basedb.mtime(object._p_oid)
