"""
This module defines the class that knows how to authenticate objects.

Classes:	User

Author:		Andrew Snare (ajs@pigpond.com)
Date:		January 8, 1999

Version:	$Id$
"""
import sys, string, base64

class Authentication:
    """
    Class that performs authentication based on the allowed roles.
    """
    def __init__(self,users):
	"""
	Setup our authentication scheme.
	"""
	self.users = users			# User database
	return

    def validate(self,request,http_authorization,roles):
	"""
	Attempts to validate the request based on the allowed roles.
	"""
	# Start off by trying to decode the authorization header
	# We only support Basic authentication -- not digest, yet.
	# This code will probably break if we get something other than 
	# Basic as the method.
	if not http_authorization:		# Shouldn't happen?
	    return None
	username,password = \
	    string.split(base64.decodestring(http_authorization[6:]),':')

	# Each role has a different authentication method
	# Roles we understand are:
	#   o Admin     - the LHEx admin
	#   o AnyUser   - any known user
	# In addition, individual usernames will be recognized in the
	# format:
	#   o User:username

	ok = None 				# False by default
	#sys.stderr.write("Roles are %s." % repr(roles))
	for role in roles:
	    #sys.stderr.write("Trying %s: " % role)
	    if hasattr(self,'validate'+role):
		#sys.stderr.write("(found a way)\n")
		ok = apply(getattr(self,'validate'+role),(username,password))
	    else:
		method = string.split(role,':')
		if method[0] == "User" and \
		   self.users.usernames.has_key(method[1]):
		    #sys.stderr.write("(got one)\n")
		    ok = self.validateUser(method[1],username,password)
	    if ok:
		break

	return ok

    def validateAdmin(self,username,password):
	"""
	Attempts to validate the user as having Admin capabilities.
	"""
	# For now we assume the user with ID #0 is the admin.
	try:
	    admin = self.users.userids[0]
	except IndexError: return None

	if admin.username == username and admin._checkpass(password):
	    return admin

	return None

    def validateAnyUser(self,username,password):
	"""
	Attempts to validate the user as any known user.
	"""
	# Just a special case of validating a specific user
	return self.validateUser(username,username,password)

    def validateUser(self,validuser,username,password):
	"""
	Attempts to validate the user as a specific user.
	"""
	# Try to find the username given
	try:
	    user = self.users.userids[self.users.usernames[username]]
	except IndexError: return None
	except KeyError: return None

	# If the provided username matches the required one, and
	# password is ok, we're done
	if validuser == username and user._checkpass(password):
	    return user

	return None

# End.
